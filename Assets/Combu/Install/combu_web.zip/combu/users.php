<?php

include_once "lib/api.php";

use Combu\Utils;
use Combu\AddonModule;
use Combu\ErrorMessage;
use Combu\Mail;
use Combu\Account;
use Combu\Account_Platform;
use Combu\CustomData;
use Combu\AppCustomData;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

    // User login
    case "login":
        wsLogin();
        break;

    // User logout
    case "logout":
        wsLogout();
        break;

    // Create new user
    case "create":
        wsCreate();
        break;

    // Get a user
    case "load":
        wsLoad();
        break;

    // Update user
    case "update":
        wsUpdate();
        break;

    // Check if user exists
    case "exists":
        wsUserExists();
        break;

    // Delete user
    case "delete":
        wsDelete();
        break;

    // Reset the password of a user
    case "reset_pwd":
        wsResetPassword();
        break;

    // Change the password of the logged user
    case "change_pwd":
        wsChangePassword();
        break;

    // Load a list of random users
    case "random":
        wsRandomList();
        break;

    // Create new guest user with random Username
    case "create_guest":
        wsCreateGuest();
        break;
    
    // Search users
    case "search":
        wsSearch();
        break;
    
    // Search users by platform
    case "search_platform":
        wsSearchPlatform();
        break;

    // User login with External Platform (Facebook, Game Center, Play Services etc.)
    case "login_platform":
        wsLoginPlatform();
        break;

    // Link the logged account to another (move the platform accounts to the new)
    case "link_account":
        wsLinkAccount();
        break;
    
    // Link a platform to the logged account
    case "link_platform":
        wsLinkPlatform();
        break;

    }
}
$Database->CloseConnection();
exit();

/**
 * Cleans the customData array coming from web requests by applying the filter of all addons
 * @param array $customData Associative key/value array of account custom data
 */
function cleanIncomingCustomData (&$customData) {
    $newCustomData = array();
    foreach ($customData as $key => $value) {
        if (!AddonModule::IsBlockedUpdateUserCustomData($key))
            $newCustomData[$key] = $value;
    }
    $customData = $newCustomData;
}

/**
 * Check the credentials to login an account
 * @global Account $LoggedAccount
 */
function wsLogin() {
    global $LoggedAccount, $WS_REQUEST;
    $username = (isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "");
    $password = (isset($WS_REQUEST["Password"]) ? trim($WS_REQUEST["Password"]) : "");
    // If the player is logged, do logout
    if ($LoggedAccount->IsLogged()) {
        $LoggedAccount->Logout();
    }
    // Verify the credentials
    $user = NULL;
    $success = Account::CheckLogin($username, $password, $user);
    $message = "";
    if ($success) {
        if (!$user->Enabled) {
            $message = ErrorMessage::Get(ERROR_LOGIN_DISABLED);
            $success = FALSE;
        } else if ($user->ActivationCode) {
            $message = ErrorMessage::Get(ERROR_LOGIN_NOT_ACTIVATED);
            $success = FALSE;
        } else {
            Account::SetSession($user);
            $message = $LoggedAccount->ToJsonFiltered();
        }
    } else {
        $message = ErrorMessage::Get(ERROR_LOGIN_INVALID_CREDENTIALS);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsLoginPlatform() {
    global $WS_REQUEST, $WS_SESSION;
    $platformKey = (isset($WS_REQUEST["PlatformKey"]) ? trim($WS_REQUEST["PlatformKey"]) : "");
    $platformId = (isset($WS_REQUEST["PlatformId"]) ? trim($WS_REQUEST["PlatformId"]) : "");
    $success = FALSE;
    $message = "";
    $justCreated = FALSE;
    // Verify the credentials
    if ($platformKey && $platformId) {
        $accountPlatform = NULL;
        $user = Account_Platform::LoadOrCreateAccount($platformKey, $platformId, $accountPlatform, $justCreated);
        if ($user) {
            if (!$user->Enabled) {
                $message = ErrorMessage::Get(ERROR_LOGIN_DISABLED);
            } else {
                $success = TRUE;
                if ($user->ActivationCode) {
                    $message = ErrorMessage::Get(ERROR_LOGIN_NOT_ACTIVATED);
                    $success = FALSE;
                } else {
                    Account::SetSession($user);
                    // Add the registered platforms for the logged user as result
                    $userArray = $user->ToArrayFiltered();
                    $message = json_encode($userArray);
                }
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_LOGIN_PLATFORM);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Link an account with a platform account
 * @global Account $LoggedAccount
 */
function wsLinkAccount() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $user = NULL;
        $username = (isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "");
        $password = (isset($WS_REQUEST["Password"]) ? trim($WS_REQUEST["Password"]) : "");
        if (Account::CheckLogin($username, $password, $user)) {
            // Move all my platforms, I lose all my data
            $platforms = Account_Platform::Load($LoggedAccount->Id);
            $otherPlatforms = Account_Platform::Load($user->Id);
            foreach ($platforms as $platform) {
                $exists = FALSE;
                foreach ($otherPlatforms as $otherPlatform) {
                    if ($otherPlatform->PlatformKey == $platform->PlatformKey && strcasecmp($otherPlatform->PlatformId, $platform->PlatformId) == 0) {
                        $exists = TRUE;
                        break;
                    }
                }
                if (!$exists) {
                    $newPlatform = new Account_Platform();
                    $newPlatform->IdAccount = $user->Id;
                    $newPlatform->PlatformKey = $platform->PlatformKey;
                    $newPlatform->PlatformId = $platform->PlatformId;
                    $newPlatform->Save();
                }
            }
            // Delete the current account
            $LoggedAccount->Delete();
            // Reset the session to the new account
            Account::SetSession($user);
            // Return the account with all platforms
            $userArray = $user->ToArrayFiltered();
            $userArray["Platforms"] = array();
            $platforms = Account_Platform::Load($user->Id);
            foreach ($platforms as $platform) {
                $userArray["Platforms"][] = $platform->ToArray();
            }
            $message = json_encode($userArray);
            $success = TRUE;
        } else {
            $message = ErrorMessage::Get(ERROR_LOGIN_INVALID_CREDENTIALS);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Link a platform to the logged account
 * @global Account $LoggedAccount
 */
function wsLinkPlatform() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $platformKey = (isset($WS_REQUEST["PlatformKey"]) ? trim($WS_REQUEST["PlatformKey"]) : "");
        $platformId = (isset($WS_REQUEST["PlatformId"]) ? trim($WS_REQUEST["PlatformId"]) : "");
        if ($platformKey && $platformId) {
            $exists = FALSE;
            $platforms = Account_Platform::Load($LoggedAccount->Id);
            foreach ($platforms as $platform) {
                if ($platformKey == $platform->PlatformKey && strcasecmp($platformId, $platform->PlatformId) == 0) {
                    $exists = TRUE;
                    break;
                }
            }
            if (!$exists) {
                $newPlatform = new Account_Platform();
                $newPlatform->IdAccount = $LoggedAccount->Id;
                $newPlatform->PlatformKey = $platformKey;
                $newPlatform->PlatformId = $platformId;
                $newPlatform->Save();
            }
            $userArray = $LoggedAccount->ToArrayFiltered();
            $userArray["Platforms"] = array();
            $platforms = Account_Platform::Load($user->Id);
            foreach ($platforms as $platform) {
                $userArray["Platforms"][] = $platform->ToArray();
            }
            $message = json_encode($userArray);
            $success = TRUE;
        } else {
            $message = ErrorMessage::Get(ERROR_LOGIN_PLATFORM);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Logoff the current user
 * @global Account $LoggedAccount
 */
function wsLogout() {
    global $LoggedAccount;
    $success = TRUE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        AddonModule::NotifyUserLogout($LoggedAccount);
        Account::Logout();
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Create a new account
 */
function wsCreate() {
    global $Addons, $WS_REQUEST;
    // Fill a new object from the REQUEST parameters (must match with class public vars)
    $user = new Account($WS_REQUEST);
    $success = FALSE;
    if ($user->Id == 0 && $user->Username && $user->Password) {
        if (defined("GUEST_PREFIX") && !empty(GUEST_PREFIX) && Utils::StartsWith($user->Username, GUEST_PREFIX, TRUE)) {
            $message = ErrorMessage::Get(ERROR_USER_USERNAME_RESERVED);
        } else if ($user->ExistsUsername()) {
            $message = ErrorMessage::Get(ERROR_USER_USERNAME_EXISTS);
        } else {
            $proceed = TRUE;
            if (REGISTER_EMAIL_REQUIRED) {
                $proceed = FALSE;
                if (!($user->Email && Utils::IsValidEmail($user->Email)))
                    $message = ErrorMessage::Get(ERROR_USER_EMAIL_INVALID);
                else
                    $proceed = TRUE;
            }
            if ($proceed && $user->Email && !REGISTER_EMAIL_MULTIPLE && $user->ExistsEmail()) {
                $message = ErrorMessage::Get(ERROR_USER_EMAIL_EXISTS);
                $proceed = FALSE;
            }
            if ($proceed) {
                $user->Enabled = 1;
                // Set an activation code if required by settings
                if (REGISTER_EMAIL_REQUIRED && REGISTER_EMAIL_ACTIVATION) {
                    $user->ActivationCode = Utils::GenerateRandomCode();
                }
                $success = $user->Save();
                if ($success) {
                    Account::SetSession($user);
                    // Save custom data
                    $customData = "{}";
                    if (isset($WS_REQUEST["CustomData"]))
                    	$customData = $WS_REQUEST["CustomData"];
                    $customData = json_decode($customData, TRUE);
                    cleanIncomingCustomData($customData);
                    foreach ($customData as $key => $value) {
                        CustomData::SetCustomData($user->Id, $key, $value);
                    }
                    
                    // Set Custom Data for App values
                    $appCustomData = "{}";
                    if (isset($WS_REQUEST["AppCustomData"])) {
                        $appCustomData = $WS_REQUEST["AppCustomData"];
                    }
                    if (empty($appCustomData)) {
                        $appCustomData = "{}";
                    }
                    $appCustomData = json_decode($appCustomData, TRUE);
                    cleanIncomingCustomData($appCustomData);
                    foreach ($appCustomData as $key => $value) {
                        AppCustomData::SetCustomData($AppId->Id, $user->Id, $key, $value);
                    }
                    
                    // Notify the addons
                    AddonModule::NotifyUserCreate($user);
                    
                    $message = $user->ToJsonFiltered();
                    
                    // Send the activation code to email
                    if ($user->ActivationCode && defined("REGISTER_EMAIL_MESSAGE") && @file_exists(EMAIL_TEMPLATES_FOLDER . REGISTER_EMAIL_MESSAGE)) {
                        $mailMessage = @file_get_contents(EMAIL_TEMPLATES_FOLDER . REGISTER_EMAIL_MESSAGE);
                        if ($mailMessage) {
                            $urlActivation = Utils::GetServerUrl("activation.php?Id=" . $user->Id . "&Code=" . urlencode($user->ActivationCode) . "&lang=" . urlencode(ErrorMessage::GetLanguage()));
                            $mailMessage = str_replace("{ACTIVATION_URL}", $urlActivation, $mailMessage);
                            $mailMessage = str_replace("{USERNAME}", (REGISTER_EMAIL_HTML ? htmlentities($user->Username, ENT_QUOTES, 'UTF-8') : $user->Username), $mailMessage);
                            $mail = new Mail();
                            $mail->prepare(REGISTER_EMAIL_SUBJECT, $mailMessage, $user->Email, EMAIL_SENDER_ADDRESS, EMAIL_SENDER_NAME);
                            $mail->IsHTML(REGISTER_EMAIL_HTML);
                            $mail->Send();
                        }
                    }
                    
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_USERNAME_PASSWORD);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Load one or more accounts
 */
function wsLoad() {
    global $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (isset($WS_REQUEST["Ids"]) || isset($WS_REQUEST["Usernames"])) {
        $message = array();
        if (isset($WS_REQUEST["Ids"])) {
            $users = Account::LoadIds(explode(",", trim($WS_REQUEST["Ids"])));
        } else {
            $users = Account::LoadUsernames(explode(",", trim($WS_REQUEST["Usernames"])));
        }
        foreach ($users as $i) {
            $message[] = $i->ToArrayFiltered();
        }
        $success = TRUE;
        $message = json_encode($message);
    } else {
        $idUser = (isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0);
        $username = (isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "");
        $user = new Account($idUser > 0 ? $idUser : $username);
        if ($user->Id > 0) {
            $success = TRUE;
            if ($success) {
                $message = $user->ToJsonFiltered();
            }
        } else {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        }
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Update the data of the logged user
 * @param array[string] $WS_REQUEST API request
 * @param Combu\AppId $AppId Description
 */
function wsUpdate () {
    global $WS_REQUEST, $AppId;
    $success = FALSE;
    $message = "";
    $idUser = (isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0);
    $username = (isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "");
    $user = new Account($idUser > 0 ? $idUser : $username);
    if ($user->Id > 0) {
        $changedUsername = FALSE;
        if (isset($WS_REQUEST["Username"]) && $WS_REQUEST["Username"] != $user->Username) {
            $user->Username = $WS_REQUEST["Username"];
            $changedUsername = TRUE;
        }
        if (isset($WS_REQUEST["Email"])) {
            $user->Email = $WS_REQUEST["Email"];
        }
        if (isset($WS_REQUEST["FacebookId"])) {
            $user->FacebookId = $WS_REQUEST["FacebookId"];
        }
        if (isset($WS_REQUEST["GameCenterId"])) {
            $user->GameCenterId = $WS_REQUEST["GameCenterId"];
        }
        if ($changedUsername && defined("GUEST_PREFIX") && !empty(GUEST_PREFIX) && Utils::StartsWith($user->Username, GUEST_PREFIX, TRUE)) {
            $message = ErrorMessage::Get(ERROR_USER_USERNAME_RESERVED);
        } else if ($changedUsername && $user->ExistsUsername()) {
            $message = ErrorMessage::Get(ERROR_USER_USERNAME_EXISTS);
        } else if ($user->Save()) {
            
            // Set Custom Data values
            $customData = "{}";
            if (isset($WS_REQUEST["CustomData"])) {
                $customData = $WS_REQUEST["CustomData"];
            }
            if (empty($customData)) {
                $customData = "{}";
            }
            $customData = json_decode($customData, TRUE);
            cleanIncomingCustomData($customData);
            foreach ($customData as $key => $value) {
                CustomData::SetCustomData($user->Id, $key, $value);
            }
            
            // Set Custom Data for App values
            $appCustomData = "{}";
            if (isset($WS_REQUEST["AppCustomData"])) {
                $appCustomData = $WS_REQUEST["AppCustomData"];
            }
            if (empty($appCustomData)) {
                $appCustomData = "{}";
            }
            $appCustomData = json_decode($appCustomData, TRUE);
            cleanIncomingCustomData($appCustomData);
            foreach ($appCustomData as $key => $value) {
                AppCustomData::SetCustomData($AppId->Id, $user->Id, $key, $value);
            }

            // Notify the addons
            AddonModule::NotifyUserUpdate($user);
            
            // Assign the result
            $success = TRUE;
            $message = $user->ToJsonFiltered();
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Checks whether a user exists
 */
function wsUserExists() {
    global $WS_REQUEST;
    $success = FALSE;
    $message = "";
    // Get the user data from request
    $user = new Account();
    if (isset($WS_REQUEST["Username"]))
        $user->Username = $WS_REQUEST["Username"];
    if (isset($WS_REQUEST["Email"]))
        $user->Email = $WS_REQUEST["Email"];
    // Check data consistency
    if (!$user->Username && !$user->Email) {
        $message = ErrorMessage::Get(ERROR_USER_USERNAME_EMAIL);
    } else {
        $success = TRUE;
        $message = FALSE;
        // Verify existing user
        if ($user->Username && $user->ExistsUsername())
            $message = TRUE;
        if ($user->Email && $user->ExistsEmail())
            $message = TRUE;
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Delete a user
 */
function wsDelete() {
    global $WS_REQUEST;
    $username = (isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "");
    $password = (isset($WS_REQUEST["Password"]) ? trim($WS_REQUEST["Password"]) : "");
    $user = NULL;
    // Verify the credentials
    $success = FALSE;
    $message = "";
    if (Account::CheckLogin($username, $password, $user)) {
        // Delete this user
        if ($user->Delete()) {
            $success = TRUE;

            // Notify the addons
            AddonModule::NotifyUserDelete($user);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_LOGIN_INVALID_CREDENTIALS);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Reset the password of a user
 * @global Account $LoggedAccount
 */
function wsResetPassword() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    // If the user isn't logged in, then check for Change Password Code passed
    if ($LoggedAccount->IsLogged()) {
        $message = "User is already logged in";
    } else {
        $id = (isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0);
        $username = ($id <= 0 && isset($WS_REQUEST["Username"]) ? $WS_REQUEST["Username"] : "" );
        $user = new Account($id > 0 ? $id : $username);
        if ($user->Id < 1) {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        } else if (!$user->Email) {
            $message = ErrorMessage::Get(ERROR_RESET_PWD_NO_EMAIL);
        } else {
            $user->ChangePwdCode = Utils::GenerateRandomCode();
            if ($user->Save()) {
                $success = TRUE;
                if (defined("RESETPWD_EMAIL_MESSAGE") && @file_exists(EMAIL_TEMPLATES_FOLDER . RESETPWD_EMAIL_MESSAGE)) {
                    $mailMessage = @file_get_contents(EMAIL_TEMPLATES_FOLDER . RESETPWD_EMAIL_MESSAGE);
                    if ($mailMessage) {
                        $mailMessage = str_replace("{CODE}", $user->ChangePwdCode, $mailMessage);
                        $mailMessage = str_replace("{USERNAME}", (REGISTER_EMAIL_HTML ? htmlentities($user->Username, ENT_QUOTES, 'UTF-8') : $user->Username), $mailMessage);
                        $mail = new Mail();
                        $mail->prepare(RESETPWD_EMAIL_SUBJECT, $mailMessage, $user->Email, EMAIL_SENDER_ADDRESS, EMAIL_SENDER_NAME);
                        $mail->IsHTML(REGISTER_EMAIL_HTML);
                        $mail->Send();
                    }
                }
            } else {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        }
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Change the password of a user
 * @global Account $LoggedAccount
 */
function wsChangePassword() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    // If the user isn't logged in, then check for Change Password Code passed
    if (!$LoggedAccount->IsLogged()) {
        $id = (isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0);
        $code = (isset($WS_REQUEST["Code"]) ? $WS_REQUEST["Code"] : "");
        $username = ($id <= 0 && isset($WS_REQUEST["Username"]) ? $WS_REQUEST["Username"] : "" );
        //$LoggedAccount = new Account($id);
        $LoggedAccount = new Account($id > 0 ? $id : $username);
        if ($LoggedAccount->Id < 1) {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        } else if ($LoggedAccount->ChangePwdCode != $code) {
            $message = ErrorMessage::Get(ERROR_CHANGE_PWD_CODE);
        }
    }
    if (!$message) {
        if ($LoggedAccount->IsLogged()) {
            // Change the current password
            if (isset($WS_REQUEST["Password"]) && strlen($WS_REQUEST["Password"]) > 0) {
                $noData = FALSE;
                $newPassword = $WS_REQUEST["Password"];
                $success = $LoggedAccount->ChangePassword($newPassword);
                // Remove the change password code
                if ($success) {
                    $LoggedAccount->ChangePwdCode = "";
                    $LoggedAccount->Save();
                }
            } else {
                $message = ErrorMessage::Get(ERROR_CHANGE_PWD_PASSWORD);
            }
            // Assign the result
            if ($success)
                $message = $LoggedAccount->ToJsonFiltered();
        } else {
            $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
        }
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Get the list of associative arrays for custom search fields
 * @param [string,string] $customData
 * @return string
 */
function getSearchCustomData ($customData) {
    $searchCustomData = array();
    foreach ($customData as $search_row) {
        if (!is_array($search_row))
            continue;
        $search = array(
            "key" => $search_row["key"],
            "value" => $search_row["value"]
        );
        // Check for allowed operators
        $allow_ops = array( "=", "!", "%", ">", ">=", "<", "<=" );
        if (!in_array($search_row["op"], $allow_ops))
            continue;
        switch ($search_row["op"]) {
            case "!": // Disequal
                $search_row["op"] = "<>";
                break;
            case "%": // Like
                $search_row["op"] = "REGEXP";
                break;
        }
        $search["op"] = $search_row["op"];
        $searchCustomData[] = $search;
    }
    return $searchCustomData;
}

/**
 * Load a list of random users
 * @global Account $LoggedAccount
 */
function wsRandomList() {
    global $LoggedAccount, $WS_REQUEST;
    $rows = array();
    if ($LoggedAccount->IsLogged()) {
        $limit = (isset($WS_REQUEST["Count"]) ? intval($WS_REQUEST["Count"]) : 0);
        if ($limit < 1)
            $limit = 5;
        
        // Build the filter by CustomData
        $customData = "[]";
        if (isset($WS_REQUEST["CustomData"]))
            $customData = $WS_REQUEST["CustomData"];
        $customData = json_decode($customData, TRUE);
        $searchCustomData = getSearchCustomData($customData);

        $users = Account::LoadRandom($LoggedAccount->Id, $searchCustomData, $limit);
        foreach ($users as $user) {
            $rows[] = $user->ToArrayFiltered();
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($rows, count($rows), 1), FALSE, TRUE );
}

/**
 * Search for users
 */
function wsSearch() {
    global $WS_REQUEST, $AppId;
    $limit = (isset($WS_REQUEST["Limit"]) && intval($WS_REQUEST["Limit"]) > 0 ? intval($WS_REQUEST["Limit"]) : NULL);
    $page = (isset($WS_REQUEST["Page"]) && intval($WS_REQUEST["Page"]) > 0 ? intval($WS_REQUEST["Page"]) : 1);
    $username = (isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "");
    $email = (isset($WS_REQUEST["Email"]) ? trim($WS_REQUEST["Email"]) : "");
    $isOnline = (isset($WS_REQUEST["Online"]) && $WS_REQUEST["Online"] == 1 );
    
    // Build the filter by Custom Data
    $customData = "[]";
    if (isset($WS_REQUEST["CustomData"])) {
        $customData = $WS_REQUEST["CustomData"];
    }
    $customData = json_decode($customData, TRUE);
    $searchCustomData = getSearchCustomData($customData);
    
    // Build the filter by Custom Data for App
    $appCustomData = "[]";
    if (isset($WS_REQUEST["AppCustomData"])) {
        $appCustomData = $WS_REQUEST["AppCustomData"];
    }
    if (empty($appCustomData)) {
        $appCustomData = "[]";
    }
    $appCustomData = json_decode($appCustomData, TRUE);
    $searchAppCustomData = getSearchCustomData($appCustomData);
    
    $offset = ($limit === NULL ? NULL : Utils::GetPageOffset($page, $limit));
    $count = 0;
    $users = Account::Load($username, $email, $searchCustomData, $searchAppCustomData, $isOnline, $limit, $offset, $count);
    $rows = array();
    foreach ($users as $user) {
        $rows[] = $user->ToArrayFiltered();
    }
    
    $pagesCount = ($limit === NULL ? 1 : Utils::GetPagesCount($count, $limit));
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($rows, $count, $pagesCount), FALSE, TRUE );
}

/**
 * Search for users linked to a platform
 */
function wsSearchPlatform() {
    global $WS_REQUEST;
    $platformKeys = explode(",", (isset($WS_REQUEST["PlatformKeys"]) ? trim($WS_REQUEST["PlatformKeys"]) : ""));
    $platformIds = explode(",", (isset($WS_REQUEST["PlatformIds"]) ? trim($WS_REQUEST["PlatformIds"]) : ""));
    $rows = array();
    if (count($platformKeys) == count($platformIds)) {
        for ($i = 0; $i < count($platformKeys); ++$i) {
            if ($platformKeys[$i] && $platformIds[$i]) {
                $account = Account_Platform::LoadAccount($platformKeys[$i], $platformIds[$i]);
                if ($account) {
                    $rows[] = $account->ToArrayFiltered();
                }
            }
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($rows, count($rows)), FALSE, TRUE );
}

/**
 * Create a user guest with random username
 */
function wsCreateGuest() {
    global $WS_REQUEST;
    // Fill a new object from the REQUEST parameters (must match with class public vars)
    $user = NULL;
    $prefix = (defined("GUEST_PREFIX") ? GUEST_PREFIX : "");
    if (!$prefix)
        $prefix = "Guest-";
    $success = Account::CreateRandom($prefix, $user);
    if (isset($WS_REQUEST["Username"]))
        unset($WS_REQUEST["Username"]);
    Utils::FillObjectFromRow($user, $WS_REQUEST);
    if ($success && $user->Username) {
        if ($user->ExistsUsername()) {
            $message = ErrorMessage::Get(ERROR_USER_USERNAME_EXISTS);
        } else {
            $proceed = TRUE;
            $isEmailRequired = (defined("REGISTER_EMAIL_REQUIRED_FOR_GUEST") && REGISTER_EMAIL_REQUIRED_FOR_GUEST === TRUE);
            if ($isEmailRequired) {
                $proceed = FALSE;
                if (!($user->Email && Utils::IsValidEmail($user->Email)))
                    $message = ErrorMessage::Get(ERROR_USER_EMAIL_INVALID);
                else
                    $proceed = TRUE;
            }
            if ($proceed && $user->Email && !REGISTER_EMAIL_MULTIPLE && $user->ExistsEmail()) {
                $message = ErrorMessage::Get(ERROR_USER_EMAIL_EXISTS);
                $proceed = FALSE;
            }
            if (!$proceed) {
                $success = FALSE;
            } else {
                $user->Password = md5($user->Password);
                $user->Enabled = 1;
                // Set an activation code if required by settings
                if ($isEmailRequired && defined("REGISTER_EMAIL_ACTIVATION") && REGISTER_EMAIL_ACTIVATION === TRUE) {
                    $user->ActivationCode = Utils::GenerateRandomCode();
                }
                $success = $user->Save();
                if ($success) {
                    Account::SetSession($user);
                    
                    // Save custom data
                    $customData = "{}";
                    if (isset($WS_REQUEST["CustomData"]))
                    	$customData = $WS_REQUEST["CustomData"];
                    $customData = json_decode($customData, TRUE);
                    foreach ($customData as $key => $value) {
                        $newData = new CustomData();
                        $newData->IdAccount = $user->Id;
                        $newData->DataKey = $key;
                        $newData->DataValue = $value;
                        $newData->Save();
                    }
                    
                    // Set Custom Data for App values
                    $appCustomData = "{}";
                    if (isset($WS_REQUEST["AppCustomData"])) {
                        $appCustomData = $WS_REQUEST["AppCustomData"];
                    }
                    if (empty($appCustomData)) {
                        $appCustomData = "{}";
                    }
                    $appCustomData = json_decode($appCustomData, TRUE);
                    cleanIncomingCustomData($appCustomData);
                    foreach ($appCustomData as $key => $value) {
                        AppCustomData::SetCustomData($AppId->Id, $user->Id, $key, $value);
                    }
                    
                    // Notify the addons
                    AddonModule::NotifyUserCreate($user);
                    
                    $message = $user->ToJsonFiltered();
                    
                    // Send the activation code to email
                    if ($user->ActivationCode && defined("REGISTER_EMAIL_MESSAGE") && @file_exists(EMAIL_TEMPLATES_FOLDER . REGISTER_EMAIL_MESSAGE)) {
                        $mailMessage = @file_get_contents(EMAIL_TEMPLATES_FOLDER . REGISTER_EMAIL_MESSAGE);
                        if ($mailMessage) {
                            $urlActivation = Utils::GetServerUrl("activation.php?Id=" . $user->Id . "&Code=" . urlencode($user->ActivationCode) . "&lang=" . urlencode(ErrorMessage::GetLanguage()));
                            $mailMessage = str_replace("{ACTIVATION_URL}", $urlActivation, $mailMessage);
                            $mailMessage = str_replace("{USERNAME}", (REGISTER_EMAIL_HTML ? htmlentities($user->Username, ENT_QUOTES, 'UTF-8') : $user->Username), $mailMessage);
                            $mail = new Mail();
                            $mail->prepare(REGISTER_EMAIL_SUBJECT, $mailMessage, $user->Email, EMAIL_SENDER_ADDRESS, EMAIL_SENDER_NAME);
                            $mail->IsHTML(REGISTER_EMAIL_HTML);
                            $mail->Send();
                        }
                    }
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_USERNAME_PASSWORD);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}
