<?php

include_once "lib/api.php";

use Combu\ErrorMessage;
use Combu\Account;

$id = intval(filter_input(INPUT_GET, "Id"));
$code = filter_input(INPUT_GET, "Code");

if ($id > 0 && $code) {
    $user = new Account($id);
    if ($user->Id > 0) {
        if ($user->ActivationCode === $code) {
            $user->ActivationCode = "";
            echo $user->Save() ? ErrorMessage::Get(ERROR_ACTIVATION_ACTIVATED) : ErrorMessage::Get(ERROR_ACTIVATION_FAILED);
        } else {
            echo ErrorMessage::Get(ERROR_ACTIVATION_EXPIRED);
        }
    }
}

$Database->CloseConnection();
