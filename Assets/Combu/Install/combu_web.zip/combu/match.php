<?php

include_once './lib/api.php';

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\DataClass;
use Combu\Account;
use Combu\GameMatch;
use Combu\GameMatch_CustomData;
use Combu\GameMatch_Account;
use Combu\GameMatch_Round;
use Combu\Tournament;
use Combu\Tournament_CustomData;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {
        
        case "tournament_list":
            wsTournamentList();
            break;
        
        case "tournament_load":
            wsTournamentLoad();
            break;
        
        case "tournament_save":
            wsTournamentSave();
            break;
        
        case "tournament_delete":
            wsTournamentDelete();
            break;
        
        case "tournament_leave":
            wsTournamentLeave();
            break;

        case "match_list":
            wsMatchList();
            break;
        
        case "match_load":
            wsMatchLoad();
            break;
        
        case "match_score":
            wsMatchScore();
            break;
        
        case "match_save":
            wsMatchSave();
            break;
        
        case "match_quick":
            wsMatchQuick();
            break;
        
        case "match_delete":
            wsMatchDelete();
            break;
        
    }
}
$Database->CloseConnection();
exit();

/**
 * Load the Tournaments list for the logged account
 * @global Account $LoggedAccount
 */
function wsTournamentList() {
    global $LoggedAccount, $WS_REQUEST;
    $rows = array();
    if ($LoggedAccount->IsLogged()) {
        $finished = (!isset($WS_REQUEST["Finished"]) ? NULL : intval($WS_REQUEST["Finished"]));
    
        // Build the filter by CustomData
        $customData = "[]";
        if (isset($WS_REQUEST["CustomData"]))
            $customData = $WS_REQUEST["CustomData"];
        $customData = json_decode($customData, TRUE);
        $searchCustomData = array();
        foreach ($customData as $search_row) {
            if (!is_array($search_row))
                continue;
            $search = array(
                "key" => $search_row["key"],
                "value" => $search_row["value"]
            );
            // Check for allowed operators
            $allow_ops = array( "=", "!", "%", ">", ">=", "<", "<=" );
            if (!in_array($search_row["op"], $allow_ops))
                continue;
            switch ($search_row["op"]) {
                case "!": // Disequal
                    $search_row["op"] = "<>";
                    break;
                case "%": // Like
                    $search_row["op"] = "REGEXP";
                    break;
            }
            $search["op"] = $search_row["op"];
            $searchCustomData[] = $search;
        }
        
        $records = Tournament::Load($finished, NULL, $searchCustomData);
        foreach ($records as $r) {
            $rows[] = $r->ToArray();
        }
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($rows, count($rows)), FALSE, TRUE);
}

/**
 * Load a Tournament
 * @global Account $LoggedAccount
 */
function wsTournamentLoad() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {
        $record = new Tournament( isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0 );
        if ($record->Id > 0) {
            $success = TRUE;
            $message = $record->ToJson();
        } else {
            $message = ErrorMessage::Get(ERROR_TOURNAMENT_INVALID);
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Save a Tournament
 * @global Account $LoggedAccount
 */
function wsTournamentSave() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {

        $isNew = FALSE;
        $record = new Tournament($WS_REQUEST);
        if ($record->Id < 1) {
            $isNew = TRUE;
            $record->IdOwner = $LoggedAccount->Id;
        }
        if ($record->Save()) {

            // Save the Tournament Custom Data
            $customData = "{}";
            if (isset($WS_REQUEST["CustomData"]))
                $customData = $WS_REQUEST["CustomData"];
            $customData = json_decode($customData, TRUE);
            foreach ($customData as $key => $value) {
                $noData = FALSE;
                $newData = new Tournament_CustomData();
                $newData->IdTournament = $record->Id;
                $newData->DataKey = $key;
                $newData->DataValue = $value;
                $newData->Save();
            }
            
            if ($isNew) {
                // Save the Matches
                $matches = 0;
                $matches_request = "[]";
                if (isset($WS_REQUEST["Matches"]))
                    $matches_request = $WS_REQUEST["Matches"];
                $matches_request = json_decode($matches_request);
                foreach ($matches_request as $m) {
                    
                    $m = Utils::ObjectToArray($m);
                    $match = new GameMatch($m);
                    $match->IdTournament = $record->Id;
                    if ($match->Save()) {
                        $matches++;
                        // Save the Match Custom Data
                        $matchData = array();
                        if (isset($m["CustomData"]))
                            $matchData = json_decode($m["CustomData"], TRUE);
                        foreach ($customData as $key => $value) {
                            $noData = FALSE;
                            $newData = new GameMatch_CustomData();
                            $newData->IdMatch = $match->Id;
                            $newData->DataKey = $key;
                            $newData->DataValue = $value;
                            $newData->Save();
                        }
                        // Save the Accounts
                        $usersData = array();
                        if (isset($m["Users"]))
                            $usersData = $m["Users"];
                        foreach ($usersData as $userData) {
                            $user = new Account($userData);
                            if ($user->Id > 0) {
                                $matchAccount = new GameMatch_Account();
                                $matchAccount->IdMatch = $match->Id;
                                $matchAccount->IdAccount = $user->Id;
                                if ($matchAccount->Save()) {
                                    $matchRound = new GameMatch_Round();
                                    $matchRound->IdMatchAccount = $matchAccount->Id;
                                    $matchRound->Save();
                                }
                            }
                        }
                    }
                }
            }

            $success = TRUE;
            $message = $record->ToJson();
            
        } else {
            $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
        }
    }
    
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Delete a Tournament
 * @global Account $LoggedAccount
 */
function wsTournamentDelete() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {
        $record = new Tournament( !isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]) );
        if ($record->Id < 1 || $record->IdOwner != $LoggedAccount->Id) {
            $message = ErrorMessage::Get(ERROR_TOURNAMENT_INVALID);
        } else if ($record->Delete()) {
            $success = TRUE;
        } else {
            $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Removes a user from Tournament
 * @global Account $LoggedAccount
 */
function wsTournamentLeave() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {
        $id = ( isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0 );
        $tournament = new Tournament($id);
        if ($tournament->Id < 1) {
            $message = ErrorMessage::Get(ERROR_TOURNAMENT_INVALID);
        } else {
            $idUser = ( isset($WS_REQUEST["User"]) ? intval($WS_REQUEST["User"]) : $LoggedAccount );
            $username = ( isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "" );
            $user = new Account( $idUser > 0 ? $idUser : $username );
            if ($user->Id > 0) {
                $matchAccounts = GameMatch_Account::Load($tournament->Id, $user->Id);
                if (count($matchAccounts) > 0) {
                    foreach ($matchAccount as $matchAccount) {
                        // Delete the record Match-Account
                        $match = new GameMatch($matchAccount->IdMatch);
                        $matchAccount->Delete();
                        // Delete the Match if it contains only one user
                        if (DataClass::CountRecords(DataClass::GetTableName(GameMatch_Account::class), sprintf("(IdMatch = %d)", $match->Id)) < 2) {
                            $match->Delete();
                        }
                    }
                    $success = TRUE;
                    $message = $tournament->ToJson();
                }
            }
            if (!$success) {
                $message = ErrorMessage::Get(ERROR_USER_INVALID);
            }
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Load the Matches list for the logged account
 * @global Account $LoggedAccount
 */
function wsMatchList() {
    global $LoggedAccount, $WS_REQUEST;
    $rows = array();
    if ($LoggedAccount->IsLogged()) {
        
        $idTournament = (isset($WS_REQUEST["IdTournament"]) ? intval($WS_REQUEST["IdTournament"]) : 0);
        $activeOnly = (isset($WS_REQUEST["Active"]) ? ($WS_REQUEST["Active"] === "1") : TRUE);
        $title = (isset($WS_REQUEST["Title"]) ? trim($WS_REQUEST["Title"]) : NULL);
        
        // Build the filter by CustomData
        $customData = "[]";
        if (isset($WS_REQUEST["CustomData"]))
            $customData = $WS_REQUEST["CustomData"];
        $customData = json_decode($customData, TRUE);
        $searchCustomData = array();
        foreach ($customData as $search_row) {
            if (!is_array($search_row))
                continue;
            $search = array(
                "key" => $search_row["key"],
                "value" => $search_row["value"]
            );
            // Check for allowed operators
            $allow_ops = array( "=", "!", "%", ">", ">=", "<", "<=" );
            if (!in_array($search_row["op"], $allow_ops))
                continue;
            switch ($search_row["op"]) {
                case "!": // Disequal
                    $search_row["op"] = "<>";
                    break;
                case "%": // Like
                    $search_row["op"] = "REGEXP";
                    break;
            }
            $search["op"] = $search_row["op"];
            $searchCustomData[] = $search;
        }
        
        $records = GameMatch::Load($idTournament > 0 ? $idTournament : -1, $LoggedAccount->Id, $activeOnly, $title, $searchCustomData);
        foreach ($records as $r) {
            $rows[] = $r->ToArray();
        }
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($rows, count($rows)), FALSE, TRUE);
}

/**
 * Get a Match
 * @global Account $LoggedAccount
 */
function wsMatchLoad() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {
        $match = new GameMatch( isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0 );
        if ($match->Id > 0) {
            // Verify that the logged user is a player of the match
            if (DataClass::CountRecords(DataClass::GetTableName(GameMatch_Account::class), sprintf("IdMatch = %d AND IdAccount = %d", $match->Id, $LoggedAccount->Id)) > 0) {
                $success = TRUE;
                $message = $match->ToJson();
            }
        }
        if (!$success) {
            $message = ErrorMessage::Get(ERROR_GAMEMATCH_INVALID);
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Send a score for a match
 * @global Account $LoggedAccount
 */
function wsMatchScore() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {
        $matchRound = new GameMatch_Round( isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0 );
        $matchAccount = new GameMatch_Account($matchRound->Id);
        if ($matchRound->Id > 0 && $matchAccount->Id > 0) {
            
            if ($matchRound->DateScore) {
                $message = ErrorMessage::Get(ERROR_GAMEMATCH_SCORE_EXISTS);
            } else {
                $matchRound->DateScore = date("Y-m-d H:i:s");
                $matchRound->Score = ( isset($WS_REQUEST["Score"]) ? floatval($WS_REQUEST["Score"]) : 0 );
                if ($matchRound->Save()) {
                    $customData = "{}";
                    if (isset($WS_REQUEST["CustomData"]))
                        $customData = $WS_REQUEST["CustomData"];

                    $matchAccount->CustomData = $customData;
                    $matchAccount->Save();
                    
                    $success = TRUE;
                    $message = $matchAccount->ToJson();
                    
                    // Check if it's the latest score of the round
                    $match = new GameMatch($matchAccount->IdMatch);
                    $match->CheckFinished();
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
            
        } else {
            $message = ErrorMessage::Get(ERROR_GAMEMATCH_INVALID);
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Save a Match
 * @global Account $LoggedAccount
 */
function wsMatchSave() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {
        $match = new GameMatch($WS_REQUEST);
        if ($match->Id < 1 && isset($WS_REQUEST["Id"]) && intval($WS_REQUEST["Id"]) > 0) {
            $message = ErrorMessage::Get(ERROR_GAMEMATCH_INVALID);
        } else {
            if ($match->Save()) {
                $success = TRUE;
                
                // Save the Match Custom Data
                $customData = "{}";
                if (isset($WS_REQUEST["CustomData"]))
                    $customData = $WS_REQUEST["CustomData"];
                $customData = json_decode($customData, TRUE);
                foreach ($customData as $key => $value) {
                    $noData = FALSE;
                    $newData = new GameMatch_CustomData();
                    $newData->IdMatch = $match->Id;
                    $newData->DataKey = $key;
                    $newData->DataValue = $value;
                    $newData->Save();
                }
                
                // Save the new users
                $users_request = "[]";
                if (isset($WS_REQUEST["Users"]))
                    $users_request = $WS_REQUEST["Users"];
                $users_request = json_decode($users_request);
                foreach ($users_request as $userId) {
                    $account = new Account(intval($userId));
                    if ($account->Id > 0) {
                        $matchAccount = new GameMatch_Account();
                        $matchAccount->IdMatch = $match->Id;
                        $matchAccount->IdAccount = $account->Id;
                        if ($matchAccount->Save()) {
                            $matchRound = new GameMatch_Round();
                            $matchRound->IdMatchAccount = $matchAccount->Id;
                            $matchRound->Save();
                        }
                    }
                }
                
                // Remove the deleted users
                $users_request = "[]";
                if (isset($WS_REQUEST["DeleteUsers"]))
                    $users_request = $WS_REQUEST["DeleteUsers"];
                $users_request = json_decode($users_request);
                foreach ($users_request as $matchAccountId) {
                    $matchAccount = new GameMatch_Account(intval($matchAccountId));
                    $matchAccount->Delete();
                }
                
                $message = $match->ToJson();
            } else {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Creates a Quick Match between logged account and a random user
 * @global Account $LoggedAccount
 */
function wsMatchQuick() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {
        $friendsOnly = (isset($WS_REQUEST["Friends"]) ? ($WS_REQUEST["Friends"] === "1") : FALSE);
        $rounds = (isset($WS_REQUEST["Rounds"]) ? intval($WS_REQUEST["Rounds"]) : 1);
        
        // Build the filter by CustomData
        $customData = "[]";
        if (isset($WS_REQUEST["CustomData"]))
            $customData = $WS_REQUEST["CustomData"];
        $customData = json_decode($customData, TRUE);
        $searchCustomData = array();
        foreach ($customData as $search_row) {
            if (!is_array($search_row))
                continue;
            $search = array(
                "key" => $search_row["key"],
                "value" => $search_row["value"]
            );
            // Check for allowed operators
            $allow_ops = array( "=", "!", "%", ">", ">=", "<", "<=" );
            if (!in_array($search_row["op"], $allow_ops))
                continue;
            switch ($search_row["op"]) {
                case "!": // Disequal
                    $search_row["op"] = "<>";
                    break;
                case "%": // Like
                    $search_row["op"] = "REGEXP";
                    break;
            }
            $search["op"] = $search_row["op"];
            $searchCustomData[] = $search;
        }
        
        if ($rounds < 1)
            $rounds = 1;
        if ($friendsOnly)
            $recs = Account::LoadRandomFriends($LoggedAccount->Id, array(), $searchCustomData, 1);
        else
            $recs = Account::LoadRandom($LoggedAccount->Id, $searchCustomData, 1);
        if (count($recs) > 0) {
            $other = $recs[0];
            $match = new GameMatch();
            $match->Rounds = $rounds;
            if ($match->Save()) {
                
                // Save the users
                $userIds = array( $LoggedAccount->Id, $other->Id );
                $dir = 1;
                for ($i = 1; $i <= $rounds; ++$i) {
                    foreach ($userIds as $idUser) {
                        $matchAccount = new GameMatch_Account();
                        $matchAccount->IdMatch = $match->Id;
                        $matchAccount->IdAccount = $idUser;
                        if ($matchAccount->Save()) {
                            $matchRound = new GameMatch_Round();
                            $matchRound->IdMatchAccount = $matchAccount->Id;
                            $matchRound->Save();
                        }
                    }
                    $user1 = $userIds[0];
                    $user2 = $userIds[1];
                    $userIds[0] = $user2;
                    $userIds[1] = $user1;
                }
                
                if (DataClass::CountRecords(DataClass::GetTableName(GameMatch_Account::class), "IdMatch = " . $match->Id) > 1) {
                    $success = TRUE;
                    $message = $match->ToJson();
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                    $match->Delete();
                }
                
            } else {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        } else {
            $message = ErrorMessage::Get(ERROR_GAMEMATCH_NO_USERS);
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}

/**
 * Delete a Match
 * @global Account $LoggedAccount
 */
function wsMatchDelete() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if (!$LoggedAccount->IsLogged()) {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    } else {
        $record = new GameMatch( !isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]) );
        if ($record->Id > 0)
            $matchAccount = GameMatch_Account::Load($record->Id, $LoggedAccount->Id);
        else
            $matchAccount = array();
        if (count($matchAccount) == 0) {
            $message = ErrorMessage::Get(ERROR_TOURNAMENT_INVALID);
        } else if ($record->Delete()) {
            $success = TRUE;
        } else {
            $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
        }
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE);
}