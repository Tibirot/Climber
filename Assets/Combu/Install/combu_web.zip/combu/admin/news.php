<?php

include_once './common.php';

use Combu\Utils;
use Combu\News;
use Combu\AppId;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$record = (!isset($_REQUEST["Id"]) ? NULL : new News(intval($_REQUEST["Id"])));
$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Action Save
        case "save":
            if ($record) {
                Utils::FillObjectFromRequest($record);
                if (!$record->Subject)
                    $error = "Enter the Subject";
                else if (!$record->Message)
                    $error = "Enter the Message";
                else {
                    $record->IdAdminAccount = $AdminLogged->Id;
                    if ($record->Save()) {
                        // Return to list
                        Utils::RedirectTo("?saved=1");
                    } else
                        $error = "An error occurred";
                }
            }
            break;

    // Action Delete
        case "delete":
            if ($record) {
                $record->Delete();
                // Return to list
                Utils::RedirectTo("?deleted=1");
            }
            break;

    }
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

$apps = AppId::Load();

// Display list if there is no active record
if (!$record) {
    $limit = DEFAULT_LIST_LIMIT;
    $page = getRequestInput("Page", 1);
    $idApp = getRequestInput("IdApp", 0);
    $count = 0;
    $records = News::Load($idApp, $limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<?php include './header.php'; ?>

<?= printAlertDisappearSaved($saved) ?>
<?= printAlertDisappearDeleted($deleted) ?>

<?php if (!$record) { ?>

    <fieldset id="list">
        <legend>News</legend>
        
        <form method="post">
            <div class="form-group">
                <label>App Scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($idApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($idApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
                <?php } ?>
                </select>
            </div>
            <div class="field">
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                <button type="button" class="btn btn-default" onclick="document.location.href = '?';"><i class="fa fa-undo"></i> Reset</button>
                <button type="button" class="btn btn-primary float-right" onclick="document.location.href = '?Id=0';"><i class="fa fa-plus"></i> Create News</button>
            </div>
        </form>

        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="1"></th>
                    <th width="100" class="text-right">Id</th>
                    <th width="150">App</th>
                    <th width="150">Date</th>
                    <th>Subject</th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="4">No results</td></tr>'; ?>
        
        <?php foreach ($records as $record) { ?>
            <?php
            $app = new AppId($record->IdApp);
            ?>

            <tr>
                <td nowrap>
                    <button class="btn btn-danger" onclick="if (confirm('Delete this News?')) document.location.href='?action=delete&Id=<?= $record->Id ?>';" title="Delete"><i class="fa fa-trash-alt"></i></button>
                    <button class="btn btn-primary" onclick="document.location.href='?Id=<?= $record->Id ?>';" title="Edit"><i class="fa fa-edit"></i></button>
                </td>
                <td class="text-right"><?= $record->Id ?></td>
                <td><?= ($app->IsValid() ? htmlentities($app->Name) : '<span style="color:#CCC;">Any App</em>') ?></td>
                <td><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($record->PublishDate)) ?></td>
                <td><?= htmlentities($record->Subject, ENT_QUOTES, 'UTF-8') ?></td>
            </tr>

        <?php } ?>

            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="IdApp" value="<?= $idApp ?>"/>
                                <h6>
                                    <?= $count ?> result(s) in <?= $pagesCount ?> page(s)
                                </h6>
                                <div class="form-row">
                                    <div class="col-auto">
                                        <select name="Page" class="form-control">
                                        <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                            <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>>Page <?= $i ?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <input type="submit" class="btn btn-default" value="Go"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>

    </fieldset>
            
<?php } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to News</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>News Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <?php if ($record->Id > 0) { ?>
            <div class="form-group">
                <label>Id</label>
                <strong><?= $record->Id ?></strong>
                | <label>Publish date</label>
                <strong><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($record->PublishDate)) ?></strong>
                | <label>App scope</label>
                <?php
                $app = new AppId($record->IdApp);
                ?>
                <strong><?= ($app->IsValid() ? htmlentities($app->Name) : "Any App") ?></strong>
            </div>
            <?php } else { ?>
            <div class="form-group">
                <label>App scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($record->IdApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($record->IdApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
                <?php } ?>
                </select>
            </div>
            <?php } ?>
            <div class="form-group">
                <label>Subject</label>
                <input type="text" class="form-control" name="Subject" value="<?= htmlentities($record->Subject, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>Message</label>
                <textarea class="form-control" name="Message"><?= htmlentities($record->Message, ENT_QUOTES, 'UTF-8') ?></textarea>
            </div>
            <div class="form-group">
                <label>URL</label>
                <input type="text" class="form-control" name="Url" value="<?= htmlentities($record->Url, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>
    
    <script>
        $(function() {
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

<?php } ?>

<?php include './footer.php'; ?>