<?php

// test new

include_once './common.php';

use Combu\Utils;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

function getUpdaterFolder() {
    $folder = __DIR__ . "/updater";
    if (!file_exists($folder)) {
        try {
            mkdir($folder);
        } catch (Exception $ex) {
        }
    }
    return $folder;
}

function cleanFolder($folder, $includeFolders = TRUE) {
    if (!file_exists($folder)) {
        return TRUE;
    }
    if (!(is_dir($folder) && is_writable($folder))) {
        return FALSE;
    }
    $files = Utils::GetAllFiles($folder);
    foreach ($files as $f) {
        try {
            unlink($f);
        } catch (Exception $ex) {
            return FALSE;
        }
    }
    if ($includeFolders) {
        $folders = Utils::GetAllFolders($folder);
        foreach ($folders as $f) {
            cleanFolder($f);
        }
    }
    $countFolders = count(Utils::GetAllFolders($folder));
    $countFiles = count(Utils::GetAllFiles($folder));
    if ($countFolders == 0 && $countFiles == 0) {
        try {
            rmdir($folder);
        } catch (Exception $ex) {
            return FALSE;
        }
    }
    return TRUE;
}

function cleanUpdaterFolder($includeFolders = TRUE) {
    return cleanFolder(getUpdaterFolder(), $includeFolders);
}

function upgradeDatabase($sqls, &$resultSql) {
    global $Database;
    if (empty($sqls) || !is_array($sqls) || count($sqls) == 0) {
        return TRUE;
    }
    if ($Database->TransactionStart()) {
        $sql_error = FALSE;
        foreach ($sqls as $sql) {
            if (!$Database->Query($sql)) {
                $sql_error_message = 
                $resultSql .= '<div style="color:#cc0000;">[ERROR ' . htmlentities($Database->GetError()) . '] ' . $sql . '</div>';
            } else {
                $resultSql .= '<div>' . $sql . '</div>';
            }
        }
        if ($sql_error) {
            $Database->TransactionRollback();
        } else {
            $Database->TransactionCommit();
            return TRUE;
        }
    }
    return FALSE;
}

function upgradeFiles($files, &$resultFiles, &$resultUncompress) {
    if (empty($files) || !is_array($files) || count($files) == 0) {
        return;
    }
    foreach ($files as $f) {
        try {
            $content = file_get_contents($f);
            $local_file = __DIR__ . "/updater/" . basename($f);
            file_put_contents($local_file, $content);
            $uncompressed = FALSE;
            $zip = new ZipArchive;
            $res = $zip->open($local_file);
            if ($res === TRUE) {
                if ($zip->numFiles > 0 && $zip->extractTo(__DIR__ . "/updater/")) {
                    unlink($local_file);
                    $uncompressed = TRUE;
                }
                $zip->close();
            }
            $resultFiles .= '<div>' . $local_file . ($uncompressed ? " [uncompressed]" : " [could not extract]") . '</div>';
        } catch (Exception $ex) {
            $resultFiles .= '<div style="color:#cc0000;">[ERROR ' . htmlentities($ex->getMessage()) . '] ' . htmlentities($f) . '</div>';
        }
    }
    $rootCombu = __DIR__ . "/updater/combu/";
    $uncompressed_files = Utils::GetAllFiles(__DIR__ . "/updater");
    foreach ($uncompressed_files as $f) {
        if (!Utils::StartsWith($f, $rootCombu)) {
            continue;
        }
        chmod($f, 0744);
        try {
            $dest_file = substr($f, strlen($rootCombu));
            $dest_path = __DIR__ . "/../" . $dest_file;
            $errorFile = "";
            // Skip the folder _setup if not already existing on this server
            $dirSetup = __DIR__ . "/../_setup";
            $dest_folder_path = dirname($dest_path);
            if (Utils::EndsWith($dest_folder_path, DIRECTORY_SEPARATOR)) {
                $dest_folder_path = substr($dest_folder_path, 0, strlen($dest_folder_path) - 1);
            }
            if (realpath($dest_folder_path) == realpath($dirSetup) && !file_exists($dirSetup)) {
                continue;
            }
            // Overwrite existing file
            if (file_exists($dest_path)) {
                if (is_readable($dest_path)) {
                    $hash_source = hash_file("crc32b", $f);
                    if ($hash_source && hash_file("crc32b", $dest_path) === $hash_source) {
                        unlink($f);
                        $resultUncompress .= '<div style="color:#C4C4C4;">[skipped] ' . htmlentities($dest_file) . '</div>';
                        continue;
                    }
                }
                if (is_writable($dest_path)) {
                    unlink($dest_path);
                } else {
                    $errorFile = "File not writable";
                }
            } else if (!is_writable(dirname($dest_path))) {
                $errorFile = "Directory not writable";
            }
            if ($errorFile) {
                $resultUncompress .= '<div style="color:#cc0000;">[' . $errorFile . '] ' . htmlentities($dest_file) . '</div>';
            } else {
                rename($f, $dest_path);
                chmod($dest_path, 0755);
                $resultUncompress .= '<div>' . $dest_file . '</div>';
            }
        } catch (Exception $ex) {
            $resultUncompress .= '<div style="color:#cc0000;">[ERROR ' . htmlentities($ex->getMessage()) . '] ' . htmlentities($f) . '</div>';
        }
    }
    // Clean updater folder
    $folders = Utils::GetAllFolders(__DIR__ . "/updater");
    foreach ($folders as $f) {
        cleanFolder($f);
    }
    cleanUpdaterFolder(FALSE);
}

function upgradeDeletes($deletes, &$resultDelete) {
    if (empty($deletes) || !is_array($deletes) || count($deletes) == 0) {
        return;
    }
    foreach ($deletes as $f) {
        $filename = Utils::CombinePath(__DIR__ . "/../", $f);
        if (!file_exists($filename)) {
            continue;
        }
        try {
            unlink($filename);
            $resultDelete .= '<div>' . $filename . '</div>';
        } catch (Exception $ex) {
            $resultDelete .= '<div style="color:#cc0000;">[ERROR ' . htmlentities($ex->getMessage()) . '] ' . htmlentities($filename) . '</div>';
        }
    }
}

// Disable the execution time limit to allow sending large amount of mails
set_time_limit(0);

$upgradeResult = checkUpgradeAvailable();
$upgradeResult["release_notes"] = nl2br($upgradeResult["release_notes"]);

$justUpgraded = FALSE;
$upgraded = (filter_input(INPUT_GET, "upgraded") === "1");
$resultSql = filter_input(INPUT_POST, "sql");
$resultFiles = filter_input(INPUT_POST, "files");
$resultDelete = filter_input(INPUT_POST, "delete");
$resultUncompress = filter_input(INPUT_POST, "uncompress");
$error = NULL;

switch (getRequestInput("action")) {
    
    case "upgrade":
        $result = NULL;
        $success = FALSE;
        $resultSql = "";
        $resultFiles = "";
        $resultDelete = "";
        $resultUncompress = "";
        if (!isset($upgradeResult["version"])) {
            $error = "Could not retrieve the list of updates";
        } else if (!cleanUpdaterFolder()) {
            $error = "Could not clean the updater folder, please delete manually the folder <strong>" . getUpdaterFolder() . "</strong>";
        } else if (!class_exists("ZipArchive")) {
            $error = "The class <strong>ZipArchive</strong> is not supported or enabled on your system";
        } else {
            $success = TRUE;
            if (isset($upgradeResult["sql"])) {
                if (!upgradeDatabase($upgradeResult["sql"], $resultSql)) {
                    $success = FALSE;
                }
            }
            if (isset($upgradeResult["files"])) {
                upgradeFiles($upgradeResult["files"], $resultFiles, $resultUncompress);
            }
            if (isset($upgradeResult["delete"]) && count($upgradeResult["delete"]) > 0) {
                upgradeDeletes($upgradeResult["delete"], $resultDelete);
            }
            if ($success) {
                $justUpgraded = TRUE;
            }
        }
        break;
        
    default:
        if (!class_exists("ZipArchive")) {
            $error = "The class <strong>ZipArchive</strong> is not supported/enabled on your system";
        }
        break;
}

?>
<?php include './header.php'; ?>

<p>
    &LeftArrow; <a href="tools.php">Back to Tools</a>
</p>

<?php if ($justUpgraded) { ?>

<form id="formUpgrade" method="post" action="?upgraded=1">
    <input type="hidden" name="sql" value="<?= htmlentities($resultSql) ?>"/>
    <input type="hidden" name="files" value="<?= htmlentities($resultFiles) ?>"/>
    <input type="hidden" name="delete" value="<?= htmlentities($resultDelete) ?>"/>
    <input type="hidden" name="uncompress" value="<?= htmlentities($resultUncompress) ?>"/>
</form>

<script>
    $(function() {
        $("#formUpgrade").submit();
    });
</script>

<?php } else { ?>

<?= printAlertDisappear(!$upgraded ? "" : "Server was upgraded successfully") ?>
<?= printAlertError($error) ?>

<style>
    .upgrade-result {margin: 15px 0; background-color: #f4f4f4; padding: 10px;}
    .upgrade-result div {font-family: monospace; margin: 0 0 5px;}
</style>

<?php if ($upgraded) { ?>
<fieldset>
    <legend>Upgrade result</legend>
    <div>
        <?php if ($resultSql) { ?><strong>SQL statements executed</strong><div class="upgrade-result"><?= $resultSql ?></div><?php } ?>
        <?php if ($resultFiles) { ?><strong>Files downloaded</strong><div class="upgrade-result"><?= $resultFiles ?></div><?php } ?>
        <?php if ($resultDelete) { ?><strong>Files deleted</strong><div class="upgrade-result"><?= $resultDelete ?></div><?php } ?>
        <?php if ($resultUncompress) { ?><strong>Files uncompressed and moved</strong><div class="upgrade-result"><?= $resultUncompress ?></div><?php } ?>
    </div>
</fieldset>
<?php } ?>

<fieldset>
    <legend>Upgrade your server</legend>
    <div id="progress">
        Checking for updates...
    </div>
<script>
    $(function() {
        var tablePrefix = "<?= GAME_DB_PREFIX ?>";
        var upgradeResult = <?= json_encode($upgradeResult) ?>;
        
        function fixTableNames(sql) {
            if (tablePrefix != "") {
                sql = sql.replace(/CREATE TABLE `/gi, "CREATE TABLE `" + tablePrefix);
                sql = sql.replace(/ALTER TABLE `/gi, "ALTER TABLE `" + tablePrefix);
                sql = sql.replace(/DROP TABLE `/gi, "DROP TABLE `" + tablePrefix);
            }
            return sql;
        }
        
        if (upgradeResult.upgrade_required) {
            var title = "";
            var ver_details = "";
            if (upgradeResult.sql.length > 0) {
                title = "<li>Queries to execute: " + upgradeResult.sql.length + "</li>";
                ver_details += "Queries: <ul>";
                for (var i = 0; i < upgradeResult.sql.length; ++i) {
                    ver_details += '<li class="mb-2 mt-2"><samp>' + fixTableNames(upgradeResult.sql[i]) + '</samp></li>';
                }
                ver_details += "</ul>";
            }
            if (upgradeResult.files.length > 0) {
                title += "<li>Files to download: " + upgradeResult.files.length + "</li>";
                ver_details += "Files: <ul>";
                for (var i = 0; i < upgradeResult.files.length; ++i) {
                    ver_details += '<li class="mb-2 mt-2"><samp>Download <a href="' + upgradeResult.files[i] + '">' + upgradeResult.files[i] + '</a></samp></li>';
                }
                ver_details += "</ul>";
            }
            if (upgradeResult.delete.length > 0) {
                title += "<li>Files to delete: " + upgradeResult.files.length + "</li>";
            }
            var buttonShowDetail = '<button type="button" class="btn btn-info" onclick="upgradeDetails();"><i class="fa fa-info"></i> Show details</button>';
            var buttonUpgradeNow = '<button type="button" class="btn btn-success" onclick="doUpgrade();"><i class="fa fa-download"></i> Upgrade now</button>';
            $("#progress").html('<strong>New version ' + upgradeResult.version + ' available</strong>' +
                    (upgradeResult.release_notes ? '<br/><br/>' + upgradeResult.release_notes : "") +
                    '<br/><ul>' + title + '</ul><div id="version_details" style="display:none;">' + ver_details + '</div>' +
                    buttonShowDetail + ' ' + buttonUpgradeNow);
            $("#progress .button").button();
        } else {
            $("#progress").html("You have the latest or newer " + (upgradeResult.beta ? "<strong>beta</strong> " : "") + "version installed: <strong>" + upgradeResult.version + "</strong>" + (upgradeResult.release_notes ? '<br/><br/><h3>Release notes</h3><p>' + upgradeResult.release_notes : "") + '</p>');
        }
    });
    
    function doUpgrade() {
        $("#progress").text("Please wait and don't close the browser or panel...");
        document.location = "?action=upgrade";
    }
    
    function upgradeDetails() {
        $("#version_details").toggle();
    }
</script>
</fieldset>

<?php } ?>

<?php include './footer.php'; ?>