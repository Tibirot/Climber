<?php

include_once './common.php';

use Combu\Utils;
use Combu\LeaderBoard;
use Combu\LeaderBoard_User;
use Combu\AppId;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$leaderboard = (!isset($_REQUEST["Id"]) ? NULL : new LeaderBoard(intval($_REQUEST["Id"])));
$error = NULL;

/**
 * Verify the current action
 */
switch (getRequestInput("action")) {

// Action Save
    case "save":
        if ($leaderboard) {
            Utils::FillObjectFromRequest($leaderboard);
            if (!$leaderboard->Title) {
                $error = "Enter the Title";
            } else if ($leaderboard->Code && is_numeric(substr($leaderboard->Code, 0, 1))) {
                $error = "Code cannot start with a number";
            } else if ($leaderboard->Code && $leaderboard->ExistsCode()) {
                $error = "This Code is already used for another Leaderboard";
            } else {
                if ($leaderboard->Save()) {
                    // Return to list
                    Utils::RedirectTo("?saved=1");
                } else
                    $error = "An error occurred";
            }
        }
        break;

// Action Delete
    case "delete":
        if ($leaderboard) {
            $leaderboard->Delete();
            // Return to list
            Utils::RedirectTo("?deleted=1");
        }
        break;

// Action Delete Score
    case "delete_score":
        if ($leaderboard) {
            $score = new LeaderBoard_User(!isset($_REQUEST["IdScore"]) ? 0 : intval($_REQUEST["IdScore"]));
            $score->Delete();
            Utils::RedirectTo("?action=scores&Id=" . $leaderboard->Id . "&saved=1");
        }
        break;

}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

$apps = AppId::Load();

// Display list if there is no active record
if (!$leaderboard) {
    $limit = DEFAULT_LIST_LIMIT;
    $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
    $idApp = getRequestInput("IdApp", 0);
    $count = 0;
    $leaderboards = LeaderBoard::Load($idApp, $limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
} else {
    $LEADERBOARD_SCORETYPE = LeaderBoard::GetScoreTypes();
}

?>
<?php include './header.php'; ?>

<?= printAlertDisappearSaved($saved) ?>
<?= printAlertDisappearDeleted($deleted) ?>

<?php if (!$leaderboard) { ?>

    <fieldset id="list">
        <legend>Leaderboards</legend>
        
        <form method="post">
            <div class="form-group">
                <label>App Scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($idApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($idApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
                <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                <button type="button" class="btn btn-default" onclick="document.location.href = '?';"><i class="fa fa-undo"></i> Reset</button>
                <button type="button" class="btn btn-primary float-right" onclick="document.location.href = '?Id=0';"><i class="fa fa-plus"></i> Create Leaderboard</button>
            </div>
        </form>

        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="1"></th>
                    <th width="100" class="text-right">Id</th>
                    <th width="200">App</th>
                    <th>Title</th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>
        
        <?php foreach ($leaderboards as $leaderboard) { ?>
            <?php
            $app = new AppId($leaderboard->IdApp);
            ?>
                
            <tr>
                <td nowrap>
                    <button class="btn btn-danger" onclick="if (confirm('Delete this Leaderboard?')) document.location.href='?action=delete&Id=<?= $leaderboard->Id ?>';" title="Delete"><i class="fa fa-trash-alt"></i></button>
                    <button class="btn btn-primary" onclick="document.location.href='?Id=<?= $leaderboard->Id ?>';" title="Edit"><i class="fa fa-edit"></i></button>
                    <button class="btn btn-default" onclick="document.location.href='?action=scores&Id=<?= $leaderboard->Id ?>';" title="View scores"><i class="fa fa-trophy"></i></button>
                </td>
                <td class="text-right"><?= $leaderboard->Id ?></td>
                <td><?= ($app->IsValid() ? htmlentities($app->Name) : '<span style="color:#CCC;">Any App</em>') ?></td>
                <td><?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?></td>
            </tr>

        <?php } ?>

            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="IdApp" value="<?= $idApp ?>"/>
                                <h6>
                                    <?= $count ?> result(s) in <?= $pagesCount ?> page(s)
                                </h6>
                                <div class="form-row">
                                    <div class="col-auto">
                                        <select name="Page" class="form-control">
                                        <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                            <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>>Page <?= $i ?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <input type="submit" class="btn btn-default" value="Go"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>

    </fieldset>
            
<?php } else { ?>

    <?php if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "scores") { ?>

    &LeftArrow; <a href="?">Back to Leaderboards</a>

    <fieldset id="list">
        <legend>High Scores from: <?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?></legend>
        <?php
        $limit = DEFAULT_LIST_LIMIT;
        $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
        $count = 0;
        $order = "";
        $field = "";
        $leaderboard->GetOrderBy($order, $field);
        $scores = $leaderboard->LoadHighscore(LeaderBoard::HIGHSCORE_TOTAL, FALSE, FALSE, $limit, Utils::GetPageOffset($page, $limit), $count);
        $pagesCount = Utils::GetPagesCount($count, $limit);
        ?>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="100"></th>
                    <th width="100" align="right">Rank <img src="images/mapmarker.png" alt="Rank" title="Rank" /></th>
                    <th align="left">Player</th>
                    <th width="150" align="right">Score <img src="images/flag_azure.png" alt="Score" title="Score" /></th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>

        <?php foreach ($scores as $score) { ?>
        
        <?php $user = json_decode($score["User"]); ?>
            <tr>
                <td nowrap>
                    <button class="btn btn-danger" onclick="if (confirm('Delete this Score?')) document.location.href='?action=delete_score&Id=<?= $leaderboard->Id ?>&IdScore=<?= $score["Id"] ?>';" title="Delete"><i class="fa fa-trash-alt"></i></button>
                    <button class="btn btn-primary" onclick="document.location.href='users.php?Id=<?= $user->Id ?>';" title="View player"><i class="fa fa-user"></i></button>
                </td>
                <td align="right"><?= $score["Rank"] ?></td>
                <td><?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?></td>
                <td align="right"><?= $score["Score"] ?></td>
            </tr>
        <?php } ?>

            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="action" value="scores"/>
                                <input type="hidden" name="Id" value="<?= $leaderboard->Id ?>"/>
                                <h6>
                                    <?= $count ?> result(s) in <?= $pagesCount ?> page(s)
                                </h6>
                                <div class="form-row">
                                    <div class="col-auto">
                                        <select name="Page" class="form-control">
                                        <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                            <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>>Page <?= $i ?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <input type="submit" class="btn btn-default" value="Go"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>
        
    </fieldset>

    <?php } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to Leadernoards</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>Leaderboard Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <?php if ($leaderboard->Id > 0) { ?>
                <div class="form-group">
                    <label>Id:</label>
                    <strong><?= $leaderboard->Id ?></strong>
                    | <label>App scope:</label>
                    <?php
                    $app = new AppId($leaderboard->IdApp);
                    ?>
                    <strong><?= ($app->IsValid() ? htmlentities($app->Name) : "Any App") ?></strong>
                </div>
            <?php } else { ?>
            <div class="form-group">
                <label>App scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($leaderboard->IdApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($leaderboard->IdApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
                <?php } ?>
                </select>
            </div>
            <?php } ?>
            <div class="form-group">
                <label>Code</label>
                <input type="text" class="form-control" name="Code" value="<?= htmlentities($leaderboard->Code, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>Title</label>
                <input type="text" class="form-control" name="Title" value="<?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" name="Description"><?= htmlentities($leaderboard->Description, ENT_QUOTES, 'UTF-8') ?></textarea>
            </div>
            <div class="form-group">
                <label>Score Type</label>
            <?php if ($leaderboard->Id > 0) { ?>
                <input type="hidden" name="UniqueRecords" value="<?= $leaderboard->UniqueRecords ?>"/>
                <strong><?= $LEADERBOARD_SCORETYPE[$leaderboard->UniqueRecords] ?></strong>
            <?php } else { ?>
                <select class="form-control" name="UniqueRecords">
                    <option value="<?= LeaderBoard::SCORE_UNIQUE_INCREASE ?>" <?php if ($leaderboard->UniqueRecords == LeaderBoard::SCORE_UNIQUE_INCREASE) echo ' selected'; ?>><?= $LEADERBOARD_SCORETYPE[LeaderBoard::SCORE_UNIQUE_INCREASE] ?></option>
                    <option value="<?= LeaderBoard::SCORE_UNIQUE_REPLACE_HIGHER ?>" <?php if ($leaderboard->UniqueRecords == LeaderBoard::SCORE_UNIQUE_REPLACE_HIGHER) echo ' selected'; ?>><?= $LEADERBOARD_SCORETYPE[LeaderBoard::SCORE_UNIQUE_REPLACE_HIGHER] ?></option>
                    <option value="<?= LeaderBoard::SCORE_UNIQUE_REPLACE_ANY ?>" <?php if ($leaderboard->UniqueRecords == LeaderBoard::SCORE_UNIQUE_REPLACE_ANY) echo ' selected'; ?>><?= $LEADERBOARD_SCORETYPE[LeaderBoard::SCORE_UNIQUE_REPLACE_ANY] ?></option>
                    <option value="<?= LeaderBoard::SCORE_UNIQUE_NONE ?>" <?php if ($leaderboard->UniqueRecords == LeaderBoard::SCORE_UNIQUE_NONE) echo ' selected'; ?>><?= $LEADERBOARD_SCORETYPE[LeaderBoard::SCORE_UNIQUE_NONE] ?></option>
                </select>
            <?php } ?>
            </div>
            <div class="form-group">
                <label>Values Type</label>
            <?php if ($leaderboard->Id > 0) { ?>
                <input type="hidden" name="ValueType" value="<?= $leaderboard->ValueType ?>"/>
                <strong><?php
                switch ($leaderboard->ValueType) {
                case LeaderBoard::VALUE_INT:
                    echo 'Integer (e.g.: 100)';
                    break;
                case LeaderBoard::VALUE_FLOAT:
                    echo 'Float (e.g.: 0.001)';
                    break;
                }
                ?></strong>
            <?php } else { ?>
                <select class="form-control" name="ValueType">
                    <option value="<?= LeaderBoard::VALUE_INT ?>" <?php if ($leaderboard->ValueType == LeaderBoard::VALUE_INT) echo ' selected'; ?>>Integer (e.g.: 100)</option>
                    <option value="<?= LeaderBoard::VALUE_FLOAT ?>" <?php if ($leaderboard->ValueType == LeaderBoard::VALUE_FLOAT) echo ' selected'; ?>>Float (e.g.: 0.001)</option>
                </select>
            <?php } ?>
            </div>
            <div class="form-group">
                <label>Order Type</label>
                <select class="form-control" name="OrderType">
                    <option value="<?= LeaderBoard::ORDER_DESC ?>" <?php if ($leaderboard->OrderType == LeaderBoard::ORDER_DESC) echo ' selected'; ?>>Descending (e.g.: from 10 to 1)</option>
                    <option value="<?= LeaderBoard::ORDER_ASC ?>" <?php if ($leaderboard->OrderType == LeaderBoard::ORDER_ASC) echo ' selected'; ?>>Ascending (e.g.: from 1 to 10)</option>
                </select>
            </div>
            <div class="form-group">
                <label>Allow anonymous</label>
                <select class="form-control" name="AllowAnonymous">
                    <option value="0" <?php if ($leaderboard->AllowAnonymous == 0) echo ' selected'; ?>>No</option>
                    <option value="1" <?php if ($leaderboard->AllowAnonymous == 1) echo ' selected'; ?>>Yes</option>
                </select>
                <br/>* <em>Anonymous players always add new scores</em>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>
    
    <script>
        $(function() {
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

    <?php } ?>

<?php } ?>

<?php include './footer.php'; ?>