<?php

include_once './common.php';

use Combu\Utils;
use Combu\ServerSettings;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$error = NULL;

/**
 * Verify the current action
 */
switch (getRequestInput("action")) {

// Action Save
    case "save":
        $record = new ServerSettings();
        Utils::FillObjectFromRequest($record);
        if (!$record->DataKey) {
            $error = "Enter the Key";
        } else if (isset ($_REQUEST["create"]) && array_key_exists($record->DataKey, $ServerSettings)) {
            $error = "This Key is already registered";
        } else {
            if ($record->Save()) {
                // Return to list
                Utils::RedirectTo("?saved=1");
            } else
                $error = "An error occurred";
        }
        break;

// Action Delete
    case "delete":
        $record = new ServerSettings($_REQUEST, TRUE);
        if ($record->Delete()) {
            // Return to list
            Utils::RedirectTo("?deleted=1");
        } else {
            Utils::RedirectTo("?");
        }
        break;

}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

$records = ServerSettings::Load();

?>
<?php include './header.php'; ?>

<?= printAlertDisappearSaved($saved) ?>
<?= printAlertDisappearDeleted($deleted) ?>
<?= printAlertError($error) ?>

<fieldset id="list">
    <legend>Server Settings</legend>
    
    <div>
        <h4>Create a new Key</h4>
        <p>
            <form id="formNewKey" method="post">
                <input type="hidden" name="action" value="save" />
                <input type="hidden" name="create" />
                <div class="form-group">
                    <label for="textNewDataKey">Key</label>
                    <input type="text" class="form-control" name="DataKey" id="textNewDataKey" placeholder="Enter a unique value"/>
                </div>
                <div class="form-group">
                    <label for="textNewDataValue">Value</label>
                    <input type="text" class="form-control" name="DataValue" id="textNewDataValue" placeholder="Value of the new setting"/>
                </div>
                <div class="form-group">
                    <label>Visible to clients</label>
                    <select name="Visible" class="form-control">
                        <option value="1">Visible to clients</option>
                        <option value="0">Not visible to clients</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Create</button>
                </div>
            </form>
        </p>
    </div>

    <table class="table-records" width="100%">
        <thead>
            <tr>
                <th width="1"></th>
                <th width="200">Key</th>
                <th>Value</th>
            </tr>
        </thead>
        <tbody>
    <?php if (count($records) == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>

        <?php $i = 0; ?>
    <?php foreach ($records as $record) { ?>
        
        <tr>
            <form id="form-edit-<?= $i ?>" method="post">
            <input type="hidden" name="action" id="action-<?= $i ?>" value="save"/>
            <input type="hidden" name="DataKey" value="<?= htmlentities($record->DataKey) ?>"/>
            <input type="hidden" name="Visible" value="<?= $record->Visible ?>"/>
            <td nowrap>
                <button type="button" class="btn btn-danger bt-delete-key" data-id="<?= $i ?>" title="Delete"><i class="fa fa-trash-alt"></i></button>
                <button type="button" class="btn btn-primary bt-save-key" data-id="<?= $i ?>" title="Save"><i class="fa fa-save"></i></button>
            </td>
            <td><?= htmlentities($record->DataKey, ENT_QUOTES, 'UTF-8') ?><br/>[<?= ($record->Visible ? "" : "Not ") ?>Visible to clients]</td>
            <td>
            <div class="form-group">
                <select name="Visible" class="form-control">
                    <option value="0" <?php if (!$record->Visible) echo 'selected'; ?>>Not visible to clients</option>
                    <option value="1" <?php if ($record->Visible) echo 'selected'; ?>>Visible to clients</option>
                </select>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="DataValue" value="<?= htmlentities($record->DataValue, ENT_QUOTES, 'UTF-8') ?>" placeholder="Empty"/>
            </div>
            </form></td>
        </tr>
        <?php $i++; ?>

    <?php } ?>

        </tbody>
    </table>

</fieldset>

<script>
    $(function() {
        $("#formNewKey").submit(function(event) {
            if ($(this).find("input[name='DataKey']").val() == "") {
                event.preventDefault();
                alert("Enter the Key");
            }
        });
        $("button.bt-save-key").click(function(event) {
            event.preventDefault();
            toggleBusy(true);
            $("#form-edit-" + $(this).attr("data-id")).submit();
        });
        $("button.bt-delete-key").click(function(event) {
            event.preventDefault();
            if (confirm('Delete this Key?')) {
                toggleBusy(true);
                $("#action-" + $(this).attr("data-id")).val("delete");
                $("#form-edit-" + $(this).attr("data-id")).submit();
            }
        });
    });
</script>

<?php include './footer.php'; ?>