<?php

use Combu\Utils;

$existsCustomCSS = file_exists(__DIR__ . "/css/custom.css");

$scriptName = filter_input(INPUT_SERVER, "SCRIPT_NAME");

function isMenuSection($relativeUrl) {
    global $scriptName;
    return (strpos($scriptName, URL_ROOT . $relativeUrl) !== FALSE);
}

?>
<!DOCTYPE html>
<html>
    <head>
        <title>Combu - Admin Console</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="ROBOTS" content="NOINDEX, NOFOLLOW"/>
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"/>
        <link href="<?= Utils::GetServerUrl("admin/css/default.css") ?>" rel="stylesheet"/>
        <link href="<?= Utils::GetServerUrl("admin/css/jquery.datetimepicker.min.css") ?>" rel="stylesheet"/>
        <?php if ($existsCustomCSS) { ?>
        <link href="<?= Utils::GetServerUrl("admin/css/custom.css") ?>" rel="stylesheet"/>
        <?php } ?>
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
        <script src="js/tinymce/tinymce.min.js"></script>
        <script src="<?= Utils::GetServerUrl("admin/js/functions.js") ?>"></script>
        <script src="<?= Utils::GetServerUrl("admin/js/jquery.datetimepicker.min.js") ?>"></script>
        <?php if (file_exists(__DIR__ . "/js/custom.js")) { ?>
        <script src="<?= Utils::GetServerUrl("admin/js/custom.js") ?>"></script>
        <?php } ?>
    </head>
    <body>
        <div id="container" class="container-fluid">
            <div id="logo" class="row">
                <div class="col-sm-8">
                    <div class="media">
                        <a href="index.php"><img src="images/combu.png" class="mr-3" alt="Home"/></a>
                        <div class="media-body">
                            <h5 class="mt-0"><a href="index.php">Server Administration</a></h5>
                            Web administration panel of <strong>Combu</strong> server
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="content">
                        <ul>
                            <li><a href="<?= COMBU_HELP ?>" target="_blank" data-toggle="tooltip" title="Read the API documentation"><img src="images/bubble_doc.png"/></a></li>
                            <li><a href="<?= COMBU_SUPPORT ?>" target="_blank" data-toggle="tooltip" title="Get support on forum"><img src="images/bubble_forum.png"/></a></li>
                            <li><a href="http://skaredcreations.com/wp/products/combu/" target="_blank" data-toggle="tooltip" title="Visit the official page of Combu"><img src="images/bubble_web.png"/></a></li>
                        </ul>
                        <div class="clear"><strong>Combu</strong> <?= COMBU_VERSION ?></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php if ($AdminLogged->IsLogged()) { ?>
                <div id="menu" class="col-sm-3 col-xl-2">
                    <div class="menu-section">
                        <div class="menu-section-title">Administration</div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/index.php")) { ?>menu-section-active<?php } ?>"><a href="index.php" title="Homepage"><i class="fa fa-home"></i> Home</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/serversettings.php")) { ?>menu-section-active<?php } ?>"><a href="serversettings.php" title="Manage the Server Settings"><i class="fa fa-cogs"></i> Server Settings</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/admins.php")) { ?>menu-section-active<?php } ?>"><a href="admins.php" title="Manage the Server Admins"><i class="fa fa-user-secret"></i> Server Admins</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/apps.php")) { ?>menu-section-active<?php } ?>"><a href="apps.php" title="Manage the Apps"><i class="fa fa-rocket"></i> Registered Apps</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/users.php")) { ?>menu-section-active<?php } ?>"><a href="users.php" title="Manage the Client Users"><i class="fa fa-users"></i> Client Users</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/session_tokens.php")) { ?>menu-section-active<?php } ?>"><a href="session_tokens.php" title="See the Session Tokens"><i class="fa fa-plug"></i> Session Tokens</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/ipbans.php")) { ?>menu-section-active<?php } ?>"><a href="ipbans.php" title="See the IP Bans"><i class="fa fa-ban"></i> IP Bans</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/leaderboards.php")) { ?>menu-section-active<?php } ?>"><a href="leaderboards.php" title="Manage the Leaderboards"><i class="fa fa-trophy"></i> Leaderboards</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/achievements.php")) { ?>menu-section-active<?php } ?>"><a href="achievements.php" title="Manage the Achievements"><i class="fa fa-star"></i> Achievements</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/news.php")) { ?>menu-section-active<?php } ?>"><a href="news.php" title="Manage the News"><i class="fa fa-newspaper"></i> News articles</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/newsletters.php")) { ?>menu-section-active<?php } ?>"><a href="newsletters.php" title="Manage the Newsletters"><i class="fa fa-envelope"></i> Newsletters</a></div>
                        <div class="menu-section-link <?php if (isMenuSection("admin/tools.php")) { ?>menu-section-active<?php } ?>"><a href="tools.php" title="Utilities and tools"><i class="fa fa-wrench"></i> Utility tools</a></div>
                        <div class="menu-section-link"><a href="index.php?logout=1" title="Disconnect"><i class="fa fa-sign-out-alt"></i> Logout</a></div>
                    </div>
                    <?php foreach ($Addons as $addon) { ?>
                        <?php
                        // Skip addons that haven't admin menu
                        if (count($addon->GetAdminMenu()) == 0)
                            continue;
                        ?>
                    <div class="menu-section">
                        <div class="menu-section-title" title="<?= $addon->GetTooltip() ?>"><?= htmlentities($addon->Name) ?></div>
                        <?php $i = 0; ?>
                        <?php foreach ($addon->GetAdminMenu() as $addonMenuItem) { ?>
                        <div class="menu-section-link" data-addon-menu="<?= $addon->Id ?>-<?= $i ?>"><a href="<?= $addon->GetMenuLink($i) ?>" title="<?= htmlentities($addon->Name . ": " . $addonMenuItem["Display"]) ?>"><?= htmlentities($addonMenuItem["Display"]) ?></a></div>
                        <?php $i++; ?>
                        <?php } ?>
                    </div>
                    <?php } ?>
                </div>
                <div id="content" class="col-sm-9 col-xl-10">
                <?php } else { ?>    
                <div id="content" class="col-sm-12">
                <?php } ?>
                    <div id="dlg-alert-disappear" class="alert alert-success" role="alert" data-time="5">
                        <p></p>
                    </div>