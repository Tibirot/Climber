                </div>
            </div>
            <div class="row" id="footer">
                <div class="col">
                    Made with <a href="https://getbootstrap.com" target="_blank">Bootstrap</a> and <a href="https://jquery.com" target="_blank">jQuery</a>.
                    <br/>Customize the layout and interaction of this panel from <a href="tools.php">Tools</a>.
                </div>
                <div class="col text-right">
                    Combu &copy; <?= date("Y") ?> <a href="http://skaredcreations.com" target="_blank" title="Skared Creations">Skared Creations</a>
                </div>
            </div>
        </div>
        
        <div id="dlg-loading" class="modal hide" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <p>Please wait...<br/><img src="images/loading.gif" /></p>
                    </div>
                </div>
            </div>
        </div>
        
    </body>
</html>
<?php $Database->CloseConnection(); ?>