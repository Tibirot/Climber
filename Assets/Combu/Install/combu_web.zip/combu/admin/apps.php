<?php

include_once './common.php';

use Combu\Utils;
use Combu\AppId;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$recordId = getRequestInput("Id");
$record = (empty($recordId) ? NULL : new AppId($recordId));
$isNew = ($recordId == "new");
$error = NULL;

/**
 * Verify the current action
 */
switch (getRequestInput("action")) {

    // Action Save
    case "save":
        if ($record) {
            Utils::FillObjectFromRequest($record);
            if (!$record->Name) {
                $error = "Enter the Name";
            } else if ($record->Exists()) {
                $error = "This Name is already used";
            } else {
                if ($record->Save()) {
                    // Return to list
                    Utils::RedirectTo("?saved=1" . ($isNew ? "&Id=" . urlencode($record->Id) : ""));
                } else {
                    $error = "An error occurred";
                    if ($isNew) {
                        $record->Id = "new";
                        $record->Secret = "";
                    }
                }
            }
        }
        break;

    // Action Delete
    case "delete":
        if ($record) {
            $record->Delete();
            // Return to list
            Utils::RedirectTo("?deleted=1");
        }
        break;

}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

// Display list if there is no active record
if (!$record) {
    $limit = DEFAULT_LIST_LIMIT;
    $page = intval(getRequestInput("Page", 1));
    $count = 0;
    $records = AppId::Load($limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<?php include './header.php'; ?>

<?= printAlertDisappearSaved($saved) ?>
<?= printAlertDisappearDeleted($deleted) ?>

<?php if (!$record) { ?>

    <fieldset id="list">
        <legend>Registered Apps</legend>
        
        <form method="post">
            <div class="field" style="text-align: right;">
                <button class="btn btn-primary" onclick="document.location.href='?Id=new'; return false">Create App</button>
            </div>
        </form>

        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="1"></th>
                    <th width="300" class="text-right">App Id</th>
                    <th>Name</th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="4">No results</td></tr>'; ?>
        
        <?php foreach ($records as $record) { ?>

            <tr class="<?= ($record->IsActive() ? "" : "record-disabled") ?>">
                <td nowrap>
                    <button class="btn btn-danger" onclick="if (confirm('Delete this News?')) document.location.href='?action=delete&Id=<?= $record->Id ?>';" title="Delete"><i class="fa fa-trash-alt"></i></button>
                    <button class="btn btn-primary" onclick="document.location.href='?Id=<?= $record->Id ?>';" title="Edit"><i class="fa fa-edit"></i></button>
                </td>
                <td class="text-right" nowrap><?= $record->AppId ?></td>
                <td><?= htmlentities($record->Name, ENT_QUOTES, 'UTF-8') ?><?php if (!$record->IsActive()) echo ' (DISABLED)'; ?></td>
            </tr>

        <?php } ?>

            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <h6>
                                    <?= $count ?> result(s) in <?= $pagesCount ?> page(s)
                                </h6>
                                <div class="form-row">
                                    <div class="col-auto">
                                        <select name="Page" class="form-control">
                                        <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                            <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>>Page <?= $i ?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <input type="submit" class="btn btn-default" value="Go"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>

    </fieldset>
            
<?php } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to Apps</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>App Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <?php if ($record->Id > 0) { ?>
                <div class="form-group">
                    <label>Id:</label> <strong><?= htmlentities($record->Id) ?></strong>
                    | <label>Date created:</label>
                    <strong><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($record->DateCreated)) ?></strong>
                </div>
                <div class="form-group">
                    <label>App Id:</label>
                    <strong><?= htmlentities($record->AppId) ?></strong>
                </div>
                <div class="form-group">
                    <label>Secret key:</label>
                    <strong><?= htmlentities($record->Secret) ?></strong>
                </div>
                <div class="form-group">
                    <label>Active</label>
                    <select class="form-control" name="Active">
                        <option value="0" <?php if (!$record->IsActive()) echo 'selected'; ?>>NO</option>
                        <option value="1" <?php if ($record->IsActive()) echo 'selected'; ?>>YES</option>
                    </select>
                </div>
            <?php } else { ?>
                <div class="form-group">
                    <label>App Id</label>
                    <br/><em>This will be assigned after saving</em>
                </div>
                <div class="form-group">
                    <label>Secret key</label>
                    <br/><em>This will be assigned after saving</em>
                </div>
            <?php } ?>
            <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" name="Name" value="<?= htmlentities($record->Name, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea class="form-control" name="Description"><?= htmlentities($record->Description, ENT_QUOTES, 'UTF-8') ?></textarea>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>
    
    <script>
        $(function() {
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

<?php } ?>

<?php include './footer.php'; ?>