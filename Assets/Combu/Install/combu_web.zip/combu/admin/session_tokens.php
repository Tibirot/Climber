<?php

include_once './common.php';

use Combu\Utils;
use Combu\SessionToken;
use Combu\Account;
use Combu\AppId;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$timezone = Utils::GetDateTimeZoneUTC();
$now = Utils::GetCurrentDateTime($timezone);

$date_request = filter_input(INPUT_POST, "Date");
$error = NULL;

/**
 * Verify the current action
 */
switch (filter_input(INPUT_POST, "action")) {

    case "delete_date":
        $idApp = getRequestInput("IdApp", 0);
        $date_format = "Y-m-d";
        $date = \DateTime::createFromFormat($date_format, $date_request, $timezone);
        if ($date && $date_request == $date->format($date_format)) {
            $diff = intval($date->diff($now)->format("%R%a"));
            $sessions = SessionToken::Load(0, NULL, $date->format("Y-m-d") . " 23:59:59", $idApp);
            if (count($sessions) > 0) {
                foreach ($sessions as $session) {
                    $session->Delete();
                }
                Utils::RedirectTo("?deleted=1");
            }
            $error = "No sessions found from beginning to date " . $date->format("Y-m-d H:i:s");
        }
        if (!$error) {
            Utils::RedirectToSelf();
        }
        break;

}

$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

$apps = AppId::Load();

// Display list if there is no active record
$limit = DEFAULT_LIST_LIMIT;
$page = max(1, intval(getRequestInput("Page")));
$idApp = getRequestInput("IdApp", 0);
$toDate = getRequestInput("Date", Utils::GetCurrentDateTimeFormat("Y-m-d"));
$ipAddress = getRequestInput("Ip", NULL);
$count = 0;
$records = SessionToken::Load(0, NULL, DateTime::createFromFormat("Y-m-d", $toDate)->format("Y-m-d") . " 23:59:59", $idApp, $ipAddress, $limit, Utils::GetPageOffset($page, $limit), $count);
$pagesCount = Utils::GetPagesCount($count, $limit);

?>
<?php include './header.php'; ?>

<fieldset id="list">
    <legend>Session Tokens</legend>

    <form id="form-sessions" method="post" action="<?= $_SERVER["PHP_SELF"] ?>">
        <input type="hidden" name="action" value=""/>
        <div class="form-group">
            <label>App Scope</label>
            <select class="form-control" name="IdApp">
                <option value="0" <?php if ($idApp <= 0) echo ' selected'; ?>>[Any App]</option>
            <?php foreach ($apps as $app) { ?>
                <option value="<?= $app->Id ?>" <?php if ($idApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
            <?php } ?>
            </select>
        </div>
        <div class="form-group">
            <label>From beginning to date (UTC):</label>
            <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text"><i class="fa fa-calendar-alt mouse-pointer" id="DeleteDateTrigger"></i></span>
                </div>
                <input type="text" class="form-control" id="DeleteDate" name="Date" readonly="readonly" value="<?= $toDate ?>">
            </div>
        </div>
        <div class="form-group">
            <label>Filter IP</label>
            <input type="text" class="form-control" name="Ip" value="<?= htmlentities($ipAddress, ENT_QUOTES, 'UTF-8') ?>"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary" title="Start the search"><i class="fa fa-search"></i> Search</button>
            <button type="button" class="btn btn-default" title="Reset the search filters" onclick="document.location.href = '?';"><i class="fa fa-undo"></i> Reset</button>
            <button type="button" class="btn btn-danger" id="btDelete" title="Delete all the tokens from begging to the date specified in the text box"><i class="fa fa-trash-alt"></i> Delete</button>
        </div>
    </form>

    <?= printAlertError($error) ?>
    <?= printAlertDisappearDeleted($deleted) ?>
    
    <table class="table-records" width="100%">
        <thead>
            <tr>
                <th width="150">Date (UTC)</th>
                <th width="320">Token</th>
                <th>Info</th>
            </tr>
        </thead>
        <tbody>
    <?php if ($count == 0) echo '<tr><td colspan="4">No results</td></tr>'; ?>

    <?php foreach ($records as $record) { ?>
        <?php
        $date = new \DateTime($record->Created);
        $diff = intval($date->diff($now)->format("%R%a"));
        $user = NULL;
        if ($record->IdAccount > 0) {
            $user = new Account($record->IdAccount);
        }
        $app = new AppId($record->IdApp);
        ?>
        <tr>
            <td><?= $date->format("d M Y H:i") ?></td>
            <td><?= htmlentities($record->Token, ENT_QUOTES, 'UTF-8') ?></td>
            <td>
                <div class="record-details">
                    <ul>
                        <li>App: <?= ($app->IsValid() ? '<a href="apps.php?Id=' . $app->Id . '">' . htmlentities($app->Name) . '</a>' : '<span style="color:#CCC;">None</em>') ?></li>
                        <li>Player: <?= ($user ? '<a href="users.php?Id=' . $user->Id . '">' . htmlentities($user->Username, ENT_QUOTES, 'UTF-8') . '</a>' : "") ?></li>
                        <li>IP address: <?= htmlentities($record->IPAddress, ENT_QUOTES, 'UTF-8') ?></li>
                        <li>Last action: <?= $record->Updated ?></li>
                    </ul>
                </div>
            </td>
        </tr>

    <?php } ?>

        </tbody>
        <tfoot>
    <?php if ($count > 0) { ?>
            <tr>
                <td colspan="4">
                    <div class="navpages">
                        <form method="post">
                            <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                            <label>Go to page</label>
                            <select name="Page">
                            <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                            <?php } ?>
                            </select>
                            <input type="hidden" name="IdApp" value="<?= $idApp ?>"/>
                            <input type="hidden" name="Date" value="<?= $toDate ?>"/>
                            <input type="hidden" name="Ip" value="<?= htmlentities($ipAddress, ENT_QUOTES, 'UTF-8') ?>"/>
                            <input type="submit" class="button" value="Go"/>
                        </form>
                    </div>
                </td>
            </tr>
    <?php } ?>
        </tfoot>
    </table>

</fieldset>

<script>
    $(function() {
        $("#DeleteDate").datetimepicker({
            timepicker:false,
            format: "Y-m-d",
            maxDate: "<?= $now->format("Y-m-d") ?>"
        });
        $("#DeleteDateTrigger").click(function(e) {
            e.preventDefault();
            $("#DeleteDate").datetimepicker("show");
        });
        $("#btDelete").click(function(e) {
            e.preventDefault();
            var dt = $("#DeleteDate").datetimepicker("getValue");
            if (!dt) {
                alert("Click the calendar to select a date");
                return;
            }
            dt.setHours(23, 59, 59);
            if (!confirm("Delete all sessions from beginning to " + dt.toLocaleDateString() + " " + dt.toLocaleTimeString() + " (UTC)")) {
                return;
            }
            //$("#DeleteDate").val($("#DeleteDate").val() + " " + dt.toLocaleTimeString());
            $("#DeleteDate").val($("#DeleteDate").val());
            $("#form-sessions input[name='action']").val('delete_date');
            $("#form-sessions").submit();
        });
    });
</script>

<?php include './footer.php'; ?>