<?php

include_once './common.php';

use Combu\Utils;
use Combu\AdminAccount;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$user = (!isset($_REQUEST["Id"]) ? NULL : new AdminAccount(intval($_REQUEST["Id"])));
$currentUsername = ($user ? $user->Username : "");
$error = NULL;

/**
 * Verify the current action
 */
if (isset($_REQUEST["action"])) {
    switch ($_REQUEST["action"]) {

    // Action Save
        case "save":
            if ($user) {
                Utils::FillObjectFromRequest($user);
                if (!$user->Username)
                    $error = "Enter the Username";
                else if ($user->ExistsUsername())
                    $error = "This Username is already used";
                else {
                    $newpass = NULL;
                    // Set the password to the appropriate REQUEST param
                    if ($user->Id > 0) {
                        // We are modifying an existing user, check for new password
                        if (isset($_REQUEST["newpass"]))
                            $newpass = trim(stripslashes($_REQUEST["newpass"]));
                    } else {
                        // We are adding a new user, the password is set from the REQUEST
                        $newpass = $user->Password;
                    }
                    // If a password has been specified, then apply it
                    if ($newpass) {
                        $user->Password = md5($newpass);
                    }
                    // Save the changes
                    if ($user->Save()) {
                        // Return to list
                        Utils::RedirectTo("?saved=1");
                    } else
                        $error = "An error occurred";
                }
            }
            break;

    // Action Delete
        case "delete":
            if ($user) {
                // I cannot delete myself!
                if ($user->Id != $AdminLogged->Id) {
                    $user->Delete();
                }
                Utils::RedirectTo("?deleted=1");
            }
            break;

    }
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

// Display list if there is no active record
if (!$user) {
    $username = (!isset($_REQUEST["Username"]) ? NULL : trim(stripslashes($_REQUEST["Username"])));
    $limit = DEFAULT_LIST_LIMIT;
    $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
    $count = 0;
    $users = AdminAccount::Load($username, $limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<?php include './header.php'; ?>

<?= printAlertDisappearSaved($saved) ?>
<?= printAlertDisappearDeleted($deleted) ?>

<?php if (!$user) { ?>

    <fieldset id="list">
        <legend>Server Admins</legend>
        
        <form method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" class="form-control" name="Username" value="<?= htmlentities($username, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                <button type="button" class="btn btn-default" onclick="document.location.href = '?';"><i class="fa fa-undo"></i> Reset</button>
                <button type="button" class="btn btn-primary float-right" onclick="document.location.href = '?Id=0';"><i class="fa fa-plus"></i> Create Admin</button>
            </div>
        </form>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="1"></th>
                    <th width="100" class="text-right">Id</th>
                    <th>Username</th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>
            
        <?php foreach ($users as $user) { ?>

            <tr>
                <td nowrap>
                    <?php if ($user->Id != $AdminLogged->Id) { ?>
                    <button class="btn btn-danger" onclick="if (confirm('Delete this User?')) document.location.href='?action=delete&Id=<?= $user->Id ?>';" title="Delete"><i class="fa fa-trash-alt"></i></button>
                    <?php } ?>
                    <button class="btn btn-primary" onclick="document.location.href='?Id=<?= $user->Id ?>';" title="Edit"><i class="fa fa-edit"></i></button>
                </td>
                <td class="text-right"><?= $user->Id ?></td>
                <td><?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?></td>
            </tr>

        <?php } ?>

            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="Username" value="<?= htmlentities($username, ENT_QUOTES, 'UTF-8') ?>"/>
                                <h6>
                                    <?= $count ?> result(s) in <?= $pagesCount ?> page(s)
                                </h6>
                                <div class="form-row">
                                    <div class="col-auto">
                                        <select name="Page" class="form-control">
                                        <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                            <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>>Page <?= $i ?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <input type="submit" class="btn btn-default" value="Go"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>

    </fieldset>
            
<?php } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to Admins</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>Admin Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <?php if ($user->Id > 0) { ?>
                <div class="form-group">
                    <label>Id:</label> <strong><?= htmlentities($user->Id) ?></strong>
                </div>
            <?php } ?>
            <div class="form-group">
                <label for="textUsername">Username</label>
                <input type="text" class="form-control" name="Username" id="textUsername" value="<?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?>"/>
                <?php if ($currentUsername) { ?>(current: <em><?= htmlentities($currentUsername, ENT_QUOTES, 'UTF-8') ?></em>)<?php } ?>
            </div>
            <?php if ($user->Id > 0) { ?>
            <div class="form-group">
                <label for="textNewPassword">New Password</label>
                <input type="password" class="form-control" name="newpass" id="textNewPassword" value=""/>
            </div>
            <div class="form-group">
                <label for="textConfirmNewPassword">Confirm Password</label>
                <input type="password" class="form-control" name="newpass_confirm" id="textConfirmNewPassword" value=""/>
            </div>
            <?php } else { ?>
            <div class="form-group">
                <label for="textPassword">Password</label>
                <input type="password" class="form-control" name="Password" id="textPassword" value=""/>
            </div>
            <?php } ?>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>

    <script type="text/javascript">
        $(function () {
            var myForm = $("#formEdit");
            myForm.submit(function() {
                if (!myForm.find("input[name=Username]").val().trim()) {
                    alert("Username cannot be empty");
                    return false;
                }
            <?php if ($user->Id > 0) { ?>
                if (myForm.find("input[name=newpass]").val().trim() && myForm.find("input[name=newpass]").val().trim() != myForm.find("input[name=newpass_confirm]").val().trim()) {
                    alert("The Confirm Password is wrong");
                    return false;
                }
            <?php } else { ?>
                if (!myForm.find("input[name=Password]").val().trim()) {
                    alert("Password cannot be empty");
                    return false;
                }
            <?php } ?>
                toggleBusy(true);
            });
        });
    </script>

<?php } ?>

<?php include './footer.php'; ?>