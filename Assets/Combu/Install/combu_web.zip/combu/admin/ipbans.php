<?php

include_once './common.php';

use Combu\Utils;
use Combu\IpBan;
use Combu\AppId;
use Combu\AdminAccount;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$id = getRequestInput("Id");
$record = (is_null($id) ? NULL : new IpBan(intval($id)));
$error = NULL;

/**
 * Verify the current action
 */
switch (getRequestInput("action")) {

    // Action Save
    case "save":
        if ($record) {
            Utils::FillObjectFromRequest($record);
            if (empty($record->ToIp)) {
                // Set range end equal to range start if not specified
                $record->ToIp = $record->FromIp;
                $sameIpType = TRUE;
            } else {
                // Are range values of the same type?
                if (Utils::IsIPv4($record->FromIp)) {
                    $sameIpType = Utils::IsIPv4($record->ToIp);
                } else if (Utils::IsIPv6($record->FromIp)) {
                    $sameIpType = Utils::IsIPv6($record->ToIp);
                }
            }
            if (!Utils::IsIPv4($record->FromIp) && !Utils::IsIPv6($record->FromIp)) {
                $error = "Enter a valid IP range start";
            } else if (!$sameIpType && !Utils::IsIPv4($record->ToIp) && !Utils::IsIPv6($record->ToIp)) {
                $error = "Enter a valid IP range end";
            } else if (!$sameIpType) {
                $error = "IP range values must be both IPv4 or both IPv6";
            } else if (strcmp($record->FromIp, $record->ToIp) > 0) {
                $error = "IP range start must be greater than range end";
            } else {
                $record->IdAdminAccount = $AdminLogged->Id;
                if ($record->Save()) {
                    // Return to list
                    Utils::RedirectTo("?saved=1");
                } else {
                    $error = "An error occurred";
                }
            }
        }
        break;

    // Action Delete
    case "delete":
        if ($record) {
            $record->Delete();
            // Return to list
            Utils::RedirectTo("?deleted=1");
        }
        break;

}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

$apps = AppId::Load();

// Display list if there is no active record
if (!$record) {
    $limit = DEFAULT_LIST_LIMIT;
    $page = getRequestInput("Page", 1);
    $idApp = getRequestInput("IdApp", 0);
    $ip = getRequestInput("Ip", NULL);
    $count = 0;
    $records = IpBan::Load($idApp, 0, $ip, $limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
} else {
    $adminAccount = new AdminAccount($record->IdAdminAccount);
}

?>
<?php include './header.php'; ?>

<?= printAlertDisappearSaved($saved) ?>
<?= printAlertDisappearDeleted($deleted) ?>

<?php if (!$record) { ?>

    <fieldset id="list">
        <legend>IP Bans</legend>
        
        <form method="post" action="<?= $_SERVER["PHP_SELF"] ?>">
            <div class="form-group">
                <label>App Scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($idApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($idApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
                <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <label>Filter IP</label>
                <input type="text" class="form-control" name="Ip" value="<?= htmlentities($ip, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                <button type="button" class="btn btn-default" onclick="document.location.href = '?';"><i class="fa fa-undo"></i> Reset</button>
                <button type="button" class="btn btn-primary float-right" onclick="document.location.href = '?Id=0';"><i class="fa fa-plus"></i> Create IP Ban</button>
            </div>
        </form>

        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="1"></th>
                    <th width="100" class="text-right">Id</th>
                    <th width="150">App</th>
                    <th width="150">Date</th>
                    <th>IP range</th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="5">No results</td></tr>'; ?>
        
        <?php foreach ($records as $record) { ?>
            <?php
            $app = new AppId($record->IdApp);
            $range = $record->FromIp;
            if ($record->FromIp != $record->ToIp) {
                $range = $record->FromIp . " to " . $record->ToIp;
            }
            ?>

            <tr>
                <td nowrap>
                    <button class="btn btn-danger" onclick="if (confirm('Delete this IP Ban?')) document.location.href='?action=delete&Id=<?= $record->Id ?>';" title="Delete"><i class="fa fa-trash-alt"></i></button>
                    <button class="btn btn-primary" onclick="document.location.href='?Id=<?= $record->Id ?>';" title="Edit"><i class="fa fa-edit"></i></button>
                </td>
                <td class="text-right"><?= $record->Id ?></td>
                <td><?= ($app->IsValid() ? htmlentities($app->Name) : '<span style="color:#CCC;">Any App</em>') ?></td>
                <td><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($record->DateUpdated)) ?></td>
                <td><?= htmlentities($range, ENT_QUOTES, 'UTF-8') . (empty($record->Reason) ? "" : "<br/>Reason: " . htmlentities($record->Reason, ENT_QUOTES, 'UTF-8')) ?></td>
            </tr>

        <?php } ?>

            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="5">
                        <div class="navpages">
                            <form method="post">
                                <?= $count ?> result(s) in <?= $pagesCount ?> page(s) -
                                <label>Go to page</label>
                                <select name="Page">
                                <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                    <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>><?= $i ?></option>
                                <?php } ?>
                                </select>
                                <input type="hidden" name="IdApp" value="<?= $idApp ?>"/>
                                <input type="hidden" name="Ip" value="<?= htmlentities($ip, ENT_QUOTES, 'UTF-8') ?>"/>
                                <input type="submit" class="button" value="Go"/>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>

    </fieldset>
            
<?php } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to the list</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>IP Ban Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <?php if ($record->Id > 0) { ?>
            <div class="form-group">
                <label>Id:</label> <strong><?= $record->Id ?></strong>
                | <label>Last Updated:</label>
                <strong><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($record->DateUpdated)) ?></strong> by <?= htmlentities($adminAccount->Username, ENT_QUOTES, 'UTF-8') ?>
                | <label>App scope:</label>
                <?php
                $app = new AppId($record->IdApp);
                ?>
                <strong><?= ($app->IsValid() ? htmlentities($app->Name, ENT_QUOTES, 'UTF-8') : "Any App") ?></strong>
            </div>
            <?php } else { ?>
            <div class="form-group">
                <label>App scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($record->IdApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($record->IdApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name, ENT_QUOTES, 'UTF-8') ?></option>
                <?php } ?>
                </select>
            </div>
            <?php } ?>
            <div class="form-group">
                <label>IP range start</label>
                <input type="text" class="form-control" name="FromIp" value="<?= htmlentities($record->FromIp, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>IP range end</label>
                <input type="text" class="form-control" name="ToIp" value="<?= htmlentities($record->ToIp, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>Reason</label>
                <input type="text" class="form-control" name="Reason" value="<?= htmlentities($record->Reason, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                or <a href="?">Cancel</a>
            </div>
        </form>

    </fieldset>
    
    <script>
        $(function() {
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

<?php } ?>

<?php include './footer.php'; ?>