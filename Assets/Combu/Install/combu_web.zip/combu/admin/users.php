<?php

include_once './common.php';

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\DataClass;
use Combu\Account;
use Combu\CustomData;
use Combu\AppCustomData;
use Combu\UserFile;
use Combu\LeaderBoard;
use Combu\LeaderBoard_User;
use Combu\Achievement;
use Combu\Achievement_User;
use Combu\Friend;
use Combu\AppId;
use Combu\Account_App;
use Combu\FileUpload;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$user = (is_null(getRequestInput("Id")) ? NULL : new Account(intval($_REQUEST["Id"])));
$currentUsername = ($user ? $user->Username : "");
$customData = ($user ? CustomData::Load($user->Id) : NULL);

$error = NULL;

/**
 * Verify the current action
 */
switch (getRequestInput("action")) {

    // Action Save
    case "save":
        if ($user) {
            $errorPassword = "";
            $newPassword = getRequestInput( $user->Id > 0 ? "NewPassword" : "Password" );
            $confirmPassword = getRequestInput("ConfirmPassword");
            if ($user->Id > 0) {
                if ($newPassword) {
                    if ($newPassword != $confirmPassword) {
                        $errorPassword = "Confirm Password is different";
                    }
                }
            } else {
                if (!$newPassword) {
                    $errorPassword = "Enter the Password and Confirm";
                } else if ($newPassword != $confirmPassword) {
                    $errorPassword = "Confirm Password is different";
                }
            }
            $oldPassword = $user->Password;
            Utils::FillObjectFromRequest($user);
            $user->Password = $oldPassword;
            if ($errorPassword) {
                $error = $errorPassword;
            } else if (!$user->Username) {
                $error = "Enter the Username";
            } else if ($user->ExistsUsername()) {
                $error = "Username is already used";
            } else {
                $isNew = ($user->Id < 1);
                if ($isNew && $newPassword) {
                    $user->Password = md5($newPassword);
                }
                if ($user->Save()) {
                    if (!$isNew && $newPassword) {
                        $user->ChangePassword(md5($newPassword));
                    }
                    // Save custom data key/value pairs, if any
                    if (isset($_REQUEST["custom_key"])) {
                        $customKeys = $_REQUEST["custom_key"];
                        $customValues = $_REQUEST["custom_value"];
                        // Ensure they are array
                        if (!is_array($customKeys)) {
                            $customKeys = array($customKeys);
                        }
                        if (!is_array($customValues)) {
                            $customValues = array($customValues);
                        }
                        // Cycle through the keys/values
                        for ($i = 0; $i < count($customKeys); $i++) {
                            $customData = new CustomData();
                            $customData->IdAccount = $user->Id;
                            $customData->DataKey = $customKeys[$i];
                            $customData->DataValue = $customValues[$i];
                            $customData->Save();
                        }
                    }
                    // Return to list
                    Utils::RedirectTo("?saved=1" . ($isNew ? "&Id=" . $user->Id : ""));
                } else {
                    $error = "An error occurred";
                }
            }
        }
        break;

    // Action Delete
    case "delete":
        if ($user) {
            $user->Delete();
            Utils::RedirectTo("?deleted=1");
        }
        break;
        
    // Load the Custom Data HTML:
    case "custom_load":
        if ($user) {
            if (count($customData) == 0) {
                echo "No global Custom Data.";
            } else {
                echo "Edit the keys for the global scope.";
                $iCustom = -1;
                foreach ($customData as $data) {
                    $iCustom++;
                    ?>
                    <form method="post" id="frm-custom<?= $iCustom ?>" class="customdata">
                        <input type="hidden" name="action" value="custom_save"/>
                        <input type="hidden" name="custom_key" value="<?= htmlentities($data->DataKey, ENT_QUOTES, 'UTF-8') ?>"/>
                        <div class="form-group">
                            <label><?= htmlentities($data->DataKey, ENT_QUOTES, 'UTF-8') ?></label>
                            <input type="text" class="form-control" name="custom_value" value="<?= htmlentities($data->DataValue, ENT_QUOTES, 'UTF-8') ?>"/>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                            <button type="button" class="btn btn-danger delete-custom" data-form="frm-custom<?= $iCustom ?>" title="Delete"><i class="fa fa-trash-alt"></i> Delete</button>
                        </div>
                    </form>
                    <?php
                }
            }
        }
        exit();
        break;

    // Save a Custom Data
    case "custom_save":
        $success = FALSE;
        $message = "";
        if (!$user) {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        } else {
            $myKey = filter_input(INPUT_POST, "custom_key");
            $myValue = filter_input(INPUT_POST, "custom_value");
            if ($myKey) {
                $data = new CustomData();
                $data->IdAccount = $user->Id;
                $data->DataKey = $myKey;
                $data->DataValue = $myValue;
                $success = $data->Save();
                if (!$success) {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
        }
        Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
        break;

    // Delete a Custom Data
    case "custom_delete":
        $success = FALSE;
        $message = "";
        $found = FALSE;
        if (!$user) {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        } else {
            $myKey = filter_input(INPUT_POST, "custom_key");
            if ($myKey) {
                foreach ($customData as $data) {
                    if ($data->DataKey == $myKey) {
                        $found = TRUE;
                        $success = $data->Delete();
                        break;
                    }
                }
            }
        }
        if (!$found && !$success) {
            $success = TRUE;
        }
        if (!$success) {
            $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
        }
        Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
        break;
        
    case "appcustom_load":
        if ($user) {
            $idApp = intval(getRequestInput("IdApp"));
            if ($idApp > 0) {
                $appCustomData = AppCustomData::Load($idApp, $user->Id);
                if (count($appCustomData) == 0) {
                    echo "No Custom Data for the selected app.";
                } else {
                    echo "Edit the keys for the selected App scope.";
                    $iCustom = -1;
                    foreach ($appCustomData as $data) {
                        $iCustom++;
                        ?>
                        <form method="post" id="frm-appcustom<?= $iCustom ?>" class="appcustomdata mt-4">
                            <input type="hidden" name="action" value="save_appcustom"/>
                            <input type="hidden" name="IdApp" value="<?= htmlentities($data->IdApp, ENT_QUOTES, 'UTF-8') ?>"/>
                            <input type="hidden" name="custom_key" value="<?= htmlentities($data->DataKey, ENT_QUOTES, 'UTF-8') ?>"/>
                            <div class="form-group">
                                <label><?= htmlentities($data->DataKey, ENT_QUOTES, 'UTF-8') ?></label>
                                <input type="text" class="form-control" name="custom_value" value="<?= htmlentities($data->DataValue, ENT_QUOTES, 'UTF-8') ?>"/>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                                <button type="button" class="btn btn-danger delete-appcustom" data-form="frm-appcustom<?= $iCustom ?>" title="Delete"><i class="fa fa-trash-alt"></i> Delete</button>
                            </div>
                        </form>
                        <?php
                    }
                }
            }
        }
        exit;
        break;

    // Save a App Custom Data
    case "appcustom_save":
        $success = FALSE;
        $message = "";
        $app = new AppId(intval(getRequestInput("IdApp")));
        if ($app->Id < 1) {
            $message = ErrorMessage::Get(ERROR_INVALID_APP);
        } else if (!$user) {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        } else {
            $myKey = filter_input(INPUT_POST, "custom_key");
            $myValue = filter_input(INPUT_POST, "custom_value");
            if (!empty($myKey)) {
                $data = new AppCustomData();
                $data->IdApp = $app->Id;
                $data->IdAccount = $user->Id;
                $data->DataKey = $myKey;
                $data->DataValue = $myValue;
                $success = $data->Save();
                if (!$success) {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            } else {
                $message = ErrorMessage::Get(ERROR_INVALID_KEY);
            }
        }
        Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
        break;

    // Delete a App Custom Data
    case "appcustom_delete":
        $success = FALSE;
        $message = "";
        $app = new AppId(intval(getRequestInput("IdApp")));
        if ($app->Id < 1) {
            $message = ErrorMessage::Get(ERROR_INVALID_APP);
        } else if (!$user) {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        } else {
            $myKey = filter_input(INPUT_POST, "custom_key");
            if (!empty($myKey)) {
                $data = new AppCustomData();
                $data->IdApp = $app->Id;
                $data->IdAccount = $user->Id;
                $data->DataKey = $myKey;
                $success = $data->Delete();
                if (!$success) {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            } else {
                $message = ErrorMessage::Get(ERROR_INVALID_KEY);
            }
        }
        Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
        break;

    // User App registration Create
    case "add_app":
        if ($user) {
            $app = new AppId(getRequestInput("app"));
            $success = FALSE;
            $aap = NULL;
            if ($app->IsValid() && !Account_App::Exists($user->Id, $app->Id, $aap)) {
                $aap = new Account_App();
                $aap->IdAccount = $user->Id;
                $aap->IdApp = $app->Id;
                $success = $aap->Save();
            }
            if ($success) {
                Utils::RedirectTo("?Id=" . $user->Id . "&saved=1#tab-apps");
            }
            if ($aap) {
                $error = "This user is already registered on the app <strong>" . $app->Name . "</strong>";
            } else {
                $error = "An error occurred when trying to add this user to the app <strong>" . $app->Name . "</strong>";
            }
        }
        break;

    // User App registration Delete
    case "delete_app":
        if ($user) {
            $app = new AppId(getRequestInput("app"));
            $aap = NULL;
            if ($app->IsValid() && Account_App::Exists($user->Id, $app->Id, $aap)) {
                $aap->Delete();
            }
            Utils::RedirectTo("?Id=" . $user->Id . "&deleted=1#tab-apps");
        }
        break;
        
    // User File upload
    case "add_file":
        if ($user) {
            $shareType = intval(filter_input(INPUT_POST, "ShareType"));
            if (is_null($shareType) || $shareType < SHARETYPE_EVERYBODY || $shareType > SHARETYPE_FRIENDS) {
                $shareType = SHARETYPE_NOBODY;
            }
            $upload = new FileUpload("File");
            if ($upload->Upload()) {
                $fileCustomData = array();
                $inputDataKey = filter_input(INPUT_POST, "custom_key", FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
                $inputDataValue = filter_input(INPUT_POST, "custom_value", FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
                if (!empty($inputDataKey) && !empty($inputDataValue) && is_array($inputDataKey) && is_array($inputDataValue)) {
                    for ($i = 0; $i < count($inputDataKey); $i++) {
                        if (!empty($inputDataKey[$i])) {
                            $fileCustomData[$inputDataKey[$i]] = ($i < count($inputDataValue) ? $inputDataValue[$i] : "");
                        }
                    }
                }
                $file = new UserFile();
                $file->IdAccount = $user->Id;
                $file->Name = filter_input(INPUT_POST, "Name");
                $file->CustomData = json_encode($fileCustomData);
                $file->Url = $upload->GetDestinationUrl();
                if ($file->Save()) {
                    Utils::RedirectTo("?Id=" . $user->Id . "&saved=1#tab-files");
                }
                $error = "An error occurred while saving the new file";
                @unlink($upload->GetDestinationPath());
            }
        }
        break;

    // User File Delete
    case "delete_file":
        if ($user) {
            $file = new UserFile(!isset($_REQUEST["file"]) ? 0 : intval($_REQUEST["file"]));
            if ($file->Delete())
                @unlink (UPLOAD_FOLDER . $file->Url);
            Utils::RedirectTo("?Id=" . $user->Id . "&saved=1#tab-files");
        }
        break;
        
    // Contacts Add
    case "contacts_add":
        if ($user) {
            $idContact = getRequestInput("contact");
            $state = intval(getRequestInput("state"));
            $other = new Account($idContact);
            if ($other->Id > 0 && $user->Id != $other->Id && $state >= FRIEND_STATE_REQUEST_PENDING && $state <= FRIEND_STATE_IGNORE) {
                $contact = new Friend();
                if ($state == FRIEND_STATE_REQUEST_PENDING) {
                    $contact->IdAccount = $other->Id;
                    $contact->IdFriend = $user->Id;
                    $contact->State = FRIEND_STATE_REQUEST;
                } else {
                    $contact->IdAccount = $user->Id;
                    $contact->IdFriend = $other->Id;
                    $contact->State = $state;
                }
                $contact->Save();
                Utils::RedirectTo("?Id=" . $user->Id . "&saved=1#tab-contacts");
            }
        }
        break;
        
    // Contacts Delete
    case "contacts_remove":
        $idContact = getRequestInput("contact");
        if ($user && $idContact > 0) {
            $found = FALSE;
            $contacts = Friend::Load($user->Id);
            foreach ($contacts as $contact) {
                if ($contact->IdFriend == $idContact) {
                    $contact->Delete();
                    $found = TRUE;
                    break;
                }
            }
            if (!$found) {
                $contacts = Friend::Load($user->Id, FRIEND_STATE_REQUEST_PENDING);
                foreach ($contacts as $contact) {
                    if ($contact->IdAccount == $idContact) {
                        $contact->Delete();
                        $found = TRUE;
                        break;
                    }
                }
            }
        }
        Utils::RedirectTo("?Id=" . $user->Id . "&saved=1#tab-contacts");
        break;

    // Delete all leaderboard scores of this player
    case "delete_scores":
        if ($user) {
            $idLeaderboard = intval(filter_input(INPUT_GET, "IdLeaderboard"));
            $scores = LeaderBoard_User::LoadAccount($user->Id, $idLeaderboard);
            foreach ($scores as $score) {
                $score->Delete();
            }
            Utils::RedirectTo("?Id=" . $user->Id . "&saved=1#tab-leaderboards");
        }
        break;

    // Delete all achievements of this player
    case "delete_achievements":
        if ($user) {
            $idAchievement = intval(filter_input(INPUT_GET, "IdAchievement"));
            $achievements = Achievement_User::LoadAccount($user->Id, $idAchievement);
            foreach ($achievements as $achievement) {
                $achievement->Delete();
            }
            Utils::RedirectTo("?Id=" . $user->Id . "&saved=1#tab-achievements");
        }
        break;
}

$apps = AppId::Load();

// Display list if there is no active record
if (!$user) {
    $username = getRequestInput("Username");
    $email = getRequestInput("Email");
    $ip = getRequestInput("IP");
    $online = ( getRequestInput("Online") == "1" );
    $limit = DEFAULT_LIST_LIMIT;
    $page = getRequestInput("Page", 1);
    $idApp = getRequestInput("IdApp", 0);
    $count = 0;
    $users = Account::LoadAnyByIp($ip, $idApp, $username, $email, NULL, NULL, $online, $limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
} else {
    
    // Initialize the lists of apps subscribed/unsubscribed by the user
    $appsAvailableForRegister = array();
    $myApps = array();
    $myAppsAccount = array();
    foreach ($apps as $app) {
        $appAccount = NULL;
        if (Account_App::Exists($user->Id, $app->Id, $appAccount)) {
            $myApps[] = $app;
            $myAppsAccount[] = $appAccount;
        } else {
            $appsAvailableForRegister[] = $app;
        }
    }
    
    // Load the friends, pending requests and ignore lists
    $friends = Friend::Load($user->Id, FRIEND_STATE_ACCEPTED);
    $requests = Friend::Load($user->Id, FRIEND_STATE_REQUEST);
    $ignored = Friend::Load($user->Id, FRIEND_STATE_IGNORE);
    $requests_sent = Friend::Load($user->Id, FRIEND_STATE_REQUEST_PENDING);
    
    // Load user files
    $files = UserFile::Load($user->Id);
    
    // Load the leaderboards and scores
    $leaderboardsScores = array();
    $leaderboards = LeaderBoard::Load();
    foreach ($leaderboards as $leaderboard) {
        $scoreToday = $leaderboard->LoadHighscoreForAccount(LeaderBoard::HIGHSCORE_TODAY, FALSE, FALSE, $user->Id);
        $scoreWeek = $leaderboard->LoadHighscoreForAccount(LeaderBoard::HIGHSCORE_WEEK, FALSE, FALSE, $user->Id);
        $scoreMonth = $leaderboard->LoadHighscoreForAccount(LeaderBoard::HIGHSCORE_MONTH, FALSE, FALSE, $user->Id);
        $scoreTotal = $leaderboard->LoadHighscoreForAccount(LeaderBoard::HIGHSCORE_TOTAL, FALSE, FALSE, $user->Id);
        $leaderboardsScores[$leaderboard->Id] = array(
            "today" => array( "rank" => $scoreToday["Rank"], "score" => $scoreToday["Score"] ),
            "week" => array( "rank" => $scoreWeek["Rank"], "score" => $scoreWeek["Score"] ),
            "month" => array( "rank" => $scoreMonth["Rank"], "score" => $scoreMonth["Score"] ),
            "total" => array( "rank" => $scoreTotal["Rank"], "score" => $scoreTotal["Score"] )
        );
    }
    
    // Load achievements
    $achievements = Achievement::LoadUserAchievements($user->Id);
}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");

?>
<?php include './header.php'; ?>

<?= printAlertDisappearSaved($saved) ?>
<?= printAlertDisappearDeleted($deleted) ?>

<?php if (!$user) { ?>

    <fieldset id="list">
        <legend>Client Users</legend>
        
        <form method="post">
            <div class="form-group">
                <label>App Scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($idApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($idApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
                <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" class="form-control" name="Username" value="<?= htmlentities($username, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="text" class="form-control" name="Email" value="<?= htmlentities($email, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>Filter IP</label>
                <input type="text" class="form-control" name="IP" value="<?= htmlentities($ip, ENT_QUOTES, 'UTF-8') ?>"/>
            </div>
            <div class="form-group">
                <label>Online state</label>
                <select class="form-control" name="Online">
                    <option value="" <?php if (!$online) echo 'selected'; ?>>Any state</option>
                    <option value="1" <?php if ($online) echo 'selected'; ?>>Online</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                <button type="button" class="btn btn-default" onclick="document.location.href = '?';"><i class="fa fa-undo"></i> Reset</button>
                <button type="button" class="btn btn-primary float-right" onclick="document.location.href = '?Id=0';"><i class="fa fa-plus"></i> Create User</button>
            </div>
        </form>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="1"></th>
                    <th width="100" class="text-right">Id</th>
                    <th>User</th>
                    <th width="160">Last login</th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="3">No results</td></tr>'; ?>
        
        <?php foreach ($users as $user) { ?>
            <?php
            $userIsOnline = $user->IsOnline();
            $lastLogin = $user->LastLoginDate;
            $lastLoginIp = $user->LastLoginIp;
            $lastActionDate = NULL;
            $lastActionIP = NULL;
            $lastAction = $user->GetSession();
            if ($lastAction) {
                $lastActionDate = $lastAction->Updated;
                $lastActionIP = $lastAction->IPAddress;
            }
            
            $myApps = array();
            foreach ($apps as $app) {
                if (Account_App::Exists($user->Id, $app->Id)) {
                    $myApps[] = $app->Name;
                }
            }
            $countApps = count($myApps);
            if ($countApps > 0) {
                $myApps = "On " . $countApps . " Apps: " . implode(", ", $myApps);
            } else {
                $myApps = "";
            }
            
            $isConfirmed = empty($user->ActivationCode);
            ?>
            <tr class="<?php if (!$user->Enabled || !$isConfirmed) echo "record-disabled"; ?> <?php if ($userIsOnline) echo "user-online"; ?>">
                <td nowrap>
                    <button type="button" class="btn btn-danger" onclick="if (confirm('Delete this User?')) document.location.href='?action=delete&Id=<?= $user->Id ?>';" title="Delete"><i class="fa fa-trash-alt"></i></button>
                    <button type="button" class="btn btn-primary" onclick="document.location.href='?Id=<?= $user->Id ?>';" title="Edit"><i class="fa fa-edit"></i></button>
                </td>
                <td class="text-right"><?= $user->Id ?></td>
                <td>
                    <span class="record-title"><?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?></span>
                    <div class="record-details">
                        <ul>
                            <?php if ($user->Email) { ?><li><a title="Send an email" href="mailto:<?= htmlentities($user->Email) ?>"><?= htmlentities($user->Email) ?></a></li><?php } ?>
                            <li><?php if (!$isConfirmed) { ?>Waiting for confirmation<?php } else { ?><?= ($user->Enabled ? 'Account enabled' : 'Account disabled') ?><?php } ?></li>
                            <?php if ($lastAction) { ?><li>Last action: <?= date("j M Y H:i:s", Utils::GetTimestamp($lastActionDate)) ?> from IP <?= htmlentities($lastActionIP) ?></li><?php } ?>
                            <?php if ($myApps) { ?><li><?= $myApps ?></li><?php } ?>
                        </ul>
                    </div>
                </td>
                <td><?= (!$lastLogin ? "" : date("j M Y H:i", Utils::GetTimestamp($lastLogin)) . "<br/>IP " . $lastLoginIp) ?></td>
            </tr>

        <?php } ?>

            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="IdApp" value="<?= $idApp ?>"/>
                                <input type="hidden" name="Username" value="<?= htmlentities($username, ENT_QUOTES, 'UTF-8') ?>"/>
                                <input type="hidden" name="Email" value="<?= htmlentities($email, ENT_QUOTES, 'UTF-8') ?>"/>
                                <input type="hidden" name="Online" value="<?= htmlentities(filter_input(INPUT_POST, "Online"), ENT_QUOTES, 'UTF-8') ?>"/>
                                <h6>
                                    <?= $count ?> result(s) in <?= $pagesCount ?> page(s)
                                </h6>
                                <div class="form-row">
                                    <div class="col-auto">
                                        <select name="Page" class="form-control">
                                        <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                            <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>>Page <?= $i ?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <input type="submit" class="btn btn-default" value="Go"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>

    </fieldset>
            
<?php } else { ?>
    
    <p>
        &LeftArrow; <a href="?">Back to Users</a>
    </p>
    
    <?php if ($user->IsOnline()) { ?><p style="font-size: 1.1em;"><strong style="color: #009900;">THIS USER IS ONLINE</strong></p><?php } ?>
    
    <?= printAlertError($error) ?>

    <fieldset id="player-info">
        <legend>User Info</legend>
        
        <div id="tabs-player" class="bordered-tabs">
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item"><a class="nav-link active" id="tab-account-tab" data-toggle="tab" href="#tab-account" role="tab" aria-controls="tab-account" aria-selected="true"><i class="fa fa-user"></i>Profile</a></li>
                <?php if ($user->Id > 0) { ?>
                <li class="nav-item"><a class="nav-link" id="tab-custom-tab" data-toggle="tab" href="#tab-custom" role="tab" aria-controls="tab-custom" aria-selected="false"><i class="fa fa-globe"></i>Global Data</a></li>
                <li class="nav-item"><a class="nav-link" id="tab-appcustom-tab" data-toggle="tab" href="#tab-appcustom" role="tab" aria-controls="tab-appcustom" aria-selected="false"><i class="fa fa-info-circle"></i>App Data</a></li>
                <li class="nav-item"><a class="nav-link" id="tab-apps-tab" data-toggle="tab" href="#tab-apps" role="tab" aria-controls="tab-apps" aria-selected="false"><i class="fa fa-rocket"></i>Apps</a></li>
                <li class="nav-item"><a class="nav-link" id="tab-files-tab" data-toggle="tab" href="#tab-files" role="tab" aria-controls="tab-files" aria-selected="false"><i class="fa fa-paperclip"></i>Files</a></li>
                <li class="nav-item"><a class="nav-link" id="tab-contacts-tab" data-toggle="tab" href="#tab-contacts" role="tab" aria-controls="tab-contacts" aria-selected="false"><i class="fa fa-address-book"></i>Contacts</a></li>
                <li class="nav-item"><a class="nav-link" id="tab-leaderboards-tab" data-toggle="tab" href="#tab-leaderboards" role="tab" aria-controls="tab-leaderboards" aria-selected="false"><i class="fa fa-trophy"></i>Leaderboards</a></li>
                <li class="nav-item"><a class="nav-link" id="tab-achievements-tab" data-toggle="tab" href="#tab-achievements" role="tab" aria-controls="tab-achievements" aria-selected="false"><i class="fa fa-star"></i>Achievements</a></li>
                <?php } ?>
            </ul>

            <div class="tab-content">
                
                <div id="tab-account" class="tab-pane fade show active" role="tabpanel" aria-labelledby="tab-account-tab">
                    <form method="post">
                        <input type="hidden" name="action" value="save"/>
                    <?php if ($user->Id > 0) { ?>
                        <?php
                        $lastAction = $user->GetLastActionDate();
                        ?>
                        <div class="form-group">
                            Id: <strong><?= $user->Id ?></strong>
                            | Last action: <strong><?= (!$lastAction ? "-" : date("d M Y H:i:s", Utils::GetTimestamp($lastAction))) ?></strong>
                        </div>
                    <?php } ?>
                        <div class="form-group">
                            <label>Enabled</label>
                            <select class="form-control" name="Enabled">
                                <option value="0" <?php if (!$user->Enabled) echo 'selected'; ?>>NO</option>
                                <option value="1" <?php if ($user->Enabled) echo 'selected'; ?>>YES</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Username (current: <?= htmlentities($currentUsername, ENT_QUOTES, 'UTF-8') ?>)</label>
                            <input type="text" class="form-control" name="Username" value="<?= htmlentities($user->Username, ENT_QUOTES, 'UTF-8') ?>"/>
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="text" class="form-control" name="Email" value="<?= htmlentities($user->Email, ENT_QUOTES, 'UTF-8') ?>"/>
                        </div>
                        <div class="form-group">
                            <label>Activation Code</label>
                            <input type="text" class="form-control" name="ActivationCode" value="<?= htmlentities($user->ActivationCode, ENT_QUOTES, 'UTF-8') ?>"/>
                        </div>
                    <?php if ($user->Id > 0) { ?>
                        <h4 class="mt-4">Change Password</h4>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" class="form-control" name="NewPassword" value=""/>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" class="form-control" name="ConfirmPassword" value=""/>
                        </div>
                    <?php } else { ?>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" class="form-control" name="Password" value=""/>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" class="form-control" name="ConfirmPassword" value=""/>
                        </div>
                    <?php } ?>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                        or <a href="?">Cancel</a>
                    </form>
                </div>

                <?php if ($user->Id > 0) { ?>

                <div id="tab-custom" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-custom-tab">
                    <h4>The custom data of this user on all Apps</h4>
                    <h5 class="mt-4">Register a new Custom Data</h5>
                    <p>
                        <form method="post" id="form-create-custom">
                            <input type="hidden" name="action" value="custom_save"/>
                            <div class="form-group">
                                <label>New key</label>
                                <input type="text" class="form-control" id="key-create-custom" required name="custom_key" placeholder="Data key"/>
                            </div>
                            <div class="form-group">
                                <label>Value</label>
                                <input type="text" class="form-control" id="value-create-custom" name="custom_value" placeholder="Data value"/>
                            </div>
                            <button type="button" class="btn btn-primary" id="button-create-custom"><i class="fa fa-plus"></i> Add key</button>
                        </form>
                    </p>
                    <h5 class="mt-4">Registered Custom Data</h5>
                    <div id="divCustomDataContent"></div>
                </div>

                <div id="tab-appcustom" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-appcustom-tab">
                    <h4>The custom data of this user by App scope</h4>
                    <h5 class="mt-4">Select an App</h5>
                    <div class="form-group">
                        <select class="form-control" id="NewAppCustomDataApp">
                            <option value="0">[Select an App]</option>
                        <?php foreach ($myApps as $app) { ?>
                            <option value="<?= $app->Id ?>"><?= htmlentities($app->Name) ?></option>
                        <?php } ?>
                        </select>
                    </div>
                    <div id="appcustom-selected" class="mt-4">
                        <h5>Register a new Custom Data</h5>
                        Create a new key in the selected App scope
                        <form method="post">
                            <input type="hidden" name="action" value="save_appcustom"/>
                            <div class="form-group">
                                <label>New key</label>
                                <input type="text" class="form-control" id="key-create-appcustom" required="required" name="custom_key" placeholder="Data key"/>
                            </div>
                            <div class="form-group">
                                <label>Value</label>
                                <input type="text" class="form-control" id="value-create-appcustom" name="custom_value" placeholder="Data value"/>
                            </div>
                            <button type="button" id="button-create-appcustom" class="btn btn-primary"><i class="fa fa-plus"></i> Add key</button>
                        </form>
                        <h5 class="mt-4">Registered Custom Data</h5>
                        <div id="divAppCustomDataContent"></div>
                    </div>
                </div>

                <div id="tab-apps" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-apps">
                    <h4>Register the user to the following</h4>
                    <?php if (count($appsAvailableForRegister) == 0) { ?>
                        The user is already registered to all Apps.
                    <?php } else { ?>
                    <form method="post">
                        <input type="hidden" name="action" value="add_app"/>
                        <div class="form-group">
                            <label>Select an App</label>
                            <select class="form-control" name="app">
                            <?php foreach ($appsAvailableForRegister as $app) { ?>
                                <option value="<?= $app->Id ?>"><?= htmlentities($app->Name) ?></option>
                            <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Register</button>
                        </div>
                    </form>
                    <?php } ?>
                    <h4 class="mt-4">This user is registered to the following Apps</h4>
                    <div class="mt-4">
                    <?php if (count($myApps) == 0) { ?>
                        Not registered to any App.
                    <?php } else { ?>
                        <table class="table-records" width="100%">
                            <thead>
                                <tr>
                                    <th width="1"></th>
                                    <th>App</th>
                                    <th>Registration</th>
                                    <th>Last update</th>
                                </tr>
                            </thead>
                        <?php for ($i = 0; $i < count($myApps); $i++) { ?>
                            <?php
                            $app = $myApps[$i];
                            $appAccount = $myAppsAccount[$i];
                            ?>
                            <tr>
                                <form id="form-registered-app-<?= $app->Id ?>" method="post">
                                    <input type="hidden" name="action" value="delete_app"/>
                                    <input type="hidden" name="app" value="<?= $app->Id ?>"/>
                                    <td>
                                        <button type="button" class="btn btn-danger button-delete-app" data-form="form-registered-app-<?= $app->Id ?>" title="Remove registration to this App"><i class="fa fa-trash-alt"></i></button>
                                    </td>
                                    <td>
                                        <?= htmlentities($app->Name) ?>
                                    </td>
                                    <td>
                                        <?= date("d/m/Y H:i", Utils::GetTimestamp($appAccount->DateCreated)) ?>
                                    </td>
                                    <td>
                                        <?= date("d/m/Y H:i", Utils::GetTimestamp($appAccount->DateUpdated)) ?>
                                    </td>
                                </form>
                            </tr>
                        <?php } ?>
                        </table>
                    <?php } ?>
                    </div>
                </div>

                <div id="tab-files" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-files">
                    <h4>The files of this user</h4>
                    <div class="form-group">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#uploadFileModal"><i class="fa fa-plus"></i> Upload file</button>
                    </div>
                    <div class="mt-4">
                    <?php if (count($files) == 0) { ?>
                        No files found.
                    <?php } else { ?>
                        <?php foreach ($files as $file) { ?>
                            <?php
                            $fileCustomData = array();
                            if (!empty($file->CustomData)) {
                                $fileCustomData = json_decode($file->CustomData);
                            }
                            $fileExists = file_exists(UPLOAD_FOLDER . $file->Url);
                            ?>
                        <form id="form-userfile-<?= $file->Id ?>" method="post" class="userfile">
                            <input type="hidden" name="action" value="delete_file"/>
                            <input type="hidden" name="file" value="<?= $file->Id ?>"/>
                            <button type="button" class="btn btn-danger button-delete-file" data-form="form-userfile-<?= $file->Id ?>" title="Delete"><i class="fa fa-trash-alt"></i></button>
                            <button class="btn btn-primary" <?php if (count($fileCustomData) == 0) { ?> disabled <?php } ?> type="button" data-toggle="collapse" data-target="#file-custom-data-<?= $file->Id ?>" aria-expanded="false" aria-controls="collapseExample" title="Show custom data"><i class="fa fa-table"></i></button>
                            <button type="button" class="btn btn-default button-view-file" data-url="<?= URL_ROOT . URL_UPLOAD . $file->Url ?>" title="Download" <?= ($fileExists ? "" : "disabled") ?>><i class="fa fa-eye"></i></button>
                            <?= ($file->Name ? "<strong>" . htmlentities($file->Name) . "</strong>: " : "") ?><?= $file->Url ?>
                            <?php if (count($fileCustomData) > 0) { ?>
                                <div class="collapse mt-1" id="file-custom-data-<?= $file->Id ?>">
                                    <?php foreach ($fileCustomData as $dataKey => $dataValue) { ?>
                                        <span class="badge badge-info"><?= htmlentities($dataKey) ?>: <?= htmlentities($dataValue) ?></span>
                                    <?php } ?>
                                </div>
                            <?php } ?>
                        </form>
                        <?php } ?>
                    <?php } ?>
                    </div>
                </div>
                
                <div id="tab-contacts" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-leaderboards-tab">
                    <p>
                        <h5>Add a new contact</h5>
                        <form method="post">
                            <input type="hidden" name="action" value="contacts_add" />
                            <div class="form-group">
                                <label>Username or Id</label>
                                <input type="text" class="form-control" name="contact" required />
                            </div>
                            <div class="form-group">
                                <label>Type</label>
                                <select class="form-control" name="state">
                                    <option value="<?= FRIEND_STATE_ACCEPTED ?>">Friend</option>
                                    <option value="<?= FRIEND_STATE_IGNORE ?>">Ignored</option>
                                    <option value="<?= FRIEND_STATE_REQUEST ?>">Pending request</option>
                                    <option value="<?= FRIEND_STATE_REQUEST_PENDING ?>">Pending sent</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Add contact</button>
                            </div>
                        </form>
                    </p>
                    <?php
                    $contactsCard = array(
                        array( "title" => "Friends", "contacts" => $friends ),
                        array( "title" => "Ignored", "contacts" => $ignored ),
                        array( "title" => "Pending requests", "contacts" => $requests ),
                        array( "title" => "Pending sent", "contacts" => $requests_sent )
                    );
                    ?>
                    <?php for ($i = 0; $i < count($contactsCard); ++$i) { ?>
                        <?php
                        $card = $contactsCard[$i];
                        $isPendingSent = ($i == (count($contactsCard) - 1));
                        ?>
                    <p>
                        <h5><?= $card["title"] ?></h5>
                        <?php if (count($card["contacts"]) == 0) { ?>
                            No contacts
                        <?php } else { ?>
                            <table class="table-records" width="100%">
                                <thead>
                                    <tr>
                                        <th width="1"></th>
                                        <th>User</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($card["contacts"] as $contact) { ?>
                                    <?php $contactUser = new Account($isPendingSent ? $contact->IdAccount : $contact->IdFriend); ?>
                                    <tr>
                                        <td nowrap>
                                            <button type="button" class="btn btn-danger button-delete-contact" data-id="<?= $contactUser->Id ?>" title="Remove this contact"><i class="fa fa-trash-alt"></i></button>
                                            <button type="button" class="btn btn-default button-visit-contact" data-id="<?= $contactUser->Id ?>" title="Visit this profile" <?= ($contactUser->Id > 0 ? "" : "disabled") ?>><i class="fa fa-address-card"></i></button>
                                        </td>
                                        <td>
                                            <?= htmlentities($contactUser->Username) ?>
                                        </td>
                                    </tr>
                                <?php } ?>
                                </tbody>
                            </table>
                        <?php } ?>
                    </p>
                    <?php } ?>
                </div>

                <div id="tab-leaderboards" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-leaderboards-tab">
                    <h5>The scores of this user in all Leaderboards</h5>
                    <div class="mt-4">
                        <h6>Reset the scores of this user</h6>
                        <div class="form-group">
                            Deletes the scores of this user from all leaderboards.
                        </div>
                        <div class="form-group">
                            <button type="button" class="btn btn-danger" onclick="if (confirm('Delete all Scores from the user?')) document.location.href='?Id=<?= $user->Id ?>&action=delete_scores'" title="Delete the scores of this user from all Leaderboards">
                                <i class="fa fa-trash-alt"></i> RESET ALL
                            </button>
                        </div>
                    </div>
                    <?php foreach ($leaderboards as $leaderboard) { ?>
                        <?php
                        // Skip the leaderboards without any score sent
                        if ($leaderboardsScores[$leaderboard->Id]["total"]["score"] == 0) {
                            continue;
                        }
                        ?>
                    <div class="mt-5">
                        <h6>Leaderboard: <?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?></h6>
                        <div class="form-group">
                            <button type="button" class="btn btn-danger" onclick="if (confirm('Delete all Scores of this Leaderboard from the user?')) document.location.href='?Id=<?= $user->Id ?>&action=delete_scores&IdLeaderboard=<?= $leaderboard->Id ?>'" title="Delete the scores of this user from the Leaderboard">
                                <i class="fa fa-trash-alt"></i> RESET
                            </button>
                        </div>
                        <?php
                        $arrayScores = array(
                            array( "title" => "Today", "data" => $leaderboardsScores[$leaderboard->Id]["today"] ),
                            array( "title" => "Last Week", "data" => $leaderboardsScores[$leaderboard->Id]["week"] ),
                            array( "title" => "Last Month", "data" => $leaderboardsScores[$leaderboard->Id]["month"] ),
                            array( "title" => "All Time", "data" => $leaderboardsScores[$leaderboard->Id]["total"] )
                        );
                        ?>
                        <table class="table-records" width="100%">
                            <thead>
                                <tr>
                                    <th>Interval</th>
                                    <th width="100" class="text-right">Rank <img src="images/mapmarker.png" alt="Rank" title="Rank" /></th>
                                    <th width="150" class="text-right">Score <img src="images/flag_azure.png" alt="Score" title="Score" /></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($arrayScores as $value) { ?>
                                <tr>
                                    <td><?= $value["title"] ?></td>
                                    <td class="text-right"><?= $value["data"]["rank"] ?></td>
                                    <td class="text-right"><?= $value["data"]["score"] ?></td>
                                </tr>
                            <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <?php } ?>
                </div>

                <div id="tab-achievements" class="tab-pane fade" role="tabpanel" aria-labelledby="tab-achievements-tab">
                    <h4>The Achievements progress of this user</h4>
                    <div class="mt-4 mb-4">
                        <h4>Reset the scores of this user</h4>
                        <div class="form-group">
                            Deletes the progress of this user from all achievements.
                        </div>
                        <div class="form-group">
                            <button type="button" class="btn btn-danger" onclick="if (confirm('Reset all Achievements from the user?')) document.location.href='?Id=<?= $user->Id ?>&action=delete_achievements'" title="Remove all Achievements from this user">
                                <i class="fa fa-trash-alt"></i> RESET ALL
                            </button>
                        </div>
                    </div>
                    <table class="table-records" width="100%">
                        <thead>
                            <tr>
                                <th width="100">&nbsp;</th>
                                <th width="150" class="text-right">Progress</th>
                                <th>Achievement</th>
                            </tr>
                        </thead>
                        <tbody>
                    <?php foreach ($achievements as $achievement) { ?>
                            <tr>
                                <td>
                                    <button type="button" class="btn btn-danger" onclick="if (confirm('Reset this Achievement from the user?')) document.location.href='?Id=<?= $user->Id ?>&action=delete_achievements&IdAchievement=<?= $achievement["Id"] ?>'" title="Remove the Achievement from this user">
                                        <i class="fa fa-trash-alt"></i> RESET
                                    </button>
                                </td>
                                <td class="text-right"><?= $achievement["Progress"] ?>&percnt; <?= ($achievement["Finished"] > 1 ? " (x" . $achievement["Finished"] . ")" : "") ?></td>
                                <td><?= htmlentities($achievement["Title"], ENT_QUOTES, 'UTF-8') ?></td>
                            </tr>
                    <?php } ?>
                        </tbody>
                    </table>
                </div>
                <?php } ?>

            </div>
                
        </div>
        
    </fieldset>
 
    <div class="modal fade" id="uploadFileModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="uploadFileModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadFileModalLabel">Upload a new file for this user</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="add_file"/>
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" class="form-control" name="Name" />
                        </div>
                        <div class="form-group">
                            <label>File</label>
                            <input type="file" class="form-control" name="File" id="uploadNewFile"/>
                        </div>
                        <div class="form-group">
                            <label>Share Type</label>
                            <select class="form-control" name="ShareType">
                                <option value="<?= SHARETYPE_NOBODY ?>">Don't share</option>
                                <option value="<?= SHARETYPE_EVERYBODY ?>">Share with everyone</option>
                                <option value="<?= SHARETYPE_FRIENDS ?>">Share with friends</option>
                            </select>
                        </div>
                        <h6>Custom Data</h6>
                        <div class="form-group">
                            <input type="text" class="form-control" id="NewFileDataKey" placeholder="Enter a new key" />
                            <input type="text" class="form-control mt-1" id="NewFileDataValue" placeholder="Enter a new value" />
                        </div>
                        <div class="form-group">
                            <button type="button" class="btn btn-primary" id="buttonNewFileData"><i class="fa fa-plus"></i> Create key</button>
                        </div>
                        <div id="newFileCustomDataTemplate"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="buttonUpload"><i class="fa fa-upload"></i> Upload</button>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        
        $(function() {
            
            $("#tabs-player form").submit(function() {
                toggleBusy(true);
            });
            
            var userId = <?= ($user->Id > 0 ? $user->Id : "0") ?>;
            
            var divCustomDataContent = $("#divCustomDataContent");
            var createCustomInputKey = $("#key-create-custom");
            var createCustomInputValue = $("#value-create-custom");
            
            var divAppCustomDataContent = $("#divAppCustomDataContent");
            var selectedAppCustomApp = $("#NewAppCustomDataApp");
            var divAppCustomSelected = $("#appcustom-selected");
            var createAppCustomInputKey = $("#key-create-appcustom");
            var createAppCustomInputValue = $("#value-create-appcustom");
            
            divAppCustomSelected.hide();
            
            var customDataLoaded;
            var refreshCustomData = function() {
                divCustomDataContent.html("Loading data..");
                divCustomDataContent.load("?", { "Id": userId, "action": "custom_load" }, function() {
                    customDataLoaded();
                });
            }
            refreshCustomData();
            
            var saveCustomData = function(dataKey, dataValue, successCallback) {
                toggleBusy(true);
                $.post("?", { "Id": userId, "action": "custom_save", "custom_key": dataKey, "custom_value": dataValue })
                    .done(function(data) {
                        toggleBusy(false);
                        if (data.success) {
                            refreshCustomData();
                            if (successCallback) {
                                successCallback();
                            }
                        } else {
                            alert(data.message);
                        }
                    })
                    .fail(function() {
                        toggleBusy(false);
                    });
            };
            
            customDataLoaded = function() {
                $("form.customdata").submit(function() {
                    saveCustomData($(this).find("input[name='custom_key']").val(), $(this).find("input[name='custom_value']").val());
                    return false;
                });
                $("form.customdata .delete-custom").click(function(event) {
                    event.preventDefault();
                    if (confirm("Delete this Custom Data?")) {
                        var dataKey = $("#" + $(this).attr("data-form") + " input[name='custom_key']").val();
                        toggleBusy(true);
                        $.post("?", { "Id": userId, "action": "custom_delete", "custom_key": dataKey })
                            .done(function(data) {
                                toggleBusy(false);
                                if (data.success) {
                                    refreshCustomData();
                                } else {
                                    alert(data.message);
                                }
                            })
                            .fail(function() {
                                toggleBusy(false);
                            });
                    }
                });
            }
            
            $("#button-create-custom").click(function(event) {
                createCustomInputKey.val(createCustomInputKey.val().trim());
                createCustomInputValue.val(createCustomInputValue.val().trim());
                if (document.getElementById("form-create-custom").checkValidity() !== false) {
                    saveCustomData(createCustomInputKey.val(), createCustomInputValue.val(), function() {
                        createCustomInputKey.val("");
                        createCustomInputValue.val("");
                    });
                }
                event.preventDefault();
                event.stopPropagation();
            });
            
            
            var refreshAppCustomData = function() {
                var selectedApp = selectedAppCustomApp.val();
                if ($.isNumeric(selectedApp) && parseInt(selectedApp) > 0) {
                    divAppCustomSelected.show();
                    divAppCustomDataContent.html("Loading data..");
                    divAppCustomDataContent.load("?", { "Id": userId, "action": "appcustom_load", "IdApp": selectedApp }, function() {
                        appCustomDataLoaded();
                    });
                } else {
                    divAppCustomSelected.hide();
                }
            }
            
            var saveAppCustomData = function(dataKey, dataValue, successCallback) {
                var selectedApp = selectedAppCustomApp.val();
                toggleBusy(true);
                $.post("?", { "Id": userId, "action": "appcustom_save", "IdApp": selectedApp, "custom_key": dataKey, "custom_value": dataValue })
                    .done(function(data) {
                        toggleBusy(false);
                        if (data.success) {
                            refreshAppCustomData();
                            if (successCallback) {
                                successCallback();
                            }
                        } else {
                            alert(data.message);
                        }
                    })
                    .fail(function() {
                        toggleBusy(false);
                    });
            };
            
            var appCustomDataLoaded = function() {
                $("form.appcustomdata").submit(function() {
                    saveAppCustomData($(this).find("input[name='custom_key']").val(), $(this).find("input[name='custom_value']").val());
                    return false;
                });
                $("form.appcustomdata .delete-appcustom").click(function(event) {
                    event.preventDefault();
                    if (confirm("Delete this Custom Data?")) {
                        var selectedApp = selectedAppCustomApp.val();
                        var dataKey = $("#" + $(this).attr("data-form") + " input[name='custom_key']").val();
                        toggleBusy(true);
                        $.post("?", { "Id": userId, "action": "appcustom_delete", "IdApp": selectedApp, "custom_key": dataKey })
                            .done(function(data) {
                                toggleBusy(false);
                                if (data.success) {
                                    refreshAppCustomData();
                                } else {
                                    alert(data.message);
                                }
                            })
                            .fail(function() {
                                toggleBusy(false);
                            });
                    }
                });
            }
            
            $("#NewAppCustomDataApp").change(function() {
                refreshAppCustomData();
            });
            
            $("#button-create-appcustom").click(function(event) {
                event.preventDefault();
                createAppCustomInputKey.val(createAppCustomInputKey.val().trim());
                createAppCustomInputValue.val(createAppCustomInputValue.val().trim());
                if (createAppCustomInputKey.val()) {
                    saveAppCustomData(createAppCustomInputKey.val(), createAppCustomInputValue.val(), function() {
                        createAppCustomInputKey.val("");
                        createAppCustomInputValue.val("");
                    });
                }
            });
            
            $(".button-delete-app").click(function(event) {
                event.preventDefault();
                if (confirm('Delete the registration to this App?')) {
                    $("#" + $(this).attr("data-form")).submit();
                }
            });
            
            $("#buttonNewFileData").click(function(event) {
                event.preventDefault();
                var newKey = $("#NewFileDataKey").val().trim();
                var newValue = $("#NewFileDataValue").val().trim();
                $("#NewFileDataKey").val("");
                $("#NewFileDataValue").val("");
                if (newKey) {
                    var newDiv = $("<div/>");
                    
                    var inputNewKey = $("<input/>");
                    inputNewKey.attr("type", "hidden");
                    inputNewKey.attr("name", "custom_key[]");
                    inputNewKey.attr("value", newKey);
                    inputNewKey.appendTo(newDiv);
                    
                    var buttonDeleteKey = $("<button/>");
                    buttonDeleteKey.addClass("btn btn-danger mr-1");
                    buttonDeleteKey.attr("type", "button");
                    buttonDeleteKey.html('<i class="fa fa-trash-alt"></i> Delete');
                    buttonDeleteKey.appendTo(newDiv);
                    buttonDeleteKey.click(function() {
                        $(this).parent().remove();
                    });
                    
                    var labelNewKey = $("<label/>");
                    labelNewKey.text(newKey);
                    labelNewKey.appendTo(newDiv);
                    
                    var inputNewValue = $("<input/>");
                    inputNewValue.addClass("form-control");
                    inputNewValue.attr("type", "text");
                    inputNewValue.attr("name", "custom_value[]");
                    inputNewValue.attr("value", newValue);
                    inputNewValue.appendTo(newDiv);
                    
                    $("#newFileCustomDataTemplate").append(newDiv);
                }
            });
            $("#buttonUpload").click(function(event) {
                event.preventDefault();
                if (document.getElementById("uploadNewFile").files.length == 0) {
                    alert("Select the file to upload");
                    return;
                }
                if (confirm("Confirm to upload the file with these informations?")) {
                    $("#uploadFileModal").modal("hide");
                    toggleBusy(true);
                    $("#uploadFileModal form").submit();
                }
            });
            
            $(".button-delete-file").click(function(event) {
                event.preventDefault();
                if (confirm('Delete this File?')) {
                    $(this).closest("form").submit();
                }
            });
            
            $(".button-view-file").click(function(event) {
                event.preventDefault();
                window.open($(this).attr("data-url"));
            });
            
            $(".button-delete-contact").click(function(event) {
                event.preventDefault();
                if (confirm('Remove this Contact?')) {
                    toggleBusy(true);
                    document.location.href = "?Id=" + userId + "&action=contacts_remove&contact=" + $(this).attr("data-id");
                }
            });
            
            $(".button-visit-contact").click(function(event) {
                event.preventDefault();
                toggleBusy(true);
                document.location.href = "?Id=" + $(this).attr("data-id");
            });
            
            // Set active tab from URL (ex.: #tab-apps)
            var iAnchorName = document.location.href.lastIndexOf("#");
            if (iAnchorName != -1) {
                var tabId = document.location.href.substring(iAnchorName) + "-tab";
                var activeTab = $(tabId);
                if (activeTab.length > 0) {
                    activeTab.tab("show");
                }
            }
        });
    </script>

<?php } ?>

<?php include './footer.php'; ?>