<?php

include_once './common.php';

use Combu\Utils;
use Combu\Mail;
use Combu\Newsletter;
use Combu\NewsletterLog;
use Combu\AdminAccount;
use Combu\Account;
use Combu\AppId;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

// Disable the execution time limit to allow sending large amount of mails
set_time_limit(0);

$newsletter = (!isset($_REQUEST["Id"]) ? NULL : new Newsletter(intval($_REQUEST["Id"])));
$error = NULL;

/**
 * Verify the current action
 */
switch (getRequestInput("action")) {

    // Action Save
    case "save":
        if ($newsletter) {
            Utils::FillObjectFromRequest($newsletter);
            if (!$newsletter->Subject) {
                $error = "Enter the Subject";
            } else if (!$newsletter->Body) {
                $error = "Enter the Body";
            } else {
                if ($newsletter->Id < 1) {
                    $newsletter->IdAccount = $AdminLogged->Id;
                }
                if ($newsletter->Save()) {

                    // Send newsletter to test address
                    $testsent = NULL;
                    if (isset($_REQUEST["testsend"]) && $_REQUEST["testsend"] == "Send") {
                        $email = (isset($_REQUEST["testemail"]) ? trim(stripslashes($_REQUEST["testemail"])) : "");
                        if ($email) {
                            $testsent = "0";
                            $mail = new Mail();
                            $mail->prepare($newsletter->Subject, $newsletter->Body, $email, NEWSLETTER_SENDER_ADDRESS, NEWSLETTER_SENDER_NAME);
                            if ($mail->Send()) {
                                $testsent = "1";
                            } else {
                                $testsent .= "&send_error=" . urlencode($mail->ErrorInfo);
                            }
                        }
                    }

                    // Return to list
                    Utils::RedirectTo("?saved=1" . ($testsent !== NULL ? "&Id=" . $newsletter->Id . "&testsent=" . $testsent : ""));
                } else
                    $error = "An error occurred";
            }
        }
        break;

    // Action Delete
    case "delete":
        if ($newsletter) {
            $newsletter->Delete();
        }
        // Return to list
        Utils::RedirectTo("?deleted=1");
        break;

    // Action Delete Score
    case "send":
        if ($newsletter) {
            $success = $newsletter->Send();
            Utils::RedirectTo("?sent=" . ($success ? "1" : "0") . "&sentId=" . $newsletter->Id);
        } else {
            // Return to list
            Utils::RedirectTo("?saved=1");
        }
        break;

}

$saved = (!$error) && (filter_input(INPUT_GET, "saved") === "1");
$deleted = (!$error) && (filter_input(INPUT_GET, "deleted") === "1");
$testsent = (!$error) && (filter_input(INPUT_GET, "testsent") === "1");
$send_error = (!$error) ? filter_input(INPUT_GET, "send_error")  : "";

$apps = AppId::Load();

// Display list if there is no active record
if (!$newsletter) {
    $sentNewsletter = (isset($_REQUEST["sentId"]) ? new Newsletter(intval($_REQUEST["sentId"])) : NULL);
    $limit = DEFAULT_LIST_LIMIT;
    $page = getRequestInput("Page", 1);
    $idApp = getRequestInput("IdApp", 0);
    $count = 0;
    $newsletters = Newsletter::Load($idApp, $limit, Utils::GetPageOffset($page, $limit), $count);
    $pagesCount = Utils::GetPagesCount($count, $limit);
}

?>
<?php include './header.php'; ?>

<?= printAlertDisappearSaved($saved) ?>
<?php if ($saved && isset($_REQUEST["testsent"])) { ?><?= printAlertDisappear($testsent ? "The newsletter has been sent to the test address." : "An error occurred sending the newsletter to the test address." . ($send_error ? "<br/>" . htmlentities($send_error) : "")) ?><?php } ?>
<?= printAlertDisappearDeleted($deleted) ?>

<?php if (!$newsletter) { ?>

    <fieldset id="list">
        <legend>Newsletters</legend>
        
        <?php if ($sentNewsletter) { ?>
            <?php if (intval($_REQUEST["sent"]) == 1) { ?>
            <div style="color:green;">The newsletter was sent</div>
            <?php } else { ?>
            <div style="color:red;">The newsletter failed</div>
            <?php } ?>
        <?php } ?>
        
        <form method="post">
            <div class="form-group">
                <label>App Scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($idApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($idApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
                <?php } ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><i class="fa fa-search"></i> Search</button>
                <button type="button" class="btn btn-default" onclick="document.location.href = '?';"><i class="fa fa-undo"></i> Reset</button>
                <button type="button" class="btn btn-primary float-right" onclick="document.location.href = '?Id=0';"><i class="fa fa-plus"></i> Create Newsletter</button>
            </div>
        </form>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="1"></th>
                    <th width="150">App</th>
                    <th align="left">Subject</th>
                    <th width="250" class="text-right">Info</th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="4">No results</td></tr>'; ?>
        <?php
        $i = 0;
        $max = count($newsletters);
        ?>
        <?php foreach ($newsletters as $newsletter) { ?>
            <?php
            $i++;
            $log = json_decode($newsletter->LogMessage, TRUE);
            $account = new AdminAccount($newsletter->IdAccount);
            $app = new AppId($newsletter->IdApp);
            ?>
            
            <tr>
                <td nowrap>
                    <button class="btn btn-danger" onclick="if (confirm('Delete this Newsletter?')) document.location.href='?action=delete&Id=<?= $newsletter->Id ?>';" title="Delete"><i class="fa fa-trash-alt"></i></button>
                    <button class="btn btn-primary" onclick="document.location.href='?Id=<?= $newsletter->Id ?>';" title="Edit"><i class="fa fa-edit"></i></button>
                    <?php if ($newsletter->Status == NEWSLETTER_STATUS_READY) { ?><button class="btn btn-default" onclick="if (confirm('Send this Newsletter?')) document.location.href='?action=send&Id=<?= $newsletter->Id ?>';" title="Send"><i class="fa fa-envelope"></i></button><?php } ?>
                    <?php if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?><button class="btn btn-default" onclick="document.location.href='?action=logs&Id=<?= $newsletter->Id ?>';" title="Log"><i class="fa fa-list-alt"></i></button><?php } ?>
                </td>
                <td><?= ($app->IsValid() ? htmlentities($app->Name) : '<span style="color:#CCC;">Any App</em>') ?></td>
                <td><?= htmlentities($newsletter->Subject, ENT_QUOTES, 'UTF-8') ?></td>
                <td class="text-right">
                    Created at <strong><?= strftime("%d %b %Y %H:%M", Utils::GetTimestamp($newsletter->DateCreation)) ?></strong>
                    <?php if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?><br/>Sent: <?= $log["sent"] ?> | Skipped: <?= $log["skipped"] ?> | Errors: <?= $log["errors"] ?><?php } ?>
                </td>
            </tr>
            
        <?php } ?>
        
            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="IdApp" value="<?= $idApp ?>"/>
                                <h6>
                                    <?= $count ?> result(s) in <?= $pagesCount ?> page(s)
                                </h6>
                                <div class="form-row">
                                    <div class="col-auto">
                                        <select name="Page" class="form-control">
                                        <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                            <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>>Page <?= $i ?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <input type="submit" class="btn btn-default" value="Go"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>

    </fieldset>
            
<?php } else { ?>

    <?php if (isset($_REQUEST["action"]) && $_REQUEST["action"] == "logs") { ?>

    &LeftArrow; <a href="?">Back to Newsletters</a>
    
    <fieldset id="list">
        <legend>Mail log from: <?= htmlentities($newsletter->Subject, ENT_QUOTES, 'UTF-8') ?></legend>
        <?php
        $limit = DEFAULT_LIST_LIMIT;
        $page = (!isset($_REQUEST["Page"]) ? 1 : intval($_REQUEST["Page"]));
        $count = 0;
        $order = "";
        $field = "";
        $logs = NewsletterLog::Load($newsletter->Id, $limit, Utils::GetPageOffset($page, $limit), $count);
        $pagesCount = Utils::GetPagesCount($count, $limit);
        ?>
        
        <table class="table-records" width="100%">
            <thead>
                <tr>
                    <th width="200">Player</th>
                    <th width="200">Email</th>
                    <th width="80">Status</th>
                    <th class="text-right">Info</th>
                </tr>
            </thead>
            <tbody>
        <?php if ($count == 0) echo '<tr><td colspan="4">No results</td></tr>'; ?>

        <?php foreach ($logs as $log) { ?>
        
        <?php $user = new Account($log->IdAccount); ?>
                <tr>
                    <td><?= ($user->Username ? htmlentities($user->Username, ENT_QUOTES, 'UTF-8') : '<span style="color:#999;">(invalid account)</span>') ?></td>
                    <td><?= htmlentities($user->Email, ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= ($log->Sent ? '<span style="color:green;">SENT</span>' : '<span style="color:red;">ERROR</span>') ?></td>
                    <td class="text-right"><?= $log->DateCreation . " " . htmlentities($log->Message, ENT_QUOTES, 'UTF-8') ?></td>
                </tr>

        <?php } ?>
        
            </tbody>
            <tfoot>
        <?php if ($count > 0) { ?>
                <tr>
                    <td colspan="4">
                        <div class="navpages">
                            <form method="post">
                                <input type="hidden" name="action" value="logs"/>
                                <input type="hidden" name="Id" value="<?= $newsletter->Id ?>"/>
                                <h6>
                                    <?= $count ?> result(s) in <?= $pagesCount ?> page(s)
                                </h6>
                                <div class="form-row">
                                    <div class="col-auto">
                                        <select name="Page" class="form-control">
                                        <?php for ($i = 1; $i <= $pagesCount; $i++) { ?>
                                            <option value="<?= $i ?>" <?php if ($i == $page) echo ' selected'; ?>>Page <?= $i ?></option>
                                        <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <input type="submit" class="btn btn-default" value="Go"/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </td>
                </tr>
        <?php } ?>
            </tfoot>
        </table>
        
    </fieldset>

    <?php } else { ?>

    <p>
        &LeftArrow; <a href="?">Back to Newsletters</a>
    </p>
    
    <?= printAlertError($error) ?>
    
    <fieldset>
        <legend>Newsletter Info</legend>

        <form id="formEdit" method="post">
            <input type="hidden" name="action" value="save"/>
            <?php if ($newsletter->Id > 0) { ?>
                <div class="form-group">
                    <label>Id:</label>
                    <strong><?= $newsletter->Id ?></strong>
                    | <label>App scope:</label>
                    <?php
                    $app = new AppId($newsletter->IdApp);
                    ?>
                    <strong><?= ($app->IsValid() ? htmlentities($app->Name) : "Any App") ?></strong>
                </div>
            <?php } else { ?>
            <div class="form-group">
                <label>App scope</label>
                <select class="form-control" name="IdApp">
                    <option value="0" <?php if ($newsletter->IdApp <= 0) echo ' selected'; ?>>[Any App]</option>
                <?php foreach ($apps as $app) { ?>
                    <option value="<?= $app->Id ?>" <?php if ($newsletter->IdApp == $app->Id) echo ' selected'; ?>><?= htmlentities($app->Name) ?></option>
                <?php } ?>
                </select>
            </div>
            <?php } ?>
            <div class="form-group">
                <label>Is HTML</label>
            <?php if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?>
                <br/><strong><?= ($newsletter->IsHtml == 1 ? "Yes" : "No") ?></strong>
            <?php } else { ?>
                <select class="form-control" id="IsHtml" name="IsHtml">
                    <option value="1" <?php if ($newsletter->IsHtml == 1) echo ' selected'; ?>>Yes</option>
                    <option value="0" <?php if ($newsletter->IsHtml == 0) echo ' selected'; ?>>No</option>
                </select>
            <?php } ?>
            </div>
            <div class="form-group">
                <label>Subject</label>
                <?php if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?>
                    <br/><strong><?= htmlentities($newsletter->Subject, ENT_QUOTES, 'UTF-8') ?></strong>
                <?php } else { ?>
                    <input type="text" class="form-control" name="Subject" value="<?= htmlentities($newsletter->Subject, ENT_QUOTES, 'UTF-8') ?>"/>
                <?php } ?>
            </div>
            <div class="form-group">
                <label>Body</label>
                <?php if ($newsletter->Status == NEWSLETTER_STATUS_SENT) { ?>
                    <br/><?= ($newsletter->IsHtml ? $newsletter->Body : htmlentities($newsletter->Body, ENT_QUOTES, 'UTF-8')) ?>
                <?php } else { ?>
                    <textarea class="form-control" id="Body" name="Body"><?= htmlentities($newsletter->Body, ENT_QUOTES, 'UTF-8') ?></textarea>
                <?php } ?>
            </div>
            <div class="form-group">
                <?php if ($newsletter->Status == NEWSLETTER_STATUS_READY) { ?>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button> or
                <?php } ?>
                <a href="?">Cancel</a>
            </div>
            <?php if ($newsletter->Status == NEWSLETTER_STATUS_READY) { ?>
                <div class="form-group mt-5">
                    <h5>Save and send to test address</h5>
                    <input type="text" class="form-control" name="testemail" placeholder="Enter an e-mail address as recipient"/>
                </div>
                <div class="form-group">
                    <button type="submit" name="testsend" value="Send" class="btn btn-default"><i class="fa fa-envelope"></i> Save and send test</button>
                </div>
            <?php } ?>
        </form>

    </fieldset>
    
    <script type="text/javascript">
        $(function () {
            tinymce.init({
                selector:'textarea', menubar : false, width: '100%', height: 150, plugins: "textcolor link image autoresize",
                toolbar: [ "undo redo | styleselect | fontsizeselect | forecolor backcolor | bold italic | link image | alignleft aligncenter alignright | bullist numlist outdent indent" ]
            });
            var fieldBody = $("#formEdit textarea[name=Body]");
            $("#formEdit select[name=IsHtml]").change(function() {
                if ($(this).val() == "1") {
                    var bodyText = "<p>" + fieldBody.val() + "</p>";
                    bodyText = bodyText.replace(/\n\n/g, "</p><p>");
                    bodyText = bodyText.replace(/\n/g, "<br>");
                    fieldBody.val(bodyText);
                    tinymce.activeEditor.show();
                } else {
                    tinymce.activeEditor.hide();
                    fieldBody.val(tinymce.activeEditor.getContent({format : 'text'}));
                }
            });
            
            $("#formEdit").submit(function() {
                toggleBusy(true);
            });
        });
    </script>

    <?php } ?>

<?php } ?>

<?php include './footer.php'; ?>