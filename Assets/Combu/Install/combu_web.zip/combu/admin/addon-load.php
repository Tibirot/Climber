<?php

include_once './common.php';

use Combu\Utils;
use Combu\AddonModule;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

$addonLoadedName = filter_input(INPUT_GET, "addon");
$addonLoadedMenu = intval(filter_input(INPUT_GET, "menu"));

// Load the addon
$addonLoaded = AddonModule::GetAddon($addonLoadedName);
if (!$addonLoaded) {
    Utils::RedirectTo("index.php");
}

// Verify that admin menu is valid
$menu = $addonLoaded->GetAdminMenu();
if ($addonLoadedMenu < 0 || $addonLoadedMenu >= count($menu)) {
    Utils::RedirectTo("index.php");
}

// Verify that requested menu url exists
$addonLoadedFile = $addonLoaded->GetFile($menu[$addonLoadedMenu]["Url"]);
if (!file_exists($addonLoadedFile)) {
    Utils::RedirectTo("index.php");
}

// Load the addon page
include './header.php';
include $addonLoadedFile;
include './footer.php';

?>
<script>
    $(function () {
        $("#menu .menu-section-link[data-addon-menu='<?= $addonLoaded->Id ?>-<?= $addonLoadedMenu ?>']").addClass("menu-section-active");
    });
</script>