<?php

include_once './common.php';

use League\Csv\Writer;
use Combu\Utils;
use Combu\Account;
use Combu\CustomData;
use Combu\Inventory;
use Combu\UserFile;
use Combu\LeaderBoard;
use Combu\LeaderBoard_User;
use Combu\Achievement;
use Combu\Achievement_User;
use Combu\SessionToken;
use Combu\GameMail;
use Combu\Tournament;
use Combu\Newsletter;

// Verify the current login session
if (!$AdminLogged->IsLogged()) {
    Utils::RedirectTo("./");
}

// Disable the execution time limit to allow sending large amount of mails
set_time_limit(0);

function doPrune() {
    $tables = getRequestInput("tables", NULL, TRUE);
    if (!$tables) {
        $error = "Export: No tables selected";
    } else {
        foreach ($tables as $table) {
            switch ($table) {
                case "players":
                    Account::Prune();
                    break;
                case "leaderboards":
                    LeaderBoard::Prune();
                    break;
                case "achievements":
                    Achievement::Prune();
                    break;
                case "tokens":
                    SessionToken::Prune();
                    break;
                case "tournaments":
                    Tournament::Prune();
                    break;
                case "players_data":
                    CustomData::Prune();
                    LeaderBoard_User::Prune();
                    Achievement_User::Prune();
                    break;
                case "inventories":
                    Inventory::Prune();
                    break;
                case "files":
                    UserFile::Prune();
                    break;
                case "mails":
                    GameMail::Prune();
                    break;
                case "newsletters":
                    Newsletter::Prune();
                    break;
            }
        }
        Utils::RedirectTo("?success=1&message=" . urlencode("The selected data have been pruned"));
    }
}

function doExport() {
    $error = NULL;
    $table = getRequestInput("table");
    switch ($table) {
        case "players":
            $default = new Account();
            $source = Account::LoadAny();
            break;
        case "leaderboards":
            $default = array(
                "IdLeaderboard",
                "Leaderboard",
                "Id",
                "Rank",
                "User",
                "Score"
            );
            $source = array();
            $leaderboards = LeaderBoard::Load();
            foreach ($leaderboards as $leaderboard) {
                $highscores = $leaderboard->LoadHighscore(LeaderBoard::HIGHSCORE_TOTAL);
                if (count($highscores) > 0) {
                    foreach ($highscores as $score) {
                        $source[] = array_merge(array("Leaderboard"=>$leaderboard->Title), $score);
                    }
                } else {
                    $source[] = array(
                        "IdLeaderboard" => $leaderboard->Id,
                        "Leaderboard" => $leaderboard->Title,
                        "Id" => "",
                        "Rank" => "",
                        "User" => "",
                        "Score" => ""
                    );
                }
            }
            break;
        case "achievements":
            $default = array(
                "IdAchievement",
                "Achievement",
                "Id",
                "User",
                "Progress"
            );
            $source = array();
            $achievements = Achievement::Load();
            foreach ($achievements as $achievement) {
                $users = Achievement_User::Load($achievement->Id);
                if (count($users) > 0) {
                    foreach ($users as $user) {
                        $account = new Account($user->IdAccount);
                        $source[] = array(
                            "IdAchievement" => $achievement->Id,
                            "Achievement" => $achievement->Title,
                            "Id" => $user->Id,
                            "User" => $account->ToJson(),
                            "Progress" => $user->Progress
                        );
                    }
                } else {
                    $source[] = array(
                        "IdAchievement" => $achievement->Id,
                        "Achievement" => $achievement->Title,
                        "Id" => "",
                        "User" => "",
                        "Progress" => ""
                    );
                }
            }
            break;
        default:
            $error = "Invalid entity";
            break;
    }
    if ($error) {
        $error = "Export: Entity invalid or not selected";
    } else {
        try {
            $header = array();
            if (is_array($default)) {
                $header = $default;
            } else {
                $props = get_class_vars(get_class($default));
                foreach ($props as $prop => $value) {
                    $header[] = $prop;
                }
            }
            $records = array();
            foreach ($source as $r) {
                $record = array();
                foreach ($header as $prop) {
                    if (is_array($r)) {
                        $record[$prop] = $r[$prop];
                    } else {
                        $record[$prop] = $r->$prop;
                    }
                }
                $records[] = $record;
            }
            $csv = Writer::createFromString('');
            $csv->setDelimiter(';');
            $csv->setNewline("\r\n");
            $csv->insertOne($header);
            $csv->insertAll($records);
            ob_clean();
            header("Content-Type: text/csv");
            header("Content-Disposition: attachment; filename=" . $table . "_" . Utils::GetCurrentDateTimeFormat("Ymd") . ".csv");
            header("Pragma: no-cache");
            header("Expires: 0");
            echo $csv;
        } catch (Exception $ex) {
            $error = "Export: " . $ex->getMessage();
        }
    }
    if ($error) {
        echo $error;
    }
    exit();
}

function saveCustomFile($content, $path, $actionRedirect, $url) {
    global $error;
    $fileContent = "";
    $lines = explode("\n", $content);
    foreach ($lines as $line) {
        $text = trim($line);
        if (!empty($text)) {
            $fileContent .= $text . "\n";
        }
    }
    $empty = empty($fileContent);
    try {
        if ($empty && file_exists($path)) {
            unlink($path);
        } else if (!$empty) {
            file_put_contents($path, $fileContent);
        }
        Utils::RedirectTo("?action=" . $actionRedirect . "&success=1");
    } catch (\Exception $ex) {
        $error = "An error occurred trying to save <em>" . $url . "</em>: " . $ex->getMessage();
    }
}

function doSaveCSS() {
    global $file_css;
    saveCustomFile(getRequestInput("CSS"), $file_css, "editcss", "./css/custom.css");
}

function doSaveJS() {
    global $file_js;
    saveCustomFile(getRequestInput("JS"), $file_js, "editjs", "./js/custom.js");
}

function getUploadsNotFound() {
    $uploads = array();
    $entries = Utils::GetAllFiles(UPLOAD_FOLDER);
    foreach ($entries as $entry) {
        $url = str_replace(UPLOAD_FOLDER, "", $entry);
        $file = UserFile::LoadByUrl($url);
        if (!$file) {
            $uploads[] = $entry;
        }
    }
    return $uploads;
}

function doDeleteUploads() {
    $files = getRequestInput("file", array(), TRUE);
    if (!empty($files)) {
        foreach ($files as $file) {
            if (file_exists($file)) {
                try {
                    unlink($file);
                } catch (Exception $ex) {
                }
            }
        }
    }
    Utils::RedirectTo("?");
}

$action = getRequestInput("action");
$success = (getRequestInput("success") === "1");
$message = getRequestInput("message");

$result = "";
$error = NULL;
$file_css = __DIR__ . "/css/custom.css";
$file_css_url = ADMIN_ROOT_URL . "css/custom.css";
$file_js = __DIR__ . "/js/custom.js";
$file_js_url = ADMIN_ROOT_URL . "js/custom.js";
$uploadsNotFound = getUploadsNotFound();

if ($action == "editcss" && $success) {
    $message = "Changes saved to your custom CSS and should have been already applied, if you don't see them in your browser try to force refresh or empty your browser cache";
}

switch ($action) {
    case "Prune":
        doPrune();
        break;
    
    case "Export":
        doExport();
        break;

    case "SaveCSS";
        doSaveCSS();
        $action = "editcss";
        break;

    case "SaveJS";
        doSaveJS();
        $action = "editjs";
        break;
    
    case "DeleteUploads":
        doDeleteUploads();
        break;
                
}

$tables = array(
    array( "table" => "players", "label" => "Users", "prune" => TRUE, "export" => TRUE ),
    array( "table" => "leaderboards", "label" => "Leaderboards", "prune" => TRUE, "export" => TRUE ),
    array( "table" => "achievements", "label" => "Achievements", "prune" => TRUE, "export" => TRUE ),
    array( "table" => "tokens", "label" => "Session Tokens", "prune" => TRUE, "export" => FALSE ),
    array( "table" => "mails", "label" => "Game Messages", "prune" => TRUE, "export" => FALSE ),
    array( "table" => "tournaments", "label" => "Tournaments & Matches", "prune" => TRUE, "export" => FALSE ),
    array( "table" => "players_data", "label" => "User Data", "prune" => TRUE, "export" => FALSE ),
    array( "table" => "files", "label" => "User Files", "prune" => TRUE, "export" => FALSE ),
    array( "table" => "inventories", "label" => "Inventories", "prune" => TRUE, "export" => FALSE ),
    array( "table" => "mails", "label" => "Game Messages", "prune" => TRUE, "export" => FALSE ),
    array( "table" => "newsletters", "label" => "Newsletters", "prune" => TRUE, "export" => FALSE )
);

?>
<?php include './header.php'; ?>

<?= printAlertDisappear(!$success ? "" : $message) ?>
<?= printAlertError($error) ?>

<?php if ($result) { ?><p><?= $result ?></p><?php } ?>

<?php if ($action == "editcss") { ?>

    <p>
        &LeftArrow; <a href="?">Back to Tools</a>
    </p>
    
    <!-- EDIT CUSTOM CSS -->
    <?php
    $cssContent = "";
    if (file_exists($file_css) && is_readable($file_css)) {
        try {
            $cssContent = file_get_contents($file_css);
        } catch (Exception $ex) {
            $cssContent = "";
        }
    }
    ?>
    <fieldset>
        <legend>Customize the administration interface</legend>
        <form action="?" method="post">
            <input type="hidden" name="action" value="SaveCSS"/>
            <div class="form-group">
                <label for="inputCSS">Add the following CSS code to customize the default interface</label>
                <textarea name="CSS" id="inputCSS" class="form-control" placeholder="Override the default CSS classes to customize the layout"><?= htmlentities($cssContent, ENT_QUOTES, 'UTF-8') ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save CSS</button>
        </form>
    </fieldset>

<?php } else if ($action == "editjs") { ?>

    <p>
        &LeftArrow; <a href="?">Back to Tools</a>
    </p>
    
    <!-- EDIT CUSTOM JS -->
    <?php
    $jsContent = "";
    if (file_exists($file_js) && is_readable($file_js)) {
        try {
            $jsContent = file_get_contents($file_js);
        } catch (Exception $ex) {
            $jsContent = "";
        }
    }
    ?>
    <fieldset>
        <legend>Customize the administration interaction</legend>
        <form action="?" method="post">
            <input type="hidden" name="action" value="SaveJS"/>
            <div class="form-group">
                <label for="inputJS">Add the following Javascript code in all pages to customize the interaction (jQuery and bootstrap are supported)</label>
                <textarea name="JS" id="inputJS" class="form-control" placeholder="Add your own javascript to all pages"><?= htmlentities($jsContent, ENT_QUOTES, 'UTF-8') ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save JS</button>
        </form>
    </fieldset>

<?php } else { ?>

    <!-- TOOLS HOME -->
    
    <div id="accordion" class="collapsible-container">
        
        <div class="card">
            <div class="card-header" id="card-upgrade">
                <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#card-upgrade-content" aria-expanded="false" aria-controls="card-upgrade-content">
                        Upgrade
                    </button>
                </h5>
            </div>
            <div id="card-upgrade-content" class="collapse" aria-labelledby="card-upgrade" data-parent="#accordion">
                <div class="card-body">
                    <a href="update.php">Click here</a> to check for server updates.
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header" id="card-utilities">
                <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#card-utilities-content" aria-expanded="false" aria-controls="card-utilities-content">
                        Utilities
                    </button>
                </h5>
            </div>
            <div id="card-utilities-content" class="collapse" aria-labelledby="card-utilities" data-parent="#accordion">
                <div class="card-body">
                    <ul>
                        <!-- Edit CSS -->
                        <?php if (file_exists($file_css)) { ?>
                            <?php if (is_writable($file_css)) { ?>
                                <li><a href="?action=editcss">Customize interface</a>: you can add custom CSS code to change the look &amp; feel of the administration area</li>
                            <?php } else { ?>
                                <li>It seems the permission to edit your custom CSS is denied, please check the file permission of <?= $file_css_url ?> on your system</li>
                            <?php } ?>
                        <?php } else if (is_writable(__DIR__ . "/css")) { ?>
                            <li><a href="?action=editcss">Customize interface</a>: you can add custom CSS code to change the look &amp; feel of the administration area</li>
                        <?php } else { ?>
                            <li>It seems the permission to create files to the CSS folder is denied, please check the file permission of <?= ADMIN_ROOT_URL . "/css" ?> on your system</li>
                        <?php } ?>

                        <!-- EDIT JS -->
                        <?php if (file_exists($file_js)) { ?>
                            <?php if (is_writable($file_js)) { ?>
                                <li><a href="?action=editjs">Customize interaction</a>: you can add custom JS code to change the interactions of the administration area</li>
                            <?php } else { ?>
                                <li>It seems the permission to edit your custom JS is denied, please check the file permission of <?= $file_js_url ?> on your system</li>
                            <?php } ?>
                        <?php } else if (is_writable(__DIR__ . "/js")) { ?>
                            <li><a href="?action=editjs">Customize interaction</a>: you can add custom JS code to change the interactions of the administration area</li>
                        <?php } else { ?>
                            <li>It seems the permission to create files to the JS folder is denied, please check the file permission of <?= ADMIN_ROOT_URL . "/js" ?> on your system</li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header" id="card-uploads">
                <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#card-uploads-content" aria-expanded="false" aria-controls="card-uploads-content">
                        Check Uploads
                    </button>
                </h5>
            </div>
            <div id="card-uploads-content" class="collapse" aria-labelledby="card-uploads" data-parent="#accordion">
                <div class="card-body">
                <?php if (count($uploadsNotFound) == 0) { ?>
                    No invalid uploads found.
                <?php } else { ?>
                    <form id="form-uploads" method="post">
                        <input type="hidden" name="action" value="DeleteUploads" />
                        <div class="form-group">
                            <a href="#" class="select-all-checkboxes">Select all</a> | <a href="#" class="deselect-all-checkboxes">Deselect all</a>
                        </div>
                    <?php foreach ($uploadsNotFound as $entry) { ?>
                        <?php $entryPath = str_replace(UPLOAD_FOLDER, "", $entry); ?>
                        <div class="form-check mb-3">
                            <input type="checkbox" class="form-check-input" name="file[]" value="<?= htmlentities($entry) ?>"/>
                            <label class="form-check-label"><a href="<?= URL_ROOT . URL_UPLOAD . $entryPath ?>" target="_blank"><?= htmlentities($entryPath) ?></a></label>
                        </div>
                    <?php } ?>
                        <div class="form-group">
                            <input type="submit" class="btn btn-danger" value="Delete selected"/>
                        </div>
                    </form>
                <?php } ?>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header" id="card-prune">
                <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#card-prune-content" aria-expanded="false" aria-controls="card-prune-content">
                        Prune
                    </button>
                </h5>
            </div>
            <div id="card-prune-content" class="collapse" aria-labelledby="card-prune" data-parent="#accordion">
                <div class="card-body">
                    <form id="form-prune" method="post">
                        <label>Select what content to delete (<a href="#" class="select-all-checkboxes">Select all</a> | <a href="#" class="deselect-all-checkboxes">Deselect all</a>)</label>
                        <p>
                            <?php foreach ($tables as $t) { ?>
                                <?php if ($t["prune"]) { ?>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" name="tables[]" value="<?= $t["table"] ?>" id="prune-<?= $t["table"] ?>"/>
                                        <label class="form-check-label" for="prune-<?= $t["table"] ?>" style="display: inline;"><?= htmlentities($t["label"]) ?></label>
                                    </div>
                                <?php } ?>
                            <?php } ?>
                        </p>
                        <p>
                            <input type="submit" class="btn btn-danger" name="action" value="Prune"/>
                        </p>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header" id="card-export">
                <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#card-export-content" aria-expanded="false" aria-controls="card-export-content">
                        Export
                    </button>
                </h5>
            </div>
            <div id="card-export-content" class="collapse" aria-labelledby="card-export" data-parent="#accordion">
                <div class="card-body">
                    <form method="post">
                        <div class="field">
                            <label>Click one of the following links to export as CSV file</label>
                            <ul>
                            <?php foreach ($tables as $t) { ?>
                                <?php if ($t["export"]) { ?>
                                <li><a href="?action=Export&table=<?= urlencode($t["table"]) ?>" target="_blank"><?= htmlentities($t["label"]) ?></a></li>
                                <?php } ?>
                            <?php } ?>
                            </ul>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
    </div>

    <script>
        $(function() {
            
            $(".collapse").collapse();
            
            $(".select-all-checkboxes").click(function(e) {
                e.preventDefault();
                $(this).closest("form").find("input[type='checkbox']").prop('checked', true);
            });
            $(".deselect-all-checkboxes").click(function(e) {
                e.preventDefault();
                $(this).closest("form").find("input[type='checkbox']").prop('checked', false);
            });
            
            $("#form-prune form").submit(function() {
                if ($(this).find("input[type='checkbox']:checked").length == 0) {
                    alert("No content selected");
                    return false;
                }
                return confirm("Do you confirm to delete all data associated to the selection?");
            });
        });
    </script>

<?php } ?>

<?php include './footer.php'; ?>