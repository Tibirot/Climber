// Add .trim() method to strings
if(!String.prototype.trim) {  
    String.prototype.trim = function () {
        return this.replace(/^\s+|\s+$/g,'');  
    };
}

var dialogLoading = null;

$(function () {
    //$('[data-toggle="tooltip"]').tooltip();
    $('[title]').tooltip();

    dialogLoading = $("#dlg-loading");
    dialogLoading.modal({
        keyboard: false,
        backdrop: 'static'
    });
    toggleBusy(false);
    
    $(".ui-dialog[aria-describedby='dlg-loading'] .ui-dialog-titlebar-close").remove();
    $(".navpages form select[name=Page]").change(function() { $(".navpages form").submit(); });

    var disappearTexts = $("#dlg-alert-disappear");
    $.each(disappearTexts, function(index, value) {
        var disappearTime = $(value).attr("data-time");
        if ($.isNumeric(disappearTime)) {
            $(value).delay(parseInt(disappearTime) * 1000).fadeOut(500);
        }
    });

    $(document).on('keyup', '.numeric-only', function(event) {
        var v = this.value;
        if($.isNumeric(v) === false) {
            //chop off the last char entered
            this.value = this.value.slice(0,-1);
        }
    });

    $("table.table-records tbody tr:even").addClass("record-alt");
});

function toggleBusy (isBusy) {
    if (isBusy) {
        dialogLoading.modal('show');
    } else {
        dialogLoading.modal('hide');
    }
}

function showTextDisappear(icon, text, className) {
    var html = (icon ? '<i class="fa fa-' + icon + '"></i>' : '') + text;
    $("#dlg-alert-disappear").attr("class", "");
    $("#dlg-alert-disappear").addClass("alert " + className);
    $("#dlg-alert-disappear p").html(html);
    $("#dlg-alert-disappear").show();
}
