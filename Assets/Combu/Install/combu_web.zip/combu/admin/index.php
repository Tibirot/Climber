<?php

include_once './common.php';

use Combu\Utils;
use Combu\DataClass;
use Combu\AppId;
use Combu\AdminAccount;
use Combu\Account;
use Combu\SessionToken;
use Combu\LeaderBoard;
use Combu\LeaderBoard_User;
use Combu\Achievement;
use Combu\News;
use Combu\Newsletter;

if (isset($_REQUEST["logout"]) && $_REQUEST["logout"] === "1") {
    AdminAccount::Logout();
    Utils::RedirectTo();
}

$error = "";

if ($AdminLogged->IsLogged()) {
    
    $upgradeResult = checkUpgradeAvailable();
    $upgradeAvailable = $upgradeResult["upgrade_required"];
    $usersOnlineTicks = time() - ONLINE_SECONDS;
    
    // Get some stats to display
    $apps = DataClass::CountRecords(DataClass::GetTableName(AppId::class));
    $admins = DataClass::CountRecords(DataClass::GetTableName(AdminAccount::class));
    $users = DataClass::CountRecords(DataClass::GetTableName(Account::class));
    $users_online = DataClass::CountRecords(DataClass::GetTableName(SessionToken::class), sprintf("Updated >= '%s' GROUP BY IdAccount", date("Y-m-d H:i:s", $usersOnlineTicks)));
    $leaderboards = DataClass::CountRecords(DataClass::GetTableName(LeaderBoard::class));
    $scores = DataClass::CountRecords(DataClass::GetTableName(LeaderBoard_User::class));
    $achievements = DataClass::CountRecords(DataClass::GetTableName(Achievement::class));
    $news = DataClass::CountRecords(DataClass::GetTableName(News::class));
    $newsletters = DataClass::CountRecords(DataClass::GetTableName(Newsletter::class));
    
} else {
    
    // Create a default account if the Admin Account table is empty
    if (AdminAccount::CountRecords(DataClass::GetTableName(AdminAccount::class)) == 0) {
        $AdminLogged = new AdminAccount();
        $AdminLogged->Username = "admin";
        $AdminLogged->Password = md5("admin");
        if ($AdminLogged->Save()) {
            AdminAccount::SetSession($AdminLogged);
            Utils::RedirectTo();
        } else {
            $error = "Error creating the default admin account (" . htmlentities ($Database->GetError(), ENT_QUOTES) . ")";
        }
    }
    
    // Check if the session save path exists and is readable/writable
    $path = session_save_path();
    if (is_dir($path)) {
        if (!is_readable($path)) {
            $error = ($error ? "<br/>" : "") . "PHP Session save directory is not readable (" . htmlentities($path) . ")";
        }
        if (!is_writable($path)) {
            $error = ($error ? "<br/>" : "") . "PHP Session save directory is not writable (" . htmlentities($path) . ")";
        }
    } else {
        $error = ($error ? "<br/>" : "") . "PHP Session save directory does not exist (" . htmlentities($path) . ")";
    }

    // Login action requested
    if (!$error && isset($_REQUEST["action"]) && $_REQUEST["action"] == "login") {
        $username = (!isset($_REQUEST["Username"]) ? NULL : trim(stripslashes($_REQUEST["Username"])));
        $password = (!isset($_REQUEST["Password"]) ? NULL : trim(stripslashes($_REQUEST["Password"])));
        if ($username && $password) {
            $account = NULL;
            if (AdminAccount::CheckLogin($username, $password, $account)) {
                AdminAccount::SetSession($account);
                Utils::RedirectTo();
            } else {
                $error = "The credentials are invalid";
            }
        }
    }
}

?>
<?php include './header.php'; ?>

<?php if (!$AdminLogged->IsLogged()) { ?>

    <fieldset id="login">
        <legend>Enter your credentials</legend>
        <?php if ($error) { ?><div class="alert alert-danger text-center" role="alert"><p><i class="fa fa-exclamation-triangle"></i><?= $error ?></p></div><?php } ?>
        <form method="post">
            <input type="hidden" name="action" value="login" />
            <div class="form-group">
                <label for="Username">Username</label>
                <input type="text" class="form-control" name="Username" id="Username" required placeholder="Enter your username" />
            </div>
            <div class="form-group">
                <label for="Password">Password</label>
                <input type="password" class="form-control" name="Password" id="Password" required placeholder="Enter your password" />
            </div>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-primary"><i class="fa fa-sign-in-alt"></i> Login</button>
            </div>
        </form>
    </fieldset>
<script>
    $(function() {
        $("#login input[name='Username']").focus();
    });
</script>
    
<?php } else { ?>

    <?php if ($upgradeAvailable) { ?>
    <fieldset id="stats">
        <legend>Upgrade available</legend>
        Version <strong><?= $upgradeResult["version"] ?></strong> is available, <a href="update.php?action=upgrade">click here</a> to update now.
    </fieldset>
    <?php } ?>
    
    <fieldset id="stats">
        <legend>Statistics</legend>
        <table class="table-records" width="100%">
            <tbody>
                <tr>
                    <td>Admins</td>
                    <td align="right"><?= $admins ?></td>
                </tr>
                <tr>
                    <td>Apps</td>
                    <td align="right"><?= $apps ?></td>
                </tr>
                <tr>
                    <td>Users</td>
                    <td align="right"><?= $users ?> (<?= $users_online ?> online)</td>
                </tr>
                <tr>
                    <td>Leaderboards</td>
                    <td align="right"><?= $leaderboards ?></td>
                </tr>
                <tr>
                    <td>Scores</td>
                    <td align="right"><?= $scores ?></td>
                </tr>
                <tr>
                    <td>Achievements</td>
                    <td align="right"><?= $achievements ?></td>
                </tr>
                <tr>
                    <td>News</td>
                    <td align="right"><?= $news ?></td>
                </tr>
                <tr>
                    <td>Newsletters</td>
                    <td align="right"><?= $newsletters ?></td>
                </tr>
            </tbody>
        </table>
    </fieldset>
    
<?php } ?>

<?php include './footer.php'; ?>