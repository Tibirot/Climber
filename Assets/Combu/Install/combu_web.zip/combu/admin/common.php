<?php

include_once '../lib/api.php';

if (!$Database->GetConnection()) {
    die("Could not connect to database: " . $Database->GetError());
}

// Include admin-only classes
use Combu\AdminAccount;
use Combu\ServerSettings;
use Combu\Utils;

define("ADMIN_ROOT", ROOT . "/admin/");
define("ADMIN_ROOT_URL", URL_ROOT . "admin/");

function printAlertError($error) {
    if (!empty($error)) {
        $error = '<div class="alert alert-danger" role="alert">' .
                '<p><i class="fa fa-exclamation-triangle"></i>' .
                $error .
                '</p></div>';
        return $error;
    }
    return "";
}

function printAlertDisappear($text, $icon = "", $cssClass = "alert-primary") {
    if (!empty($text)) {
        return '<script type="text/javascript">showTextDisappear("' . $icon . '", "' . $text . '", "' . $cssClass . '");</script>' . "\n";
    }
    return "";
}

function printAlertDisappearSaved($saved) {
    return printAlertDisappear(!$saved ? "" : "Data has been correctly saved.", "info", "alert-success");
}

function printAlertDisappearDeleted($deleted) {
    return printAlertDisappear(!$deleted ? "" : "The selected item has been deleted.", "trash", "alert-warning");
}

function isCombuBeta() {
    return !(stripos(COMBU_VERSION, "beta") === FALSE);
}

function getCombuUpdateUrl($forceRedownload = FALSE) {
    return sprintf(COMBU_UPDATE, urlencode(COMBU_VERSION), isCombuBeta() ? "1" : "0", $forceRedownload ? "1" : "0", defined("GAME_DB_PREFIX") ? urlencode(GAME_DB_PREFIX) : "");
}

function getRequestInput($name, $defaultValue = NULL, $isArray = FALSE) {
    if ($isArray) {
        $input = filter_input(INPUT_POST, $name, FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
    } else {
        $input = filter_input(INPUT_POST, $name);
    }
    if (is_null($input)) {
        if ($isArray) {
            $input = filter_input(INPUT_GET, $name, FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
        } else {
            $input = filter_input(INPUT_GET, $name);
        }
    }
    if (is_null($input)) {
        $input = $defaultValue;
    }
    return $input;
}

function checkUpgradeAvailable() {
    try {
        $upgradeResult = json_decode(Utils::DownloadUrl(getCombuUpdateUrl()), JSON_FORCE_OBJECT);
    } catch (Exception $ex) {
        $upgradeResult = NULL;
    }
    if (empty($upgradeResult)) {
        $upgradeResult = array();
    } else if (!is_array($upgradeResult)) {
        $upgradeResult = array($upgradeResult);
    }
    $upgradeResult["beta"] = isCombuBeta();
    $upgradeRequired = FALSE;
    if (isset($upgradeResult["version"])) {
        // Split remote and local version by "." and convert to lower-case
        $versionRemote = explode(".", strtolower($upgradeResult["version"]));
        $versionLocal = explode(".", strtolower(COMBU_VERSION));
        // Make sure that the array of remote and local versions have the same length
        while (count($versionRemote) < count($versionLocal)) {
            $versionRemote[] = "";
        }
        while (count($versionLocal) < count($versionRemote)) {
            $versionLocal[] = "";
        }
        // Compare the remote mayor/minor/revision/build with the local version
        for ($i = 0; $i < count($versionRemote); $i++) {
            // Remove "beta" string from the current mayor/minor/revision/build number
            $versionRemoteNumber = str_replace("beta", "", $versionRemote[$i]);
            $versionLocalNumber = str_replace("beta", "", $versionLocal[$i]);
            // Add '0' to the left of the current mayor/minor/revision/build to transform it like '000'
            $versionRemoteNumber = str_pad($versionRemoteNumber, 3, "0", STR_PAD_LEFT);
            $versionLocalNumber = str_pad($versionLocalNumber, 3, "0", STR_PAD_LEFT);
            // Compare the current mayor/minor/revision/build
            if (strcasecmp($versionRemoteNumber, $versionLocalNumber) > 0) {
                $upgradeRequired = TRUE;
                break;
            }
        }
    }
    $upgradeResult["upgrade_required"] = $upgradeRequired;
    return $upgradeResult;
}

global $AdminLogged;
$AdminLogged = AdminAccount::GetSession();
