<?php

include_once "lib/api.php";

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\Achievement;
use Combu\Achievement_User;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

    // Load all Achievements
        case "load":
            wsLoad();
            break;

    // Insert progress into Achievement
    case "progress":
        wsProgress();
        break;
    
    // Reset all achivements
    case "reset":
        wsReset();
        break;

    }
}
$Database->CloseConnection();
exit();

function wsLoad() {
    global $LoggedAccount, $AppId;
    $records = array();
    if ($LoggedAccount->IsLogged()) {
        $records = Achievement::LoadUserAchievements($LoggedAccount->Id, $AppId->Id);
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($records, count($records)), FALSE, TRUE );
}

function wsProgress() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get data from REQUEST
        $id = (isset($WS_REQUEST["IdAchievement"]) ? intval($WS_REQUEST["IdAchievement"]) : 0);
        $progress = (isset($WS_REQUEST["Progress"]) ? intval($WS_REQUEST["Progress"]) : 0);
        if ($progress < 0)
            $progress = 0;
        else if ($progress > 100)
            $progress = 100;
        // Does the achievement exist?
        $achievement = new Achievement($id);
        if ($achievement->Id > 0) {
            $newProgress = 0;
            $cannotRepeat = FALSE;
            $success = $achievement->PostProgress($LoggedAccount, $progress, $newProgress, $cannotRepeat);
            if ($success) {
                // If it was successfully registered, return info to notify the new progress and
                // if the user can continue to progress with this achievement or not
                $message = json_encode(array("Progress" => $newProgress, "Repeat" => $cannotRepeat));
            } else {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        } else {
            $message = ErrorMessage::Get(ERROR_ACHIEVEMENT_INVALID);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsReset() {
    global $LoggedAccount;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $achievements =  Achievement_User::LoadAccount($LoggedAccount->Id);
        foreach ($achievements as $achievement) {
            $achievement->Delete();
        }
        $success = TRUE;
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}