<html>
    <head>
        <title>Combu setup</title>
        <link href="style.css" rel="stylesheet"/>
    </head>
    <body>
        <h1>Combu setup</h1>
        Click on a link below to configure Combu server:
        <ol>
            <li><a href="configuration.php">Create the configuration file</a></li>
            <li><a href="database.php">Create the database script</a></li>
        </ol>
        It is not recommended to keep this folder (<strong>_setup</strong>) on your production server, so please remember to not publish it.
        <br/>You can keep it on your local development machine, so it will be easier to re-create the database script and the configuration file if you will need to make changes.
    </body>
</html>