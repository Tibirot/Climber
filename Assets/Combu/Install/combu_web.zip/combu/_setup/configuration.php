<?php

function getParamInfo($paramName, &$sectionName, &$param) {
    global $sections;
    $sectionName = "";
    $param = NULL;
    foreach ($sections as $section) {
        foreach ($section->param as $p) {
            if ($p["name"] == $paramName) {
                $sectionName = $section["name"];
                $param = $p;
                return;
            }
        }
    }
}

$configFile = realpath(__DIR__ . "/../lib/config.php");
$configFileExists = file_exists($configFile);
$configFileWritable = $configFileExists && is_writable($configFile);

$result = "";
$posted = FALSE;
$saved = FALSE;

$sections = array();
$allParams = array();

// Read the configuration XML
$xml_string = @file_get_contents("configuration.xml");
if (!$xml_string) {
    $result = "The file configuration.xml does not exist, is not readable or is empty";
} else {
    $xml = simplexml_load_string($xml_string) or die("Error: Cannot open configuration.xml (click Back in your web browser)");
    foreach ($xml->section as $section) {
        $params = array();
        foreach ($section->param as $param) {
            $allParams[] = $param["name"];
            $params[] = $param;
        }
        $sections[] = $section;
    }
}

if (count($allParams) == 0) {
    $result = "<strong>configuration.xml</strong> does not contain any parameter.";
} else {
    switch (filter_input(INPUT_POST, "action")) {
        case "save":
            $posted = TRUE;
            $error = "";
            $postParams = filter_input_array(INPUT_POST);
            $currentSection = "";
            $sectionName = "";
            $param = "";
            foreach ($postParams as $k => $v) {
                if (in_array($k, $allParams)) {
                    getParamInfo($k, $sectionName, $param);
                    if (empty($v)) {
                        if (isset($param["required"]) && strcasecmp($param["required"], "TRUE") === 0) {
                            $error .= "<li>" . $k . " is required and cannot be empty</li>";
                            continue;
                        } else if (!isset($param["required-empty"]) || (isset($param["required-empty"]) && strcasecmp($param["required-empty"], "TRUE") !== 0)) {
                            continue;
                        }
                    }
                    if (isset($param["type"])) {
                        if (strcasecmp($param["type"], "int") === 0) {
                            if (!is_numeric($v)) {
                                $error .= "<li>" . $k . " must be a valid number</li>";
                                continue;
                            }
                        } else if (strcasecmp($param["type"], "bool") === 0) {
                            if (strcasecmp($v, "TRUE") !== 0 && strcasecmp($v, "FALSE") !== 0) {
                                $error .= "<li>" . $k . " must be a valid boolean</li>";
                                continue;
                            }
                        }
                    }
                    if ($currentSection != $sectionName) {
                        $currentSection = $sectionName;
                        $result .= ($result ? "\n\n" : "") . "/*\n * " . $sectionName . "\n */\n";
                    }
                    if ($param["description"]) {
                        $result .= "// " . $param["description"] . "\n";
                    }
                    $paramValue = $v;
                    if (is_null($v)) {
                        $paramValue = "NULL";
                    } elseif (!is_numeric($v)) {
                        if (strcasecmp($v, "TRUE") === 0 || strcasecmp($v, "FALSE") === 0) {
                            $paramValue = strtoupper($v);
                        } else {
                            $paramValue = str_replace("\\", "\\\\", $v);
                            $paramValue = str_replace("\$", "\\\$", $paramValue);
                            $paramValue = str_replace("\"", "\\\"", $paramValue);
                            $paramValue = '"' . $paramValue . '"';
                        }
                    }
                    $result .= "define (\"" . $k . "\", " . $paramValue . ");\n";
                }
            }
            if ($error) {
                // An error occurred, display the message
                $result = "Error: <ul>" . $error . "</ul>";
            } else {
                // No errors, display the configuration content
                $result = htmlentities("<?php\n\n" . $result . "\n");
                $saved = TRUE;
            }
            break;
        
        case "save_file":
            $success = FALSE;
            $message = "";
            $content = filter_input(INPUT_POST, "content");
            $dir = dirname($configFile);
            if (!$content) {
                $message = "The configuration content is empty";
            } else if (!$configFileExists && !file_exists($dir)) {
                $message = "The configuration file or directory doesn't exist";
            } else if (!$configFileWritable && !is_writable($dir)) {
                $message = "The configuration file or directory is not writable";
            } else {
                try {
                    if (file_put_contents($configFile, $content)) {
                        $success = TRUE;
                    } else {
                        $error = error_get_last();
                        $message = ($error && isset($error["message"]) ? $error["message"] : "An error occurred trying to save the configuration file");
                    }
                } catch (Exception $ex) {
                    $message = $ex->getMessage();
                }
            }
            header("Content-Type:text/json");
            die(json_encode(array("success" => $success, "message" => $message)));
            break;
    }
}

?>
<html>
    <head>
        <title>Combu setup - Create configuration file</title>
        <link rel="stylesheet" href="https://jqueryvalidation.org/files/demo/site-demos.css">
        <link href="style.css" rel="stylesheet"/>
        <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/jquery.validate.min.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.0/additional-methods.min.js"></script>
        <script src="clipboard.min.js"></script>
        <script>
            $(function () {
            <?php if ($posted) { ?>
                
                new Clipboard('.copy');
                $("button.save").click(function() {
                    var content = $("#result").text();
                    $.post("<?= basename(__FILE__) ?>", { action: "save_file", content: content }, function(data) {
                        if (data) {
                            if (data.success) {
                                alert("The configuration file has been updated");
                            } else {
                                alert(data.message);
                            }
                        } else {
                            alert("An error occurred in the request");
                        }
                    });
                });
                
            <?php } else { ?>
                
                // just for the demos, avoids form submit
                $.validator.setDefaults({ success: "valid" });
                $( "#myform" ).validate({
                rules: {
            <?php $rule = 0; ?>
            <?php foreach ($sections as $section) { ?>
                <?php foreach ($section->param as $param) { ?>
                    <?php
                    $required = FALSE;
                    if (isset($param["required"]) && strcasecmp($param["required"], "TRUE") === 0) {
                        $required = TRUE;
                    }
                    if (!$required) {
                        continue;
                    }
                    if ($rule > 0) {
                        echo ",";
                    }
                    $min = NULL;
                    if (isset($param["min"]) && intval($param["min"]) > 0) {
                        $min = intval($param["min"]);
                    }
                    $max = NULL;
                    if (isset($param["max"]) && intval($param["max"]) > 0) {
                        $max = intval($param["max"]);
                    }
                    $values = NULL;
                    if (isset($param["values"]) && $param["values"]) {
                        $values = explode(",", $param["values"]);
                    }
                    ?>
                    <?= $param["name"] ?>: {
                    <?php if (is_null($values)) { ?>
                        required: true
                        <?= (is_null($min) ? "" : ",min: " . $min) ?>
                        <?= (is_null($max) ? "" : ",max: " . $max) ?>
                    <?php } else { ?>
                        required: function(element) {
                            var v = $("#<?= $param["name"] ?>").val();
                        <?php foreach ($values as $v) { ?>
                            if (v == "<?= $v ?>")
                                return false;
                        <?php } ?>
                            return true;
                        }
                    <?php } ?>
                    }
                    <?php $rule++; ?>
                <?php } ?>
            <?php } ?>
                  }
                });
                
            <?php } ?>
            });
        </script>
    </head>
    <body>
        
        <h1><a href="index.php">Combu setup</a> &raquo; Create configuration file</h1>
        <p>
            The configuration file is located in: <strong><?= $configFile ?></strong><br/>
            <span style="color:#<?= ($configFileWritable ? "00BB00" : "CC0000") ?>">The configuration file is <?php if (!$configFileWritable) echo 'not'; ?> writable</span>
        </p>
        
        <?php if ($saved) { ?>
        
            Here is the content to copy in the configuration file (<a href="?">click here</a> to create a new configuration):
            <br/><br/>
            <button class="copy" data-clipboard-target="#result"><img src="clippy.svg" alt="Copy to clipboard"/> Copy to clipboard</button>
            <button class="save" data-clipboard-target="#result"><img src="save.svg" alt="Save to file"/> Save to file</button>
            <pre id="result"><?= $result ?></pre>
        
        <?php } else { ?>
            
            <?php if ($result) { ?><div class="result_error"><?= $result ?></div><?php } ?>
        
            <?php if (count($allParams) > 0) { ?>
            <form id="myform" method="post">
                <input type="hidden" name="action" value="save"/>
                <?php foreach ($sections as $section) { ?>
                <fieldset>
                    <legend><?= htmlentities($section["name"]) ?></legend>
                    <?php foreach ($section->param as $param) { ?>
                    <?php
                    $paramName = $param["name"];
                    $paramType = "string";
                    if (isset($param["type"])) {
                        $paramType = $param["type"];
                    }
                    $paramRequired = FALSE;
                    if (isset($param["required"]) && strcasecmp($param["required"], "TRUE") === 0) {
                        $paramRequired = TRUE;
                    }
                    $paramValue = "";
                    if (isset($param["default"])) {
                        $paramValue = $param["default"];
                    }
                    if ($posted) {
                        $paramValue = filter_input(INPUT_POST, $paramName);
                    }
                    $paramValues = NULL;
                    if (isset($param["values"]) && $param["values"]) {
                        $paramValues = explode(",", $param["values"]);
                    }
                    ?>
                    <label for="<?= $paramName ?>"><?= htmlentities($param["description"]) ?></label>
                    <br/>
                    <?php if (strcasecmp($paramType, "bool") === 0) { ?>
                    <select style="width: 100%;" id="<?= $paramName ?>" name="<?= $paramName ?>">
                        <?php if (!$paramRequired) { ?>
                        <option value="">[Not set]</option>
                        <?php } ?>
                        <option <?= (strcasecmp($paramValue, "TRUE") === 0 ? "selected" : "") ?>>TRUE</option>
                        <option <?= (strcasecmp($paramValue, "FALSE") === 0 ? "selected" : "") ?>>FALSE</option>
                    </select>
                    <?php } else if (!is_null($paramValues)) { ?>
                    <select style="width: 100%;" id="<?= $paramName ?>" name="<?= $paramName ?>">
                        <?php if (!$paramRequired) { ?>
                        <option value="">[Not set]</option>
                        <?php } ?>
                        <?php foreach ($paramValues as $v) { ?>
                        <option <?= (strcasecmp($paramValue, $v) === 0 ? "selected" : "") ?>><?= htmlentities($v) ?></option>
                        <?php } ?>
                    </select>
                    <?php } else { ?>
                    <input type="<?php if ($paramName == "GAME_DB_PASS") { ?>password<?php } else { ?>text<?php } ?>" class="<?= (strcasecmp($paramType, "int") ? "only_numbers" : "") ?>" style="width: 100%;" id="<?= $paramName ?>" name="<?= $paramName ?>" value="<?= htmlentities($paramValue) ?>" />
                    <?php } ?>
                    <br/><br/>
                    <?php } ?>
                </fieldset>
                <?php } ?>
                <br/><input type="submit" value="Go" />
            </form>
            <?php } ?>
            
        <?php } ?>
        
    </body>
</html>