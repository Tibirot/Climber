<?php

$Database = NULL;
$configFile = realpath(__DIR__ . "/../lib/api.php");
if (file_exists($configFile)) {
    include_once $configFile;
    if (isset($Database) && $Database && !$Database->TestConnection()) {
        $Database = NULL;
    }
} else {
    $configFile = NULL;
}

function getAddonFile($addonName) {
    $addon = Combu\AddonModule::GetAddon($addonName);
    if ($addon) {
        return $addon->GetFolder() . "setup_database.xml";
    }
    return FALSE;
}

$result = "";
$saved = FALSE;

switch (filter_input(INPUT_POST, "action")) {
    
    case "save":
        $addonName = filter_input(INPUT_POST, "addon");
        $prefix = filter_input(INPUT_POST, "prefix");
        
        $xml_file = "database.xml";
        if ($addonName && $configFile) {
            $xml_file = getAddonFile($addonName);
        }

        if ($xml_file && file_exists($xml_file) && is_readable($xml_file)) {
            $xml_string = str_replace("pma:", "", file_get_contents($xml_file));
            if (!$xml_string) {
                $result = "The file " . $xml_file . " is not readable or is empty";
            } else {
                $xml = simplexml_load_string($xml_string) or die("Error: Cannot open " . $xml_file . " (click <em>Back</em> in your web browser)");
                foreach ($xml->structure_schemas->database->table as $table) {
                    $table_sql = "";
                    $lines = explode("\n", $table);
                    foreach ($lines as $line) {
                        $line = trim($line);
                        if (!$line) {
                            continue;
                        }
                        if (stripos($line, "CREATE TABLE") !== FALSE) {
                            $line = "CREATE TABLE IF NOT EXISTS `" . $prefix . $table["name"] . "` (";
                        } else {
                            $line = " " . $matches = preg_replace('/((\s)+AUTO_INCREMENT[^=]*=[^\d]*(\d+)(\s)+)/', " ", $line);
                        }
                        $line = str_ireplace("CHARSET", "CHARACTER SET", $line);
                        $table_sql .= $line;
                    }
                    $result .= ($result ? "\n\n" : "") . $table_sql;
                }
                $saved = TRUE;
            }
        } else {
            $result = "The file " . $xml_file . " does not exist or has not readable permission";
        }
        break;
        
    case "save_db":
        $success = FALSE;
        $message = "";
        $content = filter_input(INPUT_POST, "content");
        if (!$content) {
            $message = "The SQL query is empty";
        } else if (!$Database) {
            $message = "The database connection is not opened (the connection constants could not be correctly set in ../lib/config.php)";
        } else {
            if ($Database->TransactionStart()) {
                $queries = explode(";", $content);
                $errorQuery = FALSE;
                $i = 0;
                foreach ($queries as $query) {
                    if (!$query) {
                        continue;
                    }
                    ++$i;
                    if (!$Database->Query($query)) {
                        $errorQuery = TRUE;
                        break;
                    }
                }
                if (!$errorQuery && $Database->TransactionCommit()) {
                    $success = TRUE;
                } else {
                    $error = $Database->GetError();
                    $message = "An error occurred trying to execute the SQL query #" . $i . ($error ? ":\n" . $error : "");
                    $Database->TransactionRollback();
                }
            } else {
                $message = "An error occurred trying to start the transaction";
            }
        }
        header("Content-Type:text/json");
        die(json_encode(array("success" => $success, "message" => $message)));
        break;
}

?>
<html>
    <head>
        <title>Combu setup - Create database</title>
        <link href="style.css" rel="stylesheet"/>
        <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
        <script src="clipboard.min.js"></script>
        <script>
            $(function () {
            <?php if ($saved) { ?>
                
                new Clipboard('.copy');
                <?php if ($Database) { ?>
                $("button.save").click(function() {
                    var content = $("#result").text();
                    $.post("<?= basename(__FILE__) ?>", { action: "save_db", content: content }, function(data) {
                        if (data) {
                            if (data.success) {
                                alert("The tables have been created in your database");
                            } else {
                                alert(data.message);
                            }
                        } else {
                            alert("An error occurred in the request");
                        }
                    });
                });
                <?php } ?>
                
            <?php } ?>
            });
        </script>
    </head>
    <body>
        
        <h1><a href="index.php">Combu setup</a> &raquo; Create database</h1>
        
        <?php if ($saved) { ?>
        
            Here is your SQL script<?php if ($addonName) echo " for the add-on <strong>" . htmlentities ($addonName) . "</strong>"; ?>, copy and paste in a new query on your <a href="http://www.phpmyadmin.net" target="_blank">phpMyAdmin</a> or any other MySql manager provided by your hosting (<a href="?">click here</a> to create a new script):
            <br/><br/>
            <button class="copy" data-clipboard-target="#result"><img src="clippy.svg" alt="Copy to clipboard"/> Copy to clipboard</button>
            <?php if ($Database) { ?><button class="save" data-clipboard-target="#result"><img src="save.svg" alt="Execute on database"/> Execute on database</button><?php } ?>
            <pre id="result"><?= $result ?></pre>
        
        <?php } else { ?>
        
            <form method="post">
                <input type="hidden" name="action" value="save"/>
                <label>Destination</label>
                <br/><select name="addon">
                    <option value="">Combu Database</option>
                <?php if (isset($Addons)) { ?>
                <?php foreach ($Addons as $addon) { ?>
                    <?php if (file_exists($addon->GetFolder() . "setup_database.xml")) { ?>
                    <option value="<?= htmlentities($addon->Name) ?>">Add-on: <?= htmlentities($addon->Name) ?></option>
                    <?php } ?>
                <?php } ?>
                <?php } ?>
                </select>
                <br/><br/>
                <label>Table prefix</label>
                <br/><input type="text" name="prefix" />
                <br/><br/>
                <input type="submit" value="Go" />
            </form>
            
            <?= $result ?>
            
        <?php } ?>
        
    </body>
</html>