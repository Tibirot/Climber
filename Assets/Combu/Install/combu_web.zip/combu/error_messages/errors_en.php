<?php

// Generic errors
$errors[ERROR_UNAUTHORIZED_REQUEST] = "Unauthorized request";
$errors[ERROR_UNEXPECTED_GENERIC] = "An unexpected error occurred";
$errors[ERROR_USER_NOT_AUTHENTICATED] = "User is not authenticated";
$errors[ERROR_REQUIRE_CLIENT_UPDATE] = "Client update is required";
$errors[ERROR_INVALID_KEY] = "Invalid key";
$errors[ERROR_INVALID_APP] = "Invalid App";

// achievements.php
$errors[ERROR_ACHIEVEMENT_INVALID] = "Achievement is invalid";

// activation.php
$errors[ERROR_ACTIVATION_ACTIVATED] = "Your account has been activated, you can now login";
$errors[ERROR_ACTIVATION_FAILED] = "Activation failed or expired";
$errors[ERROR_ACTIVATION_EXPIRED] = "Activation expired";

// contacts.php
$errors[ERROR_CONTACTS_SELF] = "You cannot add or remove yourself as contact";
$errors[ERROR_CONTACTS_ACCEPTED] = "Your request has been accepted";
$errors[ERROR_CONTACTS_PENDING] = "Your request is pending";
$errors[ERROR_CONTACTS_DECLINED] = "Your request has been declined";
$errors[ERROR_CONTACTS_INVALID_STATE] = "Invalid contact type";

// groups.php
$errors[ERROR_GROUP_INVALID] = "Invalid group";
$errors[ERROR_GROUP_NAME] = "Invalid group name";
$errors[ERROR_GROUP_NAME_EXISTS] = "This name is already used";
$errors[ERROR_GROUP_NO_USERS_ADD] = "No users to add";
$errors[ERROR_GROUP_NO_USERS_DELETE] = "No users to delete";

// inventory.php
$errors[ERROR_INVENTORY_INVALID] = "Invalid item";
$errors[ERROR_INVENTORY_NAME] = "Item must have a name";

// leaderboards.php
$errors[ERROR_LEADERBOARD_INVALID] = "Leaderboard is invalid";

// mail.php
$errors[ERROR_GAMEMAIL_NO_RECIPIENT] = "No recipients";
$errors[ERROR_GAMEMAIL_SELF] = "You cannot send mail to yourself";
$errors[ERROR_GAMEMAIL_MESSAGE] = "Message cannot be empty";
$errors[ERROR_GAMEMAIL_CANNOT_DELETE] = "You are not allowed to delete this message";

// match.php
$errors[ERROR_TOURNAMENT_INVALID] = "Invalid Tournament";
$errors[ERROR_GAMEMATCH_INVALID] = "Invalid Match";
$errors[ERROR_GAMEMATCH_SCORE_EXISTS] = "Score already registered";
$errors[ERROR_GAMEMATCH_NO_USERS] = "No users available for match at this moment";

// user_files.php
$errors[ERROR_USERFILE_INVALID] = "This file is invalid";
$errors[ERROR_USERFILE_NOT_UPLOADED] = "File not uploaded";
$errors[ERROR_USERFILE_MOVE_UPLOADED] = "Error moving the file uploaded";
$errors[ERROR_USERFILE_VOTED] = "You has already voted this file";

// users.php
$errors[ERROR_LOGIN_DISABLED] = "Your account is disabled";
$errors[ERROR_LOGIN_NOT_ACTIVATED] = "You must activate your account by following the link in the email";
$errors[ERROR_LOGIN_INVALID_CREDENTIALS] = "Credentials are invalid";
$errors[ERROR_LOGIN_PLATFORM] = "No Platform Key and/or Id provided";
$errors[ERROR_USER_USERNAME_RESERVED] = "This username is reserved";
$errors[ERROR_USER_USERNAME_EXISTS] = "This username has already been taken";
$errors[ERROR_USER_EMAIL_INVALID] = "A valid email is required";
$errors[ERROR_USER_EMAIL_EXISTS] = "Email already registered";
$errors[ERROR_USER_USERNAME_PASSWORD] = "Username/Password invalid";
$errors[ERROR_USER_INVALID] = "This user does not exist";
$errors[ERROR_USER_USERNAME_EMAIL] = "Username/Email invalid";
$errors[ERROR_RESET_PWD_NO_EMAIL] = "User has no email address";
$errors[ERROR_CHANGE_PWD_CODE] = "Code is not valid";
$errors[ERROR_CHANGE_PWD_PASSWORD] = "Password cannot be empty";
