<?php

// Generic errors
$errors[ERROR_UNAUTHORIZED_REQUEST] = "Richiesta non autorizzata";
$errors[ERROR_UNEXPECTED_GENERIC] = "Si è verificato un errore imprevisto";
$errors[ERROR_USER_NOT_AUTHENTICATED] = "Utente non autenticato";
$errors[ERROR_REQUIRE_CLIENT_UPDATE] = "Il client deve essere aggiornato";
$errors[ERROR_INVALID_KEY] = "Chiave non valida";
$errors[ERROR_INVALID_APP] = "App non valida";

// achievements.php
$errors[ERROR_ACHIEVEMENT_INVALID] = "Achievement non valido";

// activation.php
$errors[ERROR_ACTIVATION_ACTIVATED] = "Il tuo account è stato attivato, adesso puoi autenticarti";
$errors[ERROR_ACTIVATION_FAILED] = "Attivazione fallita oppure scaduta";
$errors[ERROR_ACTIVATION_EXPIRED] = "Attivazione scaduta";

// contacts.php
$errors[ERROR_CONTACTS_SELF] = "Non puoi aggiungere o rimuovere te stesso come contatto";
$errors[ERROR_CONTACTS_ACCEPTED] = "La tua richiesta è stata accettata";
$errors[ERROR_CONTACTS_PENDING] = "La tua richiesta è in attesa";
$errors[ERROR_CONTACTS_DECLINED] = "La tua richiesta è stata rifiutata";
$errors[ERROR_CONTACTS_INVALID_STATE] = "Tipo di contatto non valido";

// groups.php
$errors[ERROR_GROUP_INVALID] = "Gruppo non valido";
$errors[ERROR_GROUP_NAME] = "Nome del gruppo non valido";
$errors[ERROR_GROUP_NAME_EXISTS] = "Questo nome è già in uso";
$errors[ERROR_GROUP_NO_USERS_ADD] = "Nessun utente da aggiungere";
$errors[ERROR_GROUP_NO_USERS_DELETE] = "Nessun utente da rimuovere";

// inventory.php
$errors[ERROR_INVENTORY_INVALID] = "Oggetto non valido";
$errors[ERROR_INVENTORY_NAME] = "L'oggetto deve avere un nome";

// leaderboards.php
$errors[ERROR_LEADERBOARD_INVALID] = "Leaderboard non valida";

// mail.php
$errors[ERROR_GAMEMAIL_NO_RECIPIENT] = "Nessun destinatario specificato";
$errors[ERROR_GAMEMAIL_SELF] = "Non puoi mandare messaggi a te stesso";
$errors[ERROR_GAMEMAIL_MESSAGE] = "Il messaggio non può essere vuoto";
$errors[ERROR_GAMEMAIL_CANNOT_DELETE] = "Non puoi eliminare questo messaggio";

// match.php
$errors[ERROR_TOURNAMENT_INVALID] = "Torneo non valido";
$errors[ERROR_GAMEMATCH_INVALID] = "Match non valido";
$errors[ERROR_GAMEMATCH_SCORE_EXISTS] = "Punteggio già registrato";
$errors[ERROR_GAMEMATCH_NO_USERS] = "Nessun utente disponibile per un match in questo momento";

// user_files.php
$errors[ERROR_USERFILE_INVALID] = "Questo file non è valido";
$errors[ERROR_USERFILE_NOT_UPLOADED] = "File non inviato";
$errors[ERROR_USERFILE_MOVE_UPLOADED] = "Errore nello spostamento del file inviato";
$errors[ERROR_USERFILE_VOTED] = "Hai già votato per questo file";

// users.php
$errors[ERROR_LOGIN_DISABLED] = "Il tuo account è disabilitato";
$errors[ERROR_LOGIN_NOT_ACTIVATED] = "Devi attivare il tuo account cliccando il link che hai ricevuto nell'email";
$errors[ERROR_LOGIN_INVALID_CREDENTIALS] = "Le credenziali di accesso non sono valide";
$errors[ERROR_LOGIN_PLATFORM] = "Piattaforma non valida per la Chiave/Id specificati";
$errors[ERROR_USER_USERNAME_RESERVED] = "Questo nome utente è riservato";
$errors[ERROR_USER_USERNAME_EXISTS] = "Questo nome utente è già in uso";
$errors[ERROR_USER_EMAIL_INVALID] = "È necessario un indirizzo email valido";
$errors[ERROR_USER_EMAIL_EXISTS] = "Email già registrata";
$errors[ERROR_USER_USERNAME_PASSWORD] = "Nome utente/Password non validi";
$errors[ERROR_USER_INVALID] = "Questo utente non esiste";
$errors[ERROR_USER_USERNAME_EMAIL] = "Nome utente/Email non validi";
$errors[ERROR_RESET_PWD_NO_EMAIL] = "Questo utente non ha un indirizzo email valido";
$errors[ERROR_CHANGE_PWD_CODE] = "Il Codice non è valido";
$errors[ERROR_CHANGE_PWD_PASSWORD] = "La Password non può essere vuota";
