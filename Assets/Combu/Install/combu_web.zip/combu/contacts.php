<?php

include_once 'lib/api.php';

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\Account;
use Combu\Friend;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

        // List user's friends
        case "list":
            wsList();
            break;

        // Add a new friend to a user list
        case "save":
            wsSave();
            break;

        // Delete a friend from a user list
        case "delete":
            wsDelete();
            break;
        
        // Check the friendship state of a user related to logged
        case "check":
            wsCheck();
            break;

    }
}
$Database->CloseConnection();
exit();


function wsList() {
    global $LoggedAccount, $WS_REQUEST;
    $list = array();
    if ($LoggedAccount->IsLogged()) {
        // Retrieve the owner of friendship from REQUEST
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        $state = (!isset($WS_REQUEST["State"]) ? -1 : intval($WS_REQUEST["State"]));
        if ($state < FRIEND_STATE_REQUEST_PENDING || $state > FRIEND_STATE_IGNORE) {
            $state = FRIEND_STATE_REQUEST_PENDING;
        }
        // If it's not me, then verify that the user exists
        if ($id != $LoggedAccount->Id && $id > 0) {
            $user = new Account($id);
            // Reset the request if the user doesn't exist
            $id = ($user->Id > 0 ? $user->Id : 0);
        } else {
            // If no ID was specified, then load my friends
            $id = $LoggedAccount->Id;
        }
        // Load the friends results
        $friends = Friend::Load($id, $state);
        foreach ($friends as $friend) {
            $otherId = $friend->IdFriend;
            if ($state == FRIEND_STATE_REQUEST_PENDING) {
                $otherId = $friend->IdAccount;
            }
            $user = new Account($otherId);
            if ($user->Id > 0) {
                $list[] = $user->ToArray();
            }
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($list, count($list)), FALSE, TRUE );
}

function wsSave() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get the user Id from REQUEST
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        // If the user is not valid, then get Username from REQUEST
        if ($id < 1) {
            $username = (isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "");
            $user = new Account($username);
            if ($user->Id > 0) {
                $id = $user->Id;
            }
        }
        if ($id == $LoggedAccount->Id) {
            $message = ErrorMessage::Get(ERROR_CONTACTS_SELF);
        } else if ($id < 1) {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        } else if (!isset($WS_REQUEST["State"]) || !in_array ($WS_REQUEST["State"], array(FRIEND_STATE_REQUEST, FRIEND_STATE_ACCEPTED, FRIEND_STATE_IGNORE))) {
            $message = ErrorMessage::Get(ERROR_CONTACTS_INVALID_STATE);
        } else {
            $rec = NULL;
            if (FRIENDS_REQUIRE_ACCEPT) {
                // Game is setup to require acceptance of friendship requests
                if ($WS_REQUEST["State"] != FRIEND_STATE_REQUEST) {
                    // We are setting state on own list
                    $state = intval($WS_REQUEST["State"]);
                    // Apply the new state to the contact
                    $found = FALSE;
                    $recs = Friend::Load($LoggedAccount->Id);
                    foreach ($recs as $r) {
                        if ($r->IdFriend == $id) {
                            $found = TRUE;
                            if ($r->State == $state) {
                                // State did not change
                                $success = TRUE;
                            } else {
                                // Change the state
                                $r->State = $state;
                                if ($r->Save()) {
                                    $success = TRUE;
                                    if ($state == FRIEND_STATE_ACCEPTED) {
                                        // Accepted: add ourself to the other's list
                                        $other = new Friend();
                                        $other->IdAccount = $id;
                                        $other->IdFriend = $LoggedAccount->Id;
                                        $other->State = FRIEND_STATE_ACCEPTED;
                                        $other->Save();
                                    } else {
                                        // Ignored: remove ourself from the other's list
                                        $other = Friend::Load($id);
                                        foreach ($other as $i) {
                                            if ($i->IdFriend == $LoggedAccount->Id) {
                                                $i->Delete();
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                        }
                    }
                    // If added to ignore list then verify that a record exists
                    if ($state == FRIEND_STATE_IGNORE && !$found) {
                        $other = new Friend();
                        $other->IdAccount = $LoggedAccount->Id;
                        $other->IdFriend = $id;
                        $other->State = FRIEND_STATE_IGNORE;
                        $success = $other->Save();
                        if ($success) {
                            // Delete the record from the recipient if it exists
                            $recs = Friend::Load($id);
                            foreach ($recs as $r) {
                                if ($r->IdFriend == $LoggedAccount->Id) {
                                    $r->Delete();
                                    break;
                                }
                            }
                        }
                    } else if ($state == FRIEND_STATE_ACCEPTED && !$found) {
                        // Verify that logged user is not in the accepted/ignored list of the recipient
                        $recs = Friend::Load($id);
                        $state = FRIEND_STATE_REQUEST;
                        foreach ($recs as $r) {
                            if ($r->IdFriend == $LoggedAccount->Id) {
                                switch ($r->State) {
                                    case FRIEND_STATE_ACCEPTED:
                                        $state = FRIEND_STATE_ACCEPTED;
                                        break;
                                    case FRIEND_STATE_IGNORE:
                                        $message = ErrorMessage::Get(ERROR_CONTACTS_DECLINED);
                                        $found = TRUE;
                                        break;
                                }
                                break;
                            }
                        }
                        if (!$found) {
                            $rec = new Friend();
                            $rec->IdAccount = $id;
                            $rec->IdFriend = $LoggedAccount->Id;
                            $rec->State = $state;
                        }
                    }
                } else {
                    // Verify that it's not already sent or accepted/ignored
                    $recs = Friend::Load($id);
                    $found = FALSE;
                    foreach ($recs as $r) {
                        if ($r->IdFriend == $LoggedAccount->Id) {
                            $found = TRUE;
                            switch ($r->State) {
                                case FRIEND_STATE_ACCEPTED:
                                    $message = ErrorMessage::Get(ERROR_CONTACTS_ACCEPTED);
                                    break;
                                case FRIEND_STATE_REQUEST:
                                    $message = ErrorMessage::Get(ERROR_CONTACTS_PENDING);
                                    break;
                                default:
                                    $message = ErrorMessage::Get(ERROR_CONTACTS_DECLINED);
                                    break;
                            }
                            break;
                        }
                    }
                    if (!$found) {
                        // Not found, create a new request to the other's list
                        $rec = new Friend();
                        $rec->IdAccount = $id;
                        $rec->IdFriend = $LoggedAccount->Id;
                        $rec->State = FRIEND_STATE_REQUEST;
                    }
                }
            } else {
                // Friendship acceptance is not required,
                // so just add the other to my list
                $rec = new Friend();
                $rec->IdAccount = $LoggedAccount->Id;
                $rec->IdFriend = $id;
                $rec->State = ($WS_REQUEST["State"] == FRIEND_STATE_IGNORE ? FRIEND_STATE_IGNORE : FRIEND_STATE_ACCEPTED);
            }

            // Save the record
            if ($rec) {
                $success = $rec->Save();
            }
            if (!$success && empty($message)) {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsDelete() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        if ($id > 0) {
            $user = new Account($id);
        } else {
            $username = (isset($WS_REQUEST["Username"]) ? trim($WS_REQUEST["Username"]) : "");
            $user = new Account($username);
        }
        if ($user->Id > 0) {
            $id = $user->Id;
        } else {
            $id = 0;
        }
        if ($id < 1) {
            $message = ErrorMessage::Get(ERROR_USER_INVALID);
        } else if ($id == $LoggedAccount->Id) {
            $message = ErrorMessage::Get(ERROR_CONTACTS_SELF);
        } else {
            // Delete the other from my list
            $success = Friend::DeleteBoth($id, $LoggedAccount->Id);
            if (!$success) {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsCheck() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($WS_REQUEST["Id"]) ? "" : trim($WS_REQUEST["Id"]));
        $user = new Account($id);
        if ($user->Id > 0) {
            $myList = TRUE;
            $state = NULL;
            // Search the user in my contacts
            $friends = Friend::Load($LoggedAccount->Id);
            foreach ($friends as $friend) {
                if ($friend->IdFriend == $user->Id) {
                    $state = $friend->State;
                    break;
                }
            }
            // User has not been found in my contacts
            if ($state === NULL) {
                $myList = FALSE;
                // Search me in his/her contacts
                $friends = Friend::Load($user->Id);
                foreach ($friends as $friend) {
                    if ($friend->IdFriend == $LoggedAccount->Id) {
                        $state = $friend->State;
                        break;
                    }
                }
            }
            switch ($state) {
            case FRIEND_STATE_REQUEST_PENDING:
            case FRIEND_STATE_ACCEPTED:
            case FRIEND_STATE_REQUEST:
            case FRIEND_STATE_IGNORE:
                $success = TRUE;
                $message = array( "State" => $state, "User" => $user->ToArray() );
                break;
            default:
                $message = ErrorMessage::Get(ERROR_USER_INVALID) . " (" . $id . ")";
                break;
            }
        } else {
            $message = ErrorMessage::Get(ERROR_USER_INVALID) . " (" . $id . ")";
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}
