<?php

include_once "lib/api.php";

use Combu\Utils;
use Combu\SessionToken;
use Combu\AppId;
use phpseclib\Crypt\RSA;

$action = (empty($WS_REQUEST) ? getRequestParam("action", TRUE) : $WS_REQUEST["action"]);

if (isset($action)) {
    switch ($action) {
        
    // Generate RSA keys
    case "token":
        wsToken();
        break;

    // Store client AES keys
    case "authorize":
        wsAuthorize();
        break;

    // Gets the Combu server version
    case "info":
        wsInfo();
        break;
    
    // Ping from clients
    case "ping":
        wsPing();
        break;
    
    }
}
$Database->CloseConnection();
exit();

function wsToken() {
    global $WS_VERSION;
    // Validate the request
    $unauthorizedText = "";
    $WS_VERSION = getRequestParam("version");
    if (!isValidRequest($unauthorizedText, true)) {
        Utils::EchoUnauthorized($unauthorizedText);
    }
    // Generate new RSA private/public keys
    $rsa = new RSA();
    $rsa->setPrivateKeyFormat(RSA::PRIVATE_FORMAT_PKCS8);
    $rsa->setPublicKeyFormat(RSA::PUBLIC_FORMAT_PKCS8);
    $keys = $rsa->createKey(RSA_PRIVATE_KEY_BITS);
    // Store the keys and token on database
    $session = new SessionToken();
    $session->Token = Utils::NewGUID();
    $session->ClientVersion = $WS_VERSION;
    $session->IPAddress = Utils::GetClientIP();
    $session->RSA_PrivateKey = $keys["privatekey"];
    $session->RSA_PublicKey = $keys["publickey"];
    if ($session->Save()) {
        $rsa->loadKey($session->RSA_PublicKey);
    } else {
        $session = new SessionToken();
    }
    $response = array(
        "token" => base64_encode($session->Token),
        "xml" => base64_encode($rsa->getPublicKey(RSA::PUBLIC_FORMAT_XML))
    );
    Utils::EchoJson($response, TRUE);
}

function wsAuthorize() {
    $token = base64_decode(filter_input(INPUT_POST, "token"));
    $appId = base64_decode(filter_input(INPUT_POST, "app"));
    $appSecret = base64_decode(filter_input(INPUT_POST, "secret"));
    $key = base64_decode(filter_input(INPUT_POST, "key"));
    $iv = base64_decode(filter_input(INPUT_POST, "iv"));
    $success = FALSE;
    $message = "";
    $session = new SessionToken($token);
    if ($session->RSA_PrivateKey && $session->RSA_PublicKey) {
        $rsa = new RSA();
        $rsa->setPrivateKeyFormat(RSA::PRIVATE_FORMAT_PKCS8);
        $rsa->loadKey($session->RSA_PrivateKey);
        $app = AppId::GetApp($rsa->decrypt($appId), $rsa->decrypt($appSecret));
        $key = $rsa->decrypt($key);
        $iv = $rsa->decrypt($iv);
        if (is_null($app)) {
            $message = "Invalid App";
        } else if ($key && $iv) {
            $session->AES_Key = $key;
            $session->AES_IV = $iv;
            $session->IdApp = $app->Id;
            $success = $session->Save();
        } else {
            $message = "Bad request";
        }
    } else {
        $message = "Invalid token";
    }
    if (!$success) {
        $session->Delete();
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage($success, $message));
}

function wsInfo() {
    global $ServerClientSettings, $WS_VERSION, $now;
    $version = array(
        "version" => COMBU_VERSION,
        "requireUpdate" => isHigherVersion($WS_VERSION, defined("MIN_CLIENT_VERSION") ? MIN_CLIENT_VERSION : ""),
        "time" => $now,
        "settings" => json_encode($ServerClientSettings),
        "responseEncrypted" => Utils::ServerResponseRequired()
    );
    Utils::EchoJson($version, TRUE);
}

function wsPing () {
    global $LoggedAccount;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $message = $LoggedAccount->ToJson();
    }
    Utils::EchoJson(Utils::JsonEncodeSuccessMessage(TRUE, $message));
}