<?php

include_once 'lib/api.php';

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\Account;
use Combu\UserGroup;
use Combu\UserGroupAccount;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

        // List user's friends
        case "list":
            wsList();
            break;

        // Add a new friend to a user list
        case "save":
            wsSave();
            break;

        // Delete a friend from a user list
        case "delete":
            wsDelete();
            break;
        
        // Join a group
        case "join":
            wsJoin();
            break;
        
        // Leave a group
        case "leave":
            wsLeave();
            break;

    }
}
$Database->CloseConnection();
exit();


function wsList() {
    global $LoggedAccount, $WS_REQUEST;
    $count = 0;
    $pageCount = 0;
    $list = array();
    if ($LoggedAccount->IsLogged()) {
        // Retrieve the owner from REQUEST
        $name = (isset($WS_REQUEST["Name"]) ? trim($WS_REQUEST["Name"]) : "");
        $idOwner = (!isset($WS_REQUEST["IdOwner"]) ? 0 : intval($WS_REQUEST["IdOwner"]));
        $usernameOwner = (isset($WS_REQUEST["UsernameOwner"]) ? trim($WS_REQUEST["UsernameOwner"]) : "");
        $idMember = (!isset($WS_REQUEST["IdMember"]) ? 0 : intval($WS_REQUEST["IdMember"]));
        $usernameMember = (isset($WS_REQUEST["UsernameMember"]) ? trim($WS_REQUEST["UsernameMember"]) : "");
        $ownerOrMember = ($idOwner > 0 || $usernameOwner) && ($idMember > 0 || $usernameMember);
        $limit = (isset($WS_REQUEST["Limit"]) && ($ownerOrMember || intval($WS_REQUEST["Limit"]) > 0) ? intval($WS_REQUEST["Limit"]) : NULL);
        $page = (isset($WS_REQUEST["Page"]) && intval($WS_REQUEST["Page"]) > 0 ? intval($WS_REQUEST["Page"]) : 1);
        $offset = ($limit === NULL ? NULL : Utils::GetPageOffset($page, $limit));
        // If it's not me, then verify that the user exists
        $owner = new Account( $idOwner > 0 ? $idOwner : $usernameOwner );
        $member = new Account( $idMember > 0 ? $idMember : $usernameMember );
        // Load the groups list
        $groups = UserGroup::Load($name, $owner->Id, $member->Id, $limit, $offset, $count);
        foreach ($groups as $group) {
            $list[] = $group->ToArray();
        }
        // Calculate the pages count
        $pageCount = ($limit === NULL ? 1 : Utils::GetPagesCount($count, $limit));
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($list, $count, $pageCount), FALSE, TRUE);
}

function wsSave() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0);
        $name = (isset($WS_REQUEST["Name"]) ? $WS_REQUEST["Name"] : "");
        $customData = "{}";
        if (isset($WS_REQUEST["CustomData"]))
            $customData = $WS_REQUEST["CustomData"];
        $rec = new UserGroup($id);
        $rec->Name = $name;
        $rec->CustomData = $customData;
        // Get the members list
        $members = array();
        if (isset($WS_REQUEST["IdUser"]))
            $userIds = explode(",", $WS_REQUEST["IdUser"]);
        else
            $userIds = explode(",", $WS_REQUEST["Username"]);
        foreach ($userIds as $idUser) {
            $user = new Account($idUser);
            if ($user->Id > 0)
                $members[] = $user;
        }
        // Set the ownership of the group
        if ($rec->Id < 1) {
            $rec->IdOwner = $LoggedAccount->Id;
            $rec->Public = 1;
        }
        // Validate data
        if ($id != $rec->Id) {
            $message = ErrorMessage::Get(ERROR_GROUP_INVALID);
        } else if (!$rec->Name) {
            $message = ErrorMessage::Get(ERROR_GROUP_NAME);
        } else if ($rec->Exists()) {
            $message = ErrorMessage::Get(ERROR_GROUP_NAME_EXISTS);
        } else {
            // Save the new group
            $success = $rec->Save();
            if ($success) {
                foreach ($members as $user) {
                    $membership = new UserGroupAccount();
                    $membership->IdGroup = $rec->Id;
                    $membership->IdAccount = $user->Id;
                    $membership->Save();
                }
                $message = $rec->ToJson();
            } else {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsDelete() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $rec = new UserGroup(!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        if ($rec->IdOwner != $LoggedAccount->Id)
            $message = ErrorMessage::Get(ERROR_GROUP_INVALID);
        else {
            $success = $rec->Delete();
            if (!$success)
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsJoin() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $rec = new UserGroup(isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0);
        // Validate data
        if ($rec->Id == 0) {
            $message = ErrorMessage::Get(ERROR_GROUP_INVALID);
        } else {
            $userIds = array();
            if (isset($WS_REQUEST["IdUser"]))
                $userIds = explode(",", $WS_REQUEST["IdUser"]);
            else if (isset($WS_REQUEST["Username"]))
                $userIds = explode(",", $WS_REQUEST["Username"]);
            // Fill the list of members to add
            $members = array();
            foreach ($userIds as $id) {
                $user = new Account($id);
                if ($user->Id > 0)
                    $members[] = $user;
            }
            // Verify the members count
            if (count($members) == 0) {
                $message = ErrorMessage::Get(ERROR_GROUP_NO_USERS_ADD);
            } else {
                // Create the memberships
                foreach ($members as $user) {
                    // Add only if the user is not already a member of this group
                    if (UserGroupAccount::Exists($rec->Id, $user->Id)) {
                        $success = TRUE;
                    } else {
                        $membership = new UserGroupAccount();
                        $membership->IdGroup = $rec->Id;
                        $membership->IdAccount = $user->Id;
                        if ($membership->Save())
                            $success = TRUE;
                    }
                }
                if ($success)
                    $message = $rec->ToJson();
                else
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsLeave() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $rec = new UserGroup(isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0);
        // Validate data
        if ($rec->Id == 0) {
            $message = ErrorMessage::Get(ERROR_GROUP_INVALID);
        } else {
            $userIds = array();
            if (isset($WS_REQUEST["IdUser"]))
                $userIds = explode(",", $WS_REQUEST["IdUser"]);
            else if (isset($WS_REQUEST["Username"]))
                $userIds = explode(",", $WS_REQUEST["Username"]);
            // Fill the list of members to add
            $idUser = array();
            foreach ($userIds as $id) {
                $user = new Account($id);
                if ($user->Id > 0)
                    $idUser[] = $user->Id;
            }
            if (count($idUser) == 0) {
                $message = ErrorMessage::Get(ERROR_GROUP_NO_USERS_DELETE);
            } else {
                if (in_array($LoggedAccount->Id, $idUser))
                    $success = TRUE;
                $members = $rec->GetMembers();
                for ($i = count($members) - 1; $i >= 0; --$i) {
                    if (in_array($members[$i]->IdAccount, $idUser)) {
                        // Delete the membership
                        if ($members[$i]->Delete()) {
                            $success = TRUE;
                            // Remove the index from the list
                            array_slice($members, $i, 1);
                        }
                    }
                }
                if ($success) {
                    if (count($members) < 2 && !$rec->Public) {
                        // If remaining members are lesser than 2 and it's not an owned group then delete it
                        $rec->Delete();
                    } else {
                        if (in_array($rec->IdOwner, $idUser)) {
                            // Change ownership to another random member
                            $rnd = rand(0, count($members) - 1);
                            $rec->IdOwner = $members[$rnd]->IdAccount;
                            $rec->Save();
                        }
                    }
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}
