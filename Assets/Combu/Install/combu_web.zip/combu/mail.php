<?php

include_once 'lib/api.php';

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\DataClass;
use Combu\Account;
use Combu\Friend;
use Combu\GameMail;
use Combu\UserGroup;
use Combu\UserGroupAccount;

define ("MAIL_LIST_RECEIVED", 0);
define ("MAIL_LIST_SENT", 1);
define ("MAIL_LIST_BOTH", 2);
define ("MAIL_LIST_UNREAD", 3);

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

        // List user's mail
        case "list":
            wsList();
            break;
        
        // List user's conversations recipients
        case "list_conv":
            wsListConversations();
            break;

        // Send a mail to a user
        case "send":
            wsSend();
            break;

        // Read a mail to a user
        case "read":
            wsRead();
            break;

        // Set Unread a mail to a user
        case "unread":
            wsUnread();
            break;

        // Delete a mail
        case "delete":
            wsDelete();
            break;

        // Count messages
        case "count":
            wsCount();
            break;

    }
}
$Database->CloseConnection();
exit();

function wsList() {
    global $LoggedAccount, $WS_REQUEST;
    $count = 0;
    $list = array();
    $pageCount = 0;
    if ($LoggedAccount->IsLogged()) {
        // Set the limit, offset and page for the results
        $limit = (isset($WS_REQUEST["Limit"]) && intval($WS_REQUEST["Limit"]) > 0 ? intval($WS_REQUEST["Limit"]) : NULL);
        $page = (isset($WS_REQUEST["Page"]) && intval($WS_REQUEST["Page"]) > 0 ? intval($WS_REQUEST["Page"]) : 1);
        $offset = ($limit === NULL ? NULL : Utils::GetPageOffset($page, $limit));
        $listType = (isset($WS_REQUEST["Type"]) ? intval($WS_REQUEST["Type"]) : MAIL_LIST_RECEIVED);
        $idSender = (isset($WS_REQUEST["IdSender"]) ? intval($WS_REQUEST["IdSender"]) : 0);
        $idRecipient = (isset($WS_REQUEST["IdRecipient"]) ? intval($WS_REQUEST["IdRecipient"]) : 0);
        $idGroup = (isset($WS_REQUEST["IdGroup"]) ? intval($WS_REQUEST["IdGroup"]) : 0);
        // Load the results, request parameter 'sent' decides if sent or received
        switch ($listType) {
            case MAIL_LIST_SENT:
                // Get the messages sent by the logged user to others
                $mails = GameMail::Load($idRecipient, $LoggedAccount->Id, $idGroup, FALSE, $limit, $offset, $count);
                break;
            case MAIL_LIST_BOTH:
                // Get both the messages sent and received by the logged user in the form of a conversation,
                // this method requires either $idRecipient or $idGroup to work (else it will return no records)
                $mails = GameMail::LoadConversationMessages($LoggedAccount->Id, $idRecipient, $idGroup, $limit, $offset, $count);
                break;
            case MAIL_LIST_UNREAD:
                $mails = GameMail::Load($LoggedAccount->Id, $idSender, $idGroup, TRUE, $limit, $offset, $count);
                break;
            default:
                // Get the messages received by the logged user
                $mails = GameMail::Load($LoggedAccount->Id, $idSender, $idGroup, FALSE, $limit, $offset, $count);
                break;
        }
        foreach ($mails as $i) {
            $array = $i->ToArray();
            $list[] = $array;
        }
        // Calculate the pages count
        $pageCount = ($limit === NULL ? 1 : Utils::GetPagesCount($count, $limit));
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($list, $count, $pageCount), FALSE, TRUE);
}

function wsListConversations() {
    global $LoggedAccount;
    $list = array();
    if ($LoggedAccount->IsLogged()) {
        $list = GameMail::LoadConversations($LoggedAccount->Id);
    }
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($list, count($list)), FALSE, TRUE);
}

function wsSend() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Create a group from REQUEST if needed
        $recipients = array();
        $groupId = 0;
        if (isset($WS_REQUEST["Id"]) || isset($WS_REQUEST["Username"])) {
            // Send to multiple or single users
            $isId = isset($WS_REQUEST["Id"]);
            $userRequest = $WS_REQUEST[$isId ? "Id" : "Username"];
            $userId = explode(",", $userRequest);
            foreach ($userId as $id) {
                if ($isId)
                    $id = intval($id);
                if ($id) {
                    $user = new Account($id);
                    if ($user->Id > 0)
                        $recipients[] = $user;
                }
            }
            // Create the group
            if (count($recipients) > 1) {
                $group = new UserGroup();
                $group->IdOwner = $LoggedAccount->Id;
                if ($group->Save()) {
                    $groupId = $group->Id;
                    // Add myself
                    $recipients[] = $LoggedAccount;
                    // Add the recipients
                    foreach ($recipients as $user) {
                        $userGroup = new UserGroupAccount();
                        $userGroup->IdGroup = $groupId;
                        $userGroup->IdAccount = $user->Id;
                        $userGroup->Save();
                    }
                } else {
                    // Invalidate the request
                    $recipients = array();
                }
            }
        } else if (isset($WS_REQUEST["IdGroup"])) {
            $groupId = intval($WS_REQUEST["IdGroup"]);
            $group = new UserGroup($groupId);
            if ($group->Id > 0) {
                // Get the recipients from the group
                $members = $group->GetMembersAccount();
                foreach ($members as $user) {
                    $recipients[] = $user;
                }
            } else {
                $groupId = 0;
            }
        }
        // Get message data from REQUEST
        $subject = (!isset($WS_REQUEST["Subject"]) ? "" : $WS_REQUEST["Subject"]);
        $body = (!isset($WS_REQUEST["Message"]) ? "" : $WS_REQUEST["Message"]);
        // Validate the message data
        if (count($recipients) == 0)
            $message = ErrorMessage::Get(ERROR_GAMEMAIL_NO_RECIPIENT);
        else if ($groupId == 0 && $recipients[0]->Id == $LoggedAccount->Id)
            $message = ErrorMessage::Get(ERROR_GAMEMAIL_SELF);
        else if (!$body)
            $message = ErrorMessage::Get(ERROR_GAMEMAIL_MESSAGE);
        else {
            $canSend = TRUE;
            
            // Verify that I'm not in the recipient's ignore list
            if ($groupId == 0) {
                $recs = Friend::Load($recipients[0]->Id, FRIEND_STATE_IGNORE);
                foreach ($recs as $r) {
                    if ($r->IdFriend == $LoggedAccount->Id) {
                        $canSend = FALSE;
                        break;
                    }
                }
            }
            
            // Send the message to every recipient
            if ($canSend) {
                // Add myself if it's being sent to a group and I'm not in the list
                if ($groupId > 0) {
                    $addMe = TRUE;
                    foreach ($recipients as $user) {
                        if ($user->Id == $LoggedAccount->Id) {
                            $addMe = FALSE;
                            break;
                        }
                    }
                    if ($addMe)
                        $recipients[] = $LoggedAccount;
                }
                $date = date("Y-m-d H:i:s");
                $successMessages = array();
                foreach ($recipients as $user) {
                    $rec = new GameMail();
                    $rec->SendDate = $date;
                    $rec->Subject = $subject;
                    $rec->Message = $body;
                    $rec->IdAccount = $user->Id;
                    $rec->IdGroup = $groupId;
                    $rec->IdSender = $LoggedAccount->Id;
                    if ($rec->Save()) {
                        $success = TRUE;
                        $successMessages[] = $rec->ToArray();
                    }
                }
                if ($success) {
                    $message = json_encode($successMessages);
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsRead () {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get the message Id from REQUEST
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        if ($id === -1) {
            $idSenders = (isset($WS_REQUEST["IdSender"]) && !empty($WS_REQUEST["IdSender"]) ? explode(",", $WS_REQUEST["IdSender"]) : array());
            $idGroups = (isset($WS_REQUEST["IdGroup"]) && !empty($WS_REQUEST["IdGroup"]) ? explode(",", $WS_REQUEST["IdGroup"]) : array());
            $mails = GameMail::LoadUnread($LoggedAccount->Id, $idSenders, $idGroups);
        } else {
            $mails = array( new GameMail($id) );
        }
        foreach ($mails as $mail) {
            if ($mail->IdAccount == $LoggedAccount->Id) {
                if (!$mail->ReadDate) {
                    $mail->ReadDate = date("Y-m-d H:i:s");
                    $success = $mail->Save();
                } else {
                    $success = TRUE;
                }
            }
        }
        if (!$success)
            $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsUnread () {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get the message Id from REQUEST
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        $mails = array( new GameMail($id) );
        foreach ($mails as $mail) {
            if ($mail->IdAccount == $LoggedAccount->Id) {
                if ($mail->ReadDate) {
                    $mail->ReadDate = "";
                    $success = $mail->Save();
                } else {
                    $success = TRUE;
                }
            }
        }
        if (!$success)
            $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsDelete() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $rec = new GameMail(!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        if ($rec->IdAccount == $LoggedAccount->Id) {
            $success = $rec->Delete();
            if (!$success) {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        } else {
            $message = ErrorMessage::Get(ERROR_GAMEMAIL_CANNOT_DELETE);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsCount() {
    global $LoggedAccount, $WS_REQUEST;
    $result = array();
    if ($LoggedAccount->IsLogged()) {
        $idSender = (isset($WS_REQUEST["IdSender"]) ? explode(",", $WS_REQUEST["IdSender"]) : array());
        $idGroup = (isset($WS_REQUEST["IdGroup"]) ? explode(",", $WS_REQUEST["IdGroup"]) : array());
        $where_read = sprintf("(IdAccount = %d AND ReadDate IS NOT NULL)", $LoggedAccount->Id);
        $where_unread = sprintf("(IdAccount = %d AND ReadDate IS NULL)", $LoggedAccount->Id);
        foreach ($idSender as $id) {
            if (intval($id) < 1)
                continue;
            $where = sprintf("(IdSender = %d AND IdGroup = 0)", $id);
            $read = DataClass::CountRecords(DataClass::GetTableName(GameMail::class), $where_read . " AND " . $where);
            $unread = DataClass::CountRecords(DataClass::GetTableName(GameMail::class), $where_unread . " AND " . $where);
            $result[] = array(
                "IdSender" => $id,
                "Read" => $read,
                "Unread" => $unread
            );
        }
        foreach ($idGroup as $id) {
            if (intval($id) < 1)
                continue;
            $where = sprintf("(IdGroup = %d)", $id);
            $read = DataClass::CountRecords(DataClass::GetTableName(GameMail::class), $where_read . " AND " . $where);
            $unread = DataClass::CountRecords(DataClass::GetTableName(GameMail::class), $where_unread . " AND " . $where);
            $result[] = array(
                "IdGroup" => $id,
                "Read" => $read,
                "Unread" => $unread
            );
        }
    }
    Utils::EchoJson($result, TRUE, TRUE);
}
