<?php

include_once 'lib/api.php';

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\Account;
use Combu\Inventory;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

        // List all the items of a user inventory
        case "list":
            wsList();
            break;

        // Save an item to a user inventory
        case "save":
            wsSave();
            break;

        // Delete an item from a user inventory
        case "delete":
            wsDelete();
            break;

    }
}
$Database->CloseConnection();
exit();


function wsList() {
    global $LoggedAccount, $WS_REQUEST;
    $inventory = array();
    if ($LoggedAccount->IsLogged()) {
        // Retrieve the owner of inventory from REQUEST
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        // If it's not me, then verify that the user exists
        if ($id != $LoggedAccount->Id && $id > 0) {
            $user = new Account($id);
            // Reset the request if the user doesn't exist
            if ($user->Id < 1)
                $id = 0;
        } else {
            // If no ID was specified, then load my inventory
            $id = $LoggedAccount->Id;
        }
        // Load the inventory items
        $inventory = Inventory::Load($id, TRUE);
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($inventory, count($inventory)), FALSE, TRUE );
}

function wsSave() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Integrity data validation
        if ((!isset($WS_REQUEST["Name"]) || $WS_REQUEST["Name"] === "")) {
            $message = ErrorMessage::Get(ERROR_INVENTORY_INVALID);
        } else {
            // Get the inventory item from REQUEST
            if (isset($WS_REQUEST["Id"]) && intval($WS_REQUEST["Id"]) > 0) {
                $rec = new Inventory(intval($WS_REQUEST["Id"]));
                Utils::FillObjectFromRow($rec, $WS_REQUEST);
            } else if (isset($WS_REQUEST["OneInstance"]) && $WS_REQUEST["OneInstance"] === "1") {
                // Load or create only one instance of this item
                $rec = Inventory::LoadOrCreate($LoggedAccount->Id, $WS_REQUEST["Name"]);
                Utils::FillObjectFromRow($rec, $WS_REQUEST);
            } else {
                $rec = new Inventory($WS_REQUEST, TRUE);
            }
            if (!$rec) {
                $message = ErrorMessage::Get(ERROR_INVENTORY_INVALID);
            } else {
                // Allow to edit only my inventory
                if ($rec->Id > 0 && $rec->IdAccount != $LoggedAccount->Id)
                    $message = ErrorMessage::Get(ERROR_INVENTORY_INVALID);
                else {
                    $customData = "{}";
                    if (isset($WS_REQUEST["CustomData"]))
                        $customData = $WS_REQUEST["CustomData"];
                    $rec->IdAccount = $LoggedAccount->Id;
                    $rec->Quantity = intval($rec->Quantity);
                    $rec->CustomData = $customData;
                    if (!$rec->Name)
                        $message = ErrorMessage::Get(ERROR_INVENTORY_NAME);
                    else {
                        $success = $rec->Save();
                        if (!$success)
                            $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                        else
                            $message = $rec->ToJson();
                    }
                }
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsDelete() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        $rec = new Inventory($id);
        // Can delete only from my own inventory
        if ($rec->IdAccount != $LoggedAccount->Id)
            $message = ErrorMessage::Get(ERROR_INVENTORY_INVALID);
        else {
            $success = $rec->Delete();
            if (!$success)
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}
