<?php

define ("PAGES_TITLE", "Combu");
define ("PAGES_LIST_SIZE", 20);
define ("PAGES_DISPLAY_USERLIST", TRUE);
define ("PAGES_USER_EXCLUDE_CUSTOMDATA", "");
