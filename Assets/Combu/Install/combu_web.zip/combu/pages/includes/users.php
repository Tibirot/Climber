<?php

include_once '../lib/api.php';
include 'config_pages.php';

use Combu\Utils;
use Combu\Account;
use Combu\CustomData;
use Combu\LeaderBoard;
use Combu\Achievement;

$record = NULL;
if (isset($_REQUEST["Id"]) && intval($_REQUEST["Id"]) > 0) {
    // Load a user by Id in the REQUEST
    $record = new Account(intval($_REQUEST["Id"]));
    if ($record->Id < 1) {
        // If the Id is not valid then redirects to the users' list
        Utils::RedirectTo ("?");
    }
}

if (!$record && PAGES_DISPLAY_USERLIST) {
    
    // Load the users' list
    $count = "";
    $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
    $records = Account::Load("", "", NULL, FALSE, PAGES_LIST_SIZE, Utils::GetPageOffset($page, PAGES_LIST_SIZE), $count);
    $pages = Utils::GetPagesCount($count, PAGES_LIST_SIZE);
    
} else {
    
    // Load the user's custom data
    $customData = CustomData::Load($record->Id);
    // Remove the custom data that shouldn't be displayed by configuration
    $excludeData = explode(",", PAGES_USER_EXCLUDE_CUSTOMDATA);
    for ($i = count($customData) - 1; $i >= 0; --$i) {
        $allow = TRUE;
        foreach ($excludeData as $key) {
            if (strcasecmp($key, $customData[$i]->DataKey)) {
                $allow = FALSE;
                break;
            }
        }
        // If it's not allowed then remove from the array
        if (!$allow) {
            array_splice ($customData, $i, 1);
        }
    }
    
    // Load the leaderboards and scores
    $leaderboardsScores = array();
    $leaderboards = LeaderBoard::Load();
    foreach ($leaderboards as $leaderboard) {
        $scoreToday = $leaderboard->LoadHighscoreForAccount(LeaderBoard::HIGHSCORE_TODAY, FALSE, FALSE, $record->Id);
        $scoreWeek = $leaderboard->LoadHighscoreForAccount(LeaderBoard::HIGHSCORE_WEEK, FALSE, FALSE, $record->Id);
        $scoreMonth = $leaderboard->LoadHighscoreForAccount(LeaderBoard::HIGHSCORE_MONTH, FALSE, FALSE, $record->Id);
        $scoreTotal = $leaderboard->LoadHighscoreForAccount(LeaderBoard::HIGHSCORE_TOTAL, FALSE, FALSE, $record->Id);
        $leaderboardsScores[$leaderboard->Id] = array(
            "today" => $scoreToday["Score"] . " (rank #" . $scoreToday["Rank"] . ")",
            "week" => $scoreWeek["Score"] . " (rank #" . $scoreWeek["Rank"] . ")",
            "month" => $scoreMonth["Score"] . " (rank #" . $scoreMonth["Rank"] . ")",
            "total" => $scoreTotal["Score"] . " (rank #" . $scoreTotal["Rank"] . ")"
        );
    }
    
    // Load achievements
    $achievements = Achievement::LoadUserAchievements($record->Id);
}
