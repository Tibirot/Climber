<?php

include_once '../lib/api.php';
include 'config_pages.php';

$record = NULL;
if (isset($_REQUEST["Id"]) && intval($_REQUEST["Id"]) > 0) {
    // Load a leaderboard by Id in the REQUEST
    $record = new LeaderBoard(intval($_REQUEST["Id"]));
    if ($record->Id < 1) {
        // If the Id is not valid then redirects to the users' list
        Utils::RedirectTo ("?");
    }
}

if (!$record && PAGES_DISPLAY_USERLIST) {
    
    // Load the users' list
    $count = "";
    $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
    $records = LeaderBoard::Load(PAGES_LIST_SIZE, Utils::GetPageOffset($page, PAGES_LIST_SIZE), $count);
    $pages = Utils::GetPagesCount($count, PAGES_LIST_SIZE);
    
} else {
    
    // Load the leaderboard's scores
    $count = "";
    $page = (isset($_REQUEST["Page"]) && intval($_REQUEST["Page"]) > 0 ? intval($_REQUEST["Page"]) : 1);
    $scores = $record->LoadHighscore(LeaderBoard::HIGHSCORE_TOTAL, FALSE, FALSE, PAGES_LIST_SIZE, Utils::GetPageOffset($page, PAGES_LIST_SIZE), $count);
    $pages = Utils::GetPagesCount($count, PAGES_LIST_SIZE);
    
}
