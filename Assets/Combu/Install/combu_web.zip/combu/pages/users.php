<?php
include 'includes/users.php';
?>

<?php include 'header.php'; ?>

<?php if (!$record) { ?>

    <h2>Users list</h2>
    <table class="list-records" cellpadding="5" cellspacing="5">
        <thead>
            <tr>
                <th>Username</th>
                <th>Last login</th>
            </tr>
        </thead>
        <?php if (count($records) > 0) { ?>
        <tbody>
        <?php foreach ($records as $r) { ?>
            <tr>
                <td><a href="?Id=<?= $r->Id ?>"><?= htmlentities($r->Username, ENT_QUOTES, 'UTF-8') ?></a></td>
                <td><?= htmlentities(strftime("%d %B %Y %H:%M", Utils::GetTimestamp($r->LastLoginDate)), ENT_QUOTES, 'UTF-8') ?></td>
            </tr>
        <?php } ?>
        </tbody>
        <?php } ?>
        <tfoot>
            <tr>
                <td colspan="2">
                    <div class="page-nav">
                    Pages:
                    <?php if ($page > 1) { ?><a class="page-item" href="?Page=<?= ($page - 1) ?>">Prev.</a><?php } ?>
                    <?php for ($i = 1; $i <= $pages; ++$i) { ?>
                        <a class="page-item" href="?Page=<?= $i ?>"><?= $i ?></a>
                    <?php } ?>
                    <?php if ($page < $pages) { ?><a class="page-item" href="?Page=<?= ($page + 1) ?>">Next</a><?php } ?>
                    </div>
                </td>
            </tr>
        </tfoot>
    </table>

<?php } else { ?>

    <div id="userprofile">
        <?php if (PAGES_DISPLAY_USERLIST) { ?><a href="?">Return to the list</a><?php } ?>
        <h2><?= htmlentities($record->Username, ENT_QUOTES, 'UTF-8') ?></h2>
        <?php if ($record->LastLoginDate) { ?>
        <div class="field">
            <span class="field-label">Last login:</span>
            <span class="field-value"><?= htmlentities(strftime("%d %B %Y %H:%M", Utils::GetTimestamp($record->LastLoginDate)), ENT_QUOTES, 'UTF-8') ?></span>
        </div>
        <?php } ?>

        <h3>Leaderboards</h3>
        <div class="leaderboards">
            <?php foreach ($leaderboards as $leaderboard) { ?>
            <h4><?= htmlentities($leaderboard->Title, ENT_QUOTES, 'UTF-8') ?></h4>
            <div class="score">Today: <?= $leaderboardsScores[$leaderboard->Id]["today"] ?></div>
            <div class="score">Last Week: <?= $leaderboardsScores[$leaderboard->Id]["week"] ?></div>
            <div class="score">Last Month: <?= $leaderboardsScores[$leaderboard->Id]["month"] ?></div>
            <div class="score">All time: <?= $leaderboardsScores[$leaderboard->Id]["total"] ?></div>
            <?php } ?>
        </div>

        <h3>Achievements</h3>
        <div class="achievements">
            <?php foreach ($achievements as $achievement) { ?>
            <div class="achievement"><?= htmlentities($achievement["Title"], ENT_QUOTES, 'UTF-8') ?>: <?= $achievement["Progress"] ?>% <?= ($achievement["Finished"] > 1 ? " (x" . $achievement["Finished"] . ")" : "") ?></div>
            <?php } ?>
        </div>
    </div>

<?php } ?>
        
<?php include 'footer.php'; ?>