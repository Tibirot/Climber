<?php
include 'includes/config_pages.php';
include 'header.php';
?>

<ul>
    <li><a href="users.php">Users</a></li>
    <li><a href="leaderboards.php">Leaderboards</a></li>
</ul>

<?php include 'footer.php'; ?>