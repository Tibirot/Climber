<?php
include 'includes/leaderboards.php';
?>

<?php include 'header.php'; ?>

<?php if (!$record) { ?>

    <h2>Leaderboards list</h2>
    <table class="list-records" cellpadding="5" cellspacing="5">
        <thead>
            <tr>
                <th>Title</th>
                <th>Best score</th>
            </tr>
        </thead>
        <?php if (count($records) > 0) { ?>
        <tbody>
        <?php foreach ($records as $r) { ?>
            <?php
            $scores = $r->LoadHighscore(LeaderBoard::HIGHSCORE_TOTAL, FALSE, FALSE, 1);
            $score = NULL;
            $user = NULL;
            if (count($scores) > 0) {
                $score = $scores[0];
                $user = json_decode($score["User"], TRUE);
            }
            ?>
            <tr>
                <td><a href="?Id=<?= $r->Id ?>"><?= htmlentities($r->Title, ENT_QUOTES, 'UTF-8') ?></a></td>
                <td><?= (!$score ? "-" : htmlentities($score["Score"] . " by " . $user["Username"], ENT_QUOTES, 'UTF-8')) ?></td>
            </tr>
        <?php } ?>
        </tbody>
        <?php } ?>
        <tfoot>
            <tr>
                <td colspan="2">
                    <div class="page-nav">
                    Pages:
                    <?php if ($page > 1) { ?><a class="page-item" href="?Page=<?= ($page - 1) ?>">Prev.</a><?php } ?>
                    <?php for ($i = 1; $i <= $pages; ++$i) { ?>
                        <a class="page-item" href="?Page=<?= $i ?>"><?= $i ?></a>
                    <?php } ?>
                    <?php if ($page < $pages) { ?><a class="page-item" href="?Page=<?= ($page + 1) ?>">Next</a><?php } ?>
                    </div>
                </td>
            </tr>
        </tfoot>
    </table>

<?php } else { ?>

    <div id="leaderboard">
        <a href="?">Return to the list</a>
        
        <h2><?= htmlentities($record->Title, ENT_QUOTES, 'UTF-8') ?></h2>
        <?php if ($record->Description) { ?>
        <p><?= htmlentities($record->Description, ENT_QUOTES, 'UTF-8') ?></p>
        <?php } ?>

        <table class="list-records" cellpadding="5" cellspacing="5">
            <thead>
                <tr>
                    <th>Score</th>
                    <th>Player</th>
                </tr>
            </thead>
            <tbody>
        <?php foreach ($scores as $score) { ?>
            <?php $user = json_decode($score["User"], TRUE); ?>
                <tr>
                    <td align="right"><?= htmlentities($score["Score"], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlentities($user["Username"], ENT_QUOTES, 'UTF-8') ?></td>
                </tr>
        <?php } ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="2">
                        <div class="page-nav">
                        Pages:
                        <?php if ($page > 1) { ?><a class="page-item" href="?Page=<?= ($page - 1) ?>">Prev.</a><?php } ?>
                        <?php for ($i = 1; $i <= $pages; ++$i) { ?>
                            <a class="page-item" href="?Page=<?= $i ?>"><?= $i ?></a>
                        <?php } ?>
                        <?php if ($page < $pages) { ?><a class="page-item" href="?Page=<?= ($page + 1) ?>">Next</a><?php } ?>
                        </div>
                    </td>
                </tr>
            </tfoot>
        </table>
        
    </div>

<?php } ?>
        
<?php include 'footer.php'; ?>