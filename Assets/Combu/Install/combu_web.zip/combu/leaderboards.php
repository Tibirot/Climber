<?php

include_once "lib/api.php";

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\LeaderBoard;
use Combu\Account;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

    // Load a Leaderboard
    case "load":
        wsLoad();
        break;

    // List Leaderboard Highscore
    case "highscore":
        wsHighscore();
        break;
    
    // Highscore for a player
    case "highscore_account":
        wsHighscoreForAccount();
        break;

    // Insert score into Leaderboard
    case "score":
        wsScore();
        break;

    }
}
$Database->CloseConnection();
exit();

function allowAccessToApp($idApp) {
    global $AppId;
    if (intval($idApp) <= 0) {
        return TRUE;
    }
    return ($AppId->IsValid() && $idApp == $AppId->Id);
}

function wsLoad() {
    global $WS_REQUEST;
    // Get data from REQUEST
    $id = (isset($WS_REQUEST["IdLeaderboard"]) ? $WS_REQUEST["IdLeaderboard"] : 0);
    $success = FALSE;
    $message = "";
    // Does the leaderboard exist?
    $leaderboard = new LeaderBoard($id);
    if ($leaderboard->Id > 0 && allowAccessToApp($leaderboard->IdApp)) {
        $success = TRUE;
        $message = $leaderboard->ToJson();
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

/**
 * Retrieve a page of scores
 * @global Account $LoggedAccount
 */
function wsHighscore() {
    global $LoggedAccount, $WS_REQUEST;
    $highscore = array();
    $count = 0;
    $pageCount = 0;
    // Get data from REQUEST
    $id = (isset($WS_REQUEST["IdLeaderboard"]) ? $WS_REQUEST["IdLeaderboard"] : 0);
    // Does the leaderboard exist?
    $leaderboard = new LeaderBoard($id);
    $extraParams = NULL;
    if ($leaderboard->Id > 0 && allowAccessToApp($leaderboard->IdApp)) {
        // Return total scores by default
        $timeInterval = LeaderBoard::HIGHSCORE_WEEK;
        if (isset($WS_REQUEST["Interval"])) {
            $timeInterval = intval($WS_REQUEST["Interval"]);
            // Verify the value of interval, switch back to default if needed
            if ($timeInterval < LeaderBoard::HIGHSCORE_TOTAL || $timeInterval > LeaderBoard::HIGHSCORE_TODAY) {
                $timeInterval = LeaderBoard::HIGHSCORE_WEEK;
            }
        }
        // Set the limit, offset and page for the results
        $limit = (isset($WS_REQUEST["Limit"]) && intval($WS_REQUEST["Limit"]) > 0 ? intval($WS_REQUEST["Limit"]) : DEFAULT_LIST_LIMIT);
        $page = (isset($WS_REQUEST["Page"]) && intval($WS_REQUEST["Page"]) > 0 ? intval($WS_REQUEST["Page"]) : 1);
        $userScope = (isset($WS_REQUEST["UserScope"]) ? intval($WS_REQUEST["UserScope"]) : LeaderBoard::USERSCOPE_GLOBAL);
        $groupPlayer = (isset($WS_REQUEST["GroupPlayer"]) && $WS_REQUEST["GroupPlayer"] === "1");
        $sumPlayer = (isset($WS_REQUEST["SumPlayer"]) && $WS_REQUEST["SumPlayer"] === "1");
        if ($userScope < LeaderBoard::USERSCOPE_GLOBAL || $userScope > LeaderBoard::USERSCOPE_FRIENDS) {
            $userScope = LeaderBoard::USERSCOPE_GLOBAL;
        }
        // Load the results
        $highscore = $leaderboard->LoadHighscore($timeInterval, $userScope, $groupPlayer, $sumPlayer, $limit, Utils::GetPageOffset($page, $limit), $count);
        // Calculate the pages count
        $pageCount = Utils::GetPagesCount($count, $limit);
        // Get the local player score
        if ($LoggedAccount->IsLogged()) {
            $localScore = $leaderboard->LoadHighscoreForAccount($timeInterval, $groupPlayer, $sumPlayer, $LoggedAccount->Id);
            $extraParams = array("localScore" => $localScore);
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($highscore, $count, $pageCount, $extraParams), FALSE, TRUE );
}

function wsHighscoreForAccount () {
    global $WS_REQUEST, $AppId;
    $accountSrc = NULL;
    if (isset($WS_REQUEST["Id"]) && intval($WS_REQUEST["Id"]) > 0) {
        $accountSrc = intval($WS_REQUEST["Id"]);
    } else if (isset($WS_REQUEST["Username"]) && !empty($WS_REQUEST["Username"])) {
        $accountSrc = $WS_REQUEST["Username"];
    }
    $account = new Account($accountSrc);
    $idLeaderboard = !isset($WS_REQUEST["IdLeaderboard"]) ? 0 : $WS_REQUEST["IdLeaderboard"];
    $leaderboard = new LeaderBoard($idLeaderboard);
    $isMultiple = ($leaderboard->Id < 1);
    $timeInterval = LeaderBoard::HIGHSCORE_WEEK;
    if (isset($WS_REQUEST["Interval"])) {
        $timeInterval = intval($WS_REQUEST["Interval"]);
        // Verify the value of interval, switch back to default if needed
        if ($timeInterval < LeaderBoard::HIGHSCORE_TOTAL || $timeInterval > LeaderBoard::HIGHSCORE_TODAY) {
            $timeInterval = LeaderBoard::HIGHSCORE_WEEK;
        }
    }
    $limit = (isset($WS_REQUEST["Limit"]) && intval($WS_REQUEST["Limit"]) > 0 ? intval($WS_REQUEST["Limit"]) : DEFAULT_LIST_LIMIT);
    $groupPlayer = (isset($WS_REQUEST["GroupPlayer"]) && $WS_REQUEST["GroupPlayer"] === "1");
    $sumPlayer = (isset($WS_REQUEST["SumPlayer"]) && $WS_REQUEST["SumPlayer"] === "1");
    
    $results = array();
    $result = array("Score" => 0, "Rank" => 0, "Page" => 0, "User" => NULL);
    if ($account->Id > 0) {
        $leaderboards = array();
        if ($isMultiple) {
            if ($AppId->IsValid()) {
                $leaderboards = LeaderBoard::Load($AppId->Id);
            }
        } else {
            if ($leaderboard->Id > 0 && allowAccessToApp($leaderboard->IdApp)) {
                $leaderboards[] = $leaderboard;
            }
        }
        foreach ($leaderboards as $leaderboard) {
            $newresult = $leaderboard->LoadHighscoreForAccount($timeInterval, $groupPlayer, $sumPlayer, $account->Id);
            if (!$isMultiple) {
                $newresult["Page"] = $limit > 0 ? ceil($newresult["Rank"] / $limit) : 1;
            }
            $newresult["User"] = $account->ToJson();
            $results[] = $newresult;
        }
    }
    if ($isMultiple) {
        $result = $results;
    } else {
        if (count($results) > 0) {
            $result = $results[0];
        }
    }
    Utils::EchoJson( $result, TRUE, TRUE );
}

function wsScore() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    $id = (isset($WS_REQUEST["IdLeaderboard"]) ? $WS_REQUEST["IdLeaderboard"] : 0);
    $username = (isset($WS_REQUEST["Username"]) ? $WS_REQUEST["Username"] : "");
    // Does the leaderboard exist?
    $leaderboard = new LeaderBoard($id);
    if ($leaderboard->Id > 0 && allowAccessToApp($leaderboard->IdApp)) {
        $account = NULL;
        if ($LoggedAccount->IsLogged()) {
            // Set the scoring player by logged user
            $account = $LoggedAccount;
        } else if ($leaderboard->AllowAnonymous && $username) {
            // Set the scoring player by REQUEST
            $account = new Account();
            $account->Username = $username;
        }
        if ($account) {
            // Get data from REQUEST
            $score = (isset($WS_REQUEST["Score"]) ? $WS_REQUEST["Score"] : "");
            $success = $leaderboard->PostScore($account, $score);
            if (!$success) {
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
            }
        } else {
            $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_LEADERBOARD_INVALID);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}
