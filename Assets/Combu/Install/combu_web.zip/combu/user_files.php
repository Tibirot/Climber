<?php

set_time_limit(0);

include_once 'lib/api.php';

use Combu\Utils;
use Combu\ErrorMessage;
use Combu\Account;
use Combu\Friend;
use Combu\UserFile;
use Combu\UserFileActivity;
use Combu\FileUpload;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

        // List user files
        case "list":
            wsList();
            break;
        
        // Load a user file
        case "load":
            wsLoad();
            break;

        // Save user file
        case "save":
            wsSave();
            break;

        // Delete user file
        case "delete":
            wsDelete();
            break;

        // Increments Likes count
        case "like":
            wsLikes();
            break;

        // Increments Views count
        case "view":
            wsViews();
            break;

    }
}
$Database->CloseConnection();
exit();

function loggedAccountCanAccessFile ($userFile) {
    global $LoggedAccount;
    if ($userFile->IdAccount == $LoggedAccount->Id && $LoggedAccount->IsLogged()) {
        return TRUE;
    }
    switch ($userFile->ShareType) {
        case SHARETYPE_EVERYBODY:
            // Shared with everyone, add this file
            return TRUE;
        case SHARETYPE_NOBODY:
            // Not shared, skip this file
            break;
        case SHARETYPE_FRIENDS:
            // Shared only with friends, verify that we are in the list
            if ($LoggedAccount->IsLogged()) {
                $friends = Friend::Load($userFile->IdAccount, FRIEND_STATE_ACCEPTED);
                foreach ($friends as $friend) {
                    if ($friend->IdFriend == $LoggedAccount->Id) {
                        return TRUE;
                    }
                }
            }
            // If not an accepted friend then skip this file
            break;
    }
    return FALSE;
}

function wsList() {
    global $LoggedAccount, $WS_REQUEST;
    $files = array();
    $count = 0;
    $pageCount = 0;
    if ($LoggedAccount->IsLogged()) {
        // Retrieve the owner of files from REQUEST
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        $includeShared = (!isset($WS_REQUEST["Shared"]) ? FALSE : $WS_REQUEST["Shared"] === "1");
        // Set the limit, offset and page for the results
        $limit = (isset($WS_REQUEST["Limit"]) && intval($WS_REQUEST["Limit"]) > 0 ? intval($WS_REQUEST["Limit"]) : DEFAULT_LIST_LIMIT);
        $page = (isset($WS_REQUEST["Page"]) && intval($WS_REQUEST["Page"]) > 0 ? intval($WS_REQUEST["Page"]) : 1);
        // If it's not me, then verify that the user exists
        if ($id != $LoggedAccount->Id && $id > 0) {
            $user = new Account($id);
            // Reset the request if the user doesn't exist
            if ($user->Id < 1) {
                $id = 0;
            }
        } else {
            // If no ID was specified, then load my inventory
            $id = $LoggedAccount->Id;
        }
        // Load the files
        if ($LoggedAccount->Id != $id) {
            $includeShared = FALSE;
        }
        $userFiles = UserFile::Load($id, $includeShared, FALSE, $limit, Utils::GetPageOffset($page, $limit), $count);
        // Calculate the pages count
        $pageCount = Utils::GetPagesCount($count, $limit);
        for ($i = 0; $i < count($userFiles); ++$i) {
            // Skip this file if we don't meet the share conditions
            if (loggedAccountCanAccessFile($userFiles[$i])) {
                // Get the file data of the logged account
                $file = $userFiles[$i]->ToArrayClient();
                $files[] = $file;
            }
        }
    }
    Utils::EchoJson( Utils::JsonEncodeRowsMessage($files, $count, $pageCount), FALSE, TRUE );
}

function wsLoad() {
    global $WS_REQUEST;
    $success = FALSE;
    $message = "";
    $file = new UserFile(isset($WS_REQUEST["Id"]) ? intval($WS_REQUEST["Id"]) : 0);
    if ($file->Id > 0 && loggedAccountCanAccessFile($file)) {
        $success = TRUE;
        $message = $file->ToJsonClient();
    } else {
        $message = ErrorMessage::Get(ERROR_USERFILE_INVALID);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsSave() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        // Get the file from REQUEST
        if (isset($WS_REQUEST["Id"])) {
            $rec = new UserFile(intval($WS_REQUEST["Id"]));
            Utils::FillObjectFromRow($rec, $WS_REQUEST);
        } else {
            $rec = new UserFile($WS_REQUEST);
        }
        // Allow to edit only my files
        if ($rec->Id > 0 && $rec->IdAccount != $LoggedAccount->Id)
            $message = ErrorMessage::Get(ERROR_USERFILE_INVALID);
        else {
            $upload = new FileUpload("File");
            $uploaded= $upload->IsUploaded();
            if ($rec->Id <= 0 && !$uploaded)
                $message = ErrorMessage::Get(ERROR_USERFILE_NOT_UPLOADED);
            else if ($uploaded && !$upload->Upload())
                $message = ErrorMessage::Get(ERROR_USERFILE_MOVE_UPLOADED);
            else {
                $oldFile = ($rec->Id > 0 ? $rec->Url : "");
                $customData = "{}";
                if (isset($WS_REQUEST["CustomData"]))
                    $customData = $WS_REQUEST["CustomData"];
                $rec->IdAccount = $LoggedAccount->Id;
                $rec->Name = $WS_REQUEST["Name"];
                $rec->CustomData = $customData;
                if ($uploaded)
                    $rec->Url = $upload->GetDestinationUrl();
                $success = $rec->Save();
                if ($success) {
                    $rec->Url = Utils::GetUploadUrl($rec->Url);
                    $message = $rec->ToJson ();
                    // Delete old file
                    if ($oldFile && file_exists(UPLOAD_FOLDER . $oldFile) && defined("UPLOAD_DELETE_OLD_FILES") && UPLOAD_DELETE_OLD_FILES === TRUE) {
                        try {
                            unlink(UPLOAD_FOLDER . $oldFile);
                        } catch (Exception $ex) {

                        }
                    }
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsDelete() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        $rec = new UserFile($id);
        // Can delete only from my own files
        if ($rec->IdAccount != $LoggedAccount->Id)
            $message = ErrorMessage::Get(ERROR_USERFILE_INVALID);
        else {
            $success = $rec->Delete();
            if ($success)
                @unlink (UPLOAD_FOLDER . $rec->Url);
            else
                $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsLikes() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        $rec = new UserFile($id);
        if ($rec->Id > 0) {
            // Loads the activity of the currently logged user on this file
            $activity = UserFileActivity::Load($rec->Id, $LoggedAccount->Id);
            if (count($activity) > 0)
                $activity = $activity[0];
            else
                $activity = NULL;
            // Verify data
            if (!loggedAccountCanAccessFile($rec)) {
                // The currently logged user cannot access this file
                $message = ErrorMessage::Get(ERROR_USERFILE_INVALID);
            } else if ($activity && $activity->Likes > 0) {
                // The currently logged user has already sent a Like for this file
                $message = ErrorMessage::Get(ERROR_USERFILE_VOTED);
            } else {
                $success = $rec->AddLike();
                if ($success) {
                	$rec->Url = Utils::GetUploadUrl($rec->Url);
                    $message = $rec->ToJson ();
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
        } else {
            $message = ErrorMessage::Get(ERROR_USERFILE_INVALID);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}

function wsViews() {
    global $LoggedAccount, $WS_REQUEST;
    $success = FALSE;
    $message = "";
    if ($LoggedAccount->IsLogged()) {
        $id = (!isset($WS_REQUEST["Id"]) ? 0 : intval($WS_REQUEST["Id"]));
        $rec = new UserFile($id);
        if ($rec->Id > 0) {
            // Can delete only from my own files
            if (!loggedAccountCanAccessFile($rec)) {
                $message = ErrorMessage::Get(ERROR_USERFILE_INVALID);
            } else {
                $success = $rec->AddView();
                if ($success) {
                    $rec->Url = Utils::GetUploadUrl($rec->Url);
                    $message = $rec->ToJson();
                } else {
                    $message = ErrorMessage::Get(ERROR_UNEXPECTED_GENERIC);
                }
            }
        } else {
            $message = ErrorMessage::Get(ERROR_USERFILE_INVALID);
        }
    } else {
        $message = ErrorMessage::Get(ERROR_USER_NOT_AUTHENTICATED);
    }
    Utils::EchoJson( Utils::JsonEncodeSuccessMessage($success, $message), FALSE, TRUE );
}
