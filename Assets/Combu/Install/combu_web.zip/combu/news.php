<?php

include_once 'lib/api.php';

use Combu\Utils;
use Combu\News;

if (isset($WS_REQUEST["action"])) {
    switch ($WS_REQUEST["action"]) {

        // List news
        case "list":
            wsList();
            break;

    }
}
$Database->CloseConnection();
exit();

function wsList() {
    global $WS_REQUEST, $AppId;
    $count = 0;
    $list = array();
    // Set the limit, offset and page for the results
    $limit = (isset($WS_REQUEST["Limit"]) && intval($WS_REQUEST["Limit"]) > 0 ? intval($WS_REQUEST["Limit"]) : DEFAULT_LIST_LIMIT);
    $page = (isset($WS_REQUEST["Page"]) && intval($WS_REQUEST["Page"]) > 0 ? intval($WS_REQUEST["Page"]) : 1);
    // Load the results
    $news = News::Load(0, $limit, Utils::GetPageOffset($page, $limit), $count);
    foreach ($news as $i) {
        $array = Utils::ObjectToArray($i);
        // Hide Id admin account to clients
        unset($array["IdAdminAccount"]);
        $list[] = $array;
    }
    // Calculate the pages count
    $pageCount = Utils::GetPagesCount($count, $limit);
    Utils::EchoJson(Utils::JsonEncodeRowsMessage($list, $count, $pageCount), FALSE, TRUE);
}
