<?php

/*
 * This sample script can help you to keep the table SessionToken clean
 * by deleting all tokens older than $CLEAN_FROM_DAYS days from today.
 * You can use this code in a scheduled job in your OS to be executed,
 * for example once per week if you have $CLEAN_FROM_DAYS equals to 7.
 */

include '../lib/api.php';

use Combu\SessionToken;
use Combu\Utils;

$CLEAN_FROM_DAYS = 7;

if ($CLEAN_FROM_DAYS > 0) {
    
    $interval_spec = sprintf("P%dD", $CLEAN_FROM_DAYS);
    $toDate = Utils::GetCurrentDateTime()->sub(new DateInterval($interval_spec));
    $dateString = $toDate->format("Y-m-d") . " 23:59:59";
    
    $deleted = 0;
    $sessions = SessionToken::Load(0, NULL, $dateString);
    foreach ($sessions as $session) {
        if ($session->Delete()) {
            $deleted++;
        }
    }
    
    echo sprintf("Deleted %d Session Tokens until %s", $deleted, $dateString);
}
