<?php

/*
 * General
 */
// Define the relative URL of Combu folder, including the last path separator (e.g.: /your_combu_path/)
define ("URL_ROOT", "/combu/");
// Debug the web services data: if TRUE then the data is loaded from both GET and POST, else it is loaded only from POST (set to FALSE or comment the following line in the production environment)
define ("WS_DEBUG", TRUE);
// Default size of a records list when limit is not specified in the REQUEST (must be greater than zero)
define ("DEFAULT_LIST_LIMIT", 20);
// Alphanumeric characters used to generate a random code (e.g.: Activation Code and Reset Password Authorization Code)
define ("RANDOM_CODE_CHARS", "bcdfghjklmnpqrstvwxzBCDFGHJKLMNPQRSTVWXZ0123456789");
// Default length of a random code (e.g.: Activation Code and Reset Password Authorization Code)
define ("RANDOM_CODE_LENGTH", 10);


/*
 * Database connection
 */
// Should use PDO for the database functions? (If FALSE then it uses mysqli)
define ("GAME_DB_USE_PDO", TRUE);
// Database engine (only if PDO is enabled, this must be supported by PDO)
define ("GAME_DB_TYPE", "mysql");
// Database Server hostname or IP (if MySql runs on the same machine use 'localhost')
define ("GAME_DB_SERVER", "localhost");
// The port of the database connection (default MySql port is 3306)
define ("GAME_DB_PORT", 3306);
// The name of the database
define ("GAME_DB_NAME", "combu");
// The username of the database connection
define ("GAME_DB_USER", "root");
// The password of the database connection
define ("GAME_DB_PASS", "");
// Prefix for table names
define ("GAME_DB_PREFIX", "");


/*
 * Security
 */
// Key bits length for RSA generation (higher values increase security but require more time to generate keys)
define ("RSA_PRIVATE_KEY_BITS", 2048);
// Should encrypt the server response to web services? (TRUE increase security but requires more resources/time both in server and in client)
define ("RESPONSE_ENCRYPTED", TRUE);
// Should deny the connections when the clients don't send their version number?
define ("DENY_UNVERSIONED_CLIENT", TRUE);
// Minimum version of client's CombuManager.COMBU_VERSION to be considered as out of range
define ("MIN_CLIENT_VERSION", "");
// Maximum version of client's CombuManager.COMBU_VERSION to be considered as out of range
define ("MAX_CLIENT_VERSION", "");
// Should refuse the connections from out of range versions?
define ("DENY_OUTRANGE_VERSIONS", TRUE);


/*
 * Email
 */
// Sender address for sending emails
define ("EMAIL_SENDER_ADDRESS", "noreply@yourserver.com");
// Sender name for sending emails
define ("EMAIL_SENDER_NAME", "Your App Title");
// Sender address for sending newsletters
define ("NEWSLETTER_SENDER_ADDRESS", "noreply@yourserver.com");
// Sender name for sending newsletters
define ("NEWSLETTER_SENDER_NAME", "Your Newsletter");
// Is Email required for new users?
define ("REGISTER_EMAIL_REQUIRED", FALSE);
// Is Email required for guest users?
define ("REGISTER_EMAIL_REQUIRED_FOR_GUEST", FALSE);
// Allow multiple accounts with the same email?
define ("REGISTER_EMAIL_MULTIPLE", FALSE);
// Should verify email registration with activation code?
define ("REGISTER_EMAIL_ACTIVATION", FALSE);
// The regitration mail subject (if activation code is required)
define ("REGISTER_EMAIL_SUBJECT", "Confirm account registration");
// Name of the HTML/text file containing the mail message (the file must exists in /email_templates)
define ("REGISTER_EMAIL_MESSAGE", "email_register.html");
// Is the email content HTML (TRUE) or plain text (FALSE)?
define ("REGISTER_EMAIL_HTML", TRUE);
// The regitration mail subject (if activation code is required)
define ("RESETPWD_EMAIL_SUBJECT", "Reset your password");
// Name of the HTML/text file containing the mail message (the file must exists in /email_templates)
define ("RESETPWD_EMAIL_MESSAGE", "email_resetpwd.html");


/*
 * Users
 */
// Time interval in seconds to consider a user online (HTTP is asynchronous protocol, so there is no realtime connection)
define ("ONLINE_SECONDS", 120);
// Should delete all other sessions of an account after login? (if TRUE then your users can be authenticated only on one client at once, all other sessions will be invalidated)
define ("CLEAR_PLAYER_SESSIONS", FALSE);
// Prefix of Username of guest accounts
define ("GUEST_PREFIX", "Guest-");
// Is required to accept the friendship (TRUE) or users can add friends freely (FALSE)?
define ("FRIENDS_REQUIRE_ACCEPT", FALSE);


/*
 * Upload
 */
// Should delete old file upon new upload? (TRUE will keep your upload folder clean with latest changes to UserFile)
define ("UPLOAD_DELETE_OLD_FILES", TRUE);


/*
 * Log
 */
// Name of the log file (in the folder /_logs/)
define ("LOG_FILENAME", "app.log");
// Max size in bytes of the log file (if it reaches this size the system will backup the current)
define ("LOG_MAXFILESIZE", 2048);

