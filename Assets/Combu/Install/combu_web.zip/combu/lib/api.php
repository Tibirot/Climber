<?php

// Composer autoloader http://getcomposer.org/
include_once __DIR__ . "/../vendor/autoload.php";

include_once __DIR__ . "/config.php";
include_once __DIR__ . "/constants.php";
include_once __DIR__ . "/functions.php";

use Combu\AppLog;
use Combu\Database;
use Combu\AddonModule;
use Combu\ErrorMessage;
use Combu\ServerSettings;
use Combu\Account;
use Combu\Utils;
use Combu\AppId;

// Start PHP session
ob_start();
session_start();

// Initialize the application logging utility
AppLog::Initialize();

// Initialize the error messages
ErrorMessage::Initialize(getRequestParam("lang"));

// Set the default Timezone to UTC
date_default_timezone_set ("UTC");

// Get the current date/time for global use
$now = Utils::GetCurrentDateTimeFormat();

// Initialize the global Database connection
if (defined("GAME_DB_USE_PDO") && GAME_DB_USE_PDO === TRUE) {
    $Database = new \Combu\DatabasePDO(GAME_DB_TYPE, GAME_DB_SERVER, GAME_DB_PORT, GAME_DB_NAME, GAME_DB_USER, GAME_DB_PASS);
} else {
    $Database = new Database(GAME_DB_TYPE, GAME_DB_SERVER, GAME_DB_PORT, GAME_DB_NAME, GAME_DB_USER, GAME_DB_PASS);
}

// Initialize the game server settings
global $ServerClientSettings;
$ServerSettings = ServerSettings::GetCurrentSettings($ServerClientSettings);

// Initialize the add-ons
$Addons = AddonModule::LoadAddons();

// The current AppId of web services
$AppId = new AppId();

// The user account that is currently logged to the web service
$LoggedAccount = new Account();

// Load the request to web services
getWebServiceRequest();
