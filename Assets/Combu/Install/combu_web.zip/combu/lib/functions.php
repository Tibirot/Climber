<?php

use Combu\AppLog;
use Combu\Utils;
use Combu\ErrorMessage;
use Combu\AppId;
use Combu\Account_App;
use Combu\Account;
use Combu\SessionToken;
use Combu\IpBan;
use phpseclib\Crypt\AES;

/**
 * Load the data of web services from Request
 * @global string $WS_TOKEN
 * @global Combu\SessionToken $WS_SESSION
 * @global array[string]string $WS_REQUEST
 * @global string $WS_VERSION
 * @global Combu\AppId $AppId
 * @global Combu\Account $LoggedAccount
 */
function getWebServiceRequest() {
    global $WS_TOKEN, $WS_SESSION, $WS_REQUEST, $WS_VERSION, $AppId, $LoggedAccount, $ServerSettings;
    
    $AppId = new AppId();
    $LoggedAccount = new Account();
    
    $WS_TOKEN = NULL;
    $WS_SESSION = NULL;
    $WS_VERSION = "";
    $WS_REQUEST = array();
    
    // Get the token and data from Request
    $ipaddress = Utils::GetClientIP();
    $token = getWebServiceRequestToken();
    $rawRequest = getWebServiceRequestData();
    $request = (empty($rawRequest) ? "" : base64_decode($rawRequest));
    
    $idAccount = 0;
    $aes = NULL;
    $session = NULL;
    $isValidRequest = TRUE;
    
    // Load the Token and initialize the AES decryptor
    if ($token) {
        $session = new SessionToken($token);
        if ($session->Token && $session->IPAddress == $ipaddress) {
            $session->UpdateLastAction();
            $WS_VERSION = $session->ClientVersion;
            $idAccount = $session->IdAccount;
            $isValidRequest = isValidRequest($unauthorizedText);
            if ($isValidRequest) {
                $aes = new AES();
                $aes->setKey(base64_decode($session->AES_Key));
                $aes->setIV(base64_decode($session->AES_IV));
            }
        }
    }
    
    // Decrypt the web services request
    if ($isValidRequest && $token && $request && $aes) {
        $request = json_decode($aes->decrypt($request), TRUE);
        if (!empty($request)) {
            // Validate the App Id and Secret key
            if (isset($request["app_id"]) && isset($request["app_secret"])) {
                $app = AppId::GetApp($request["app_id"], $request["app_secret"]);
                if ($app) {
                    $AppId = $app;
                }
            }
            
            $isValidRequest = ($AppId->IsActive() && $AppId->IsValid());
            if ($isValidRequest)
            {
                // Verify that the client IP address is not banned
                if (count(IpBan::Load($AppId->Id, 0, $ipaddress)) > 0) {
                    if (defined("LOG_BANNED") && LOG_BANNED === TRUE) {
                        AppLog::Info("Banned IP request: (IP) " . $ipaddress . " (Token) ". $token . " (Data) " . $rawRequest);
                    }
                    $isValidRequest = FALSE;
                }
                
                // Validate the logged account (if set in the session)
                if ($isValidRequest && $idAccount > 0) {
                    $LoggedAccount = new Account($idAccount);
                    if ($LoggedAccount->IsLogged()) {
                        $LoggedAccount->GUID = $token;
                        Account_App::InsertOrUpdate($LoggedAccount->Id, $AppId->Id);
                    } else {
                        $isValidRequest = FALSE;
                    }
                }
            }
        }
    }
    
    if ($isValidRequest) {
        // Continue to process the result
        $WS_TOKEN = $token;
        $WS_SESSION = $session;
        $WS_REQUEST = $request;
    } else {
        // Log the unauthorized request
        if (defined("LOG_UNAUTHORIZED") && LOG_UNAUTHORIZED === TRUE) {
            AppLog::Info("Unauthorized request: (IP) " . $ipaddress . " (Token) ". $token . " (Data) " . $rawRequest);
        }
        Utils::EchoUnauthorized($unauthorizedText);
    }
}

/**
 * Check whether the current request is valid
 * @param string $unauthorizedText Error message in case of invalid request
 */
function isValidRequest(&$unauthorizedText) {
    global $WS_VERSION;
    $isValidRequest = TRUE;
    $unauthorizedText = "";
    // Validate client version
    if (defined("DENY_UNVERSIONED_CLIENT") && DENY_UNVERSIONED_CLIENT === TRUE && empty($WS_VERSION))
    {
        $isValidRequest = FALSE;
    }
    else
    {
        // Deny out of range versions?
        if (defined("DENY_OUTRANGE_VERSIONS") && DENY_OUTRANGE_VERSIONS === TRUE)
        {
            if (defined("MIN_CLIENT_VERSION") && !empty(MIN_CLIENT_VERSION))
            {
                if (isHigherVersion($WS_VERSION, MIN_CLIENT_VERSION))
                {
                    $isValidRequest = FALSE;
                    $unauthorizedText = ErrorMessage::Get(ERROR_REQUIRE_CLIENT_UPDATE);
                }
            }
            if (defined("MAX_CLIENT_VERSION") && !empty(MAX_CLIENT_VERSION))
            {
                if (isHigherVersion(MAX_CLIENT_VERSION, $WS_VERSION))
                {
                    $isValidRequest = FALSE;
                    $unauthorizedText = ErrorMessage::Get(ERROR_REQUIRE_CLIENT_UPDATE);
                }
            }
        }
    }
    return $isValidRequest;
}

/**
 * Gets a parameter from Request
 * @param string $paramName
 * @param bool $isWebService
 * @return string
 */
function getRequestParam($paramName, $isWebService = FALSE) {
    $value = filter_input(INPUT_POST, $paramName);
    if (!$value && (!$isWebService || (defined("WS_DEBUG") && WS_DEBUG === TRUE))) {
        $value = filter_input(INPUT_GET, $paramName);
    }
    return $value;
}

/**
 * Gets the Token sent to the web service
 * @return string
 */
function getWebServiceRequestToken() {
    $token = getRequestParam("token", TRUE);
    return (empty($token) ? "" : base64_decode($token));
}

/**
 * Gets the Data sent to the web service
 * @return string
 */
function getWebServiceRequestData() {
    return getRequestParam("data", TRUE);
}

/**
 * Encrypts a text using the AES Key/IV of a SessionToken
 * @global SessionToken $WS_SESSION
 * @param string $text Text to encrypt
 * @param SessionToken $session SessionToken used to encrypt (if NULL then uses the global $WS_SESSION)
 * @return string The encrypted text
 */
function clientEncrypt($text, $session = NULL) {
    global $WS_SESSION;
    if ($session === NULL) {
        $session = $WS_SESSION;
    }
    $plainText = "";
    if ($text !== NULL) {
        try {
            $plainText = strval($text);
        } catch (Exception $ex) {
            AppLog::Warning("(clientEncrypt) Could not convert \$text to string: " . $ex->getMessage());
            $plainText = "";
        }
    }
    $encrypted = "";
    if ($plainText && $session && is_a($session, SessionToken::class)) {
        $aes = new AES();
        $aes->setKey(base64_decode($session->AES_Key));
        $aes->setIV(base64_decode($session->AES_IV));
        $encrypted = base64_encode($aes->encrypt($plainText));
    }
    return $encrypted;
}

/**
 * Compare two version strings and returns whether the other version is higher than the current
 * @param type $currentVersionNumber Current version number
 * @param type $otherVersionNumber Other version number
 * @return boolean TRUE if other version is higher
 */
function isHigherVersion($currentVersionNumber, $otherVersionNumber) {
    // Split remote and local version by "." and convert to lower-case
    $versionOther = explode(".", strtolower($otherVersionNumber));
    $versionLocal = explode(".", strtolower($currentVersionNumber));
    // Make sure that the array of remote and local versions have the same length
    while (count($versionOther) < count($versionLocal)) {
        $versionOther[] = "";
    }
    while (count($versionLocal) < count($versionOther)) {
        $versionLocal[] = "";
    }
    // Compare the remote mayor/minor/revision/build with the local version
    for ($i = 0; $i < count($versionOther); $i++) {
        // Remove "beta" string from the current mayor/minor/revision/build number
        $versionOtherNumber = str_replace("beta", "", $versionOther[$i]);
        $versionLocalNumber = str_replace("beta", "", $versionLocal[$i]);
        // Add '0' to the left of the current mayor/minor/revision/build to transform it like '000'
        $versionOtherNumber = str_pad($versionOtherNumber, 3, "0", STR_PAD_LEFT);
        $versionLocalNumber = str_pad($versionLocalNumber, 3, "0", STR_PAD_LEFT);
        // Compare the current mayor/minor/revision/build
        if (strcasecmp($versionOtherNumber, $versionLocalNumber) > 0) {
            return TRUE;
        }
    }
    return FALSE;
}
